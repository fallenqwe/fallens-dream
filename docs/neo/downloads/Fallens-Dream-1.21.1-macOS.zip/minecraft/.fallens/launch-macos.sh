#!/bin/sh
# Fallen's Dream NeoForge macOS pre-launch updater. MIT. Does not launch Minecraft.
set -eu

script_dir=$(CDPATH= cd "$(dirname "$0")" && pwd)
minecraft_dir=$(CDPATH= cd "$script_dir/.." && pwd)
data_dir=$(CDPATH= cd "$minecraft_dir/../../.." && pwd)
channel_url='https://fallenqwe.github.io/fallens-dream/neo/channel.properties'

java_major() {
    [ -n "$1" ] && [ -x "$1" ] || return 1
    version=$("$1" -XshowSettings:properties -version 2>&1) || return 1
    printf '%s\n' "$version" | awk '$1 == "java.specification.version" && $2 == "=" { print $3; exit }'
}

# Prefer Java 21 (what Minecraft 1.21.1 uses); any newer Java also runs the updater.
selected=''
fallback=''
consider() {
    [ -z "$selected" ] || return 0
    major=$(java_major "$1") || return 0
    case "$major" in
        21) selected=$1 ;;
        2[2-9]|[3-9][0-9]) [ -n "$fallback" ] || fallback=$1 ;;
    esac
}

consider "${INST_JAVA:-}"
# Prism-managed Mojang runtimes may contain either a bin directory or a macOS bundle.
for root in "$data_dir/java" "$HOME/Library/Application Support/PrismLauncher/java"; do
    for candidate in "$root"/*/bin/java "$root"/*/Contents/Home/bin/java "$root"/*/*/Contents/Home/bin/java; do
        consider "$candidate"
    done
done
for candidate in "${JAVA_HOME:-/nonexistent-java-home}/bin/java" \
    /Library/Java/JavaVirtualMachines/*/Contents/Home/bin/java \
    "$HOME"/Library/Java/JavaVirtualMachines/*/Contents/Home/bin/java; do
    consider "$candidate"
done
if [ -z "$selected" ] && [ -x /usr/libexec/java_home ]; then
    if detected_home=$(/usr/libexec/java_home -v 21 2>/dev/null); then
        consider "$detected_home/bin/java"
    fi
fi
if path_java=$(command -v java 2>/dev/null); then
    consider "$path_java"
fi
[ -n "$selected" ] || selected=$fallback

if [ -z "$selected" ]; then
    printf '%s\n' 'Java 21 was not found. In Prism enable Autodetect Java version and Auto-download Mojang Java, then launch again.' >&2
    exit 1
fi

printf '%s\n' "Fallen's Dream NeoForge: Java found ($selected); checking the update channel."
cd "$script_dir"
exec "$selected" -Djava.awt.headless=true -jar launcher.jar .. "$channel_url"

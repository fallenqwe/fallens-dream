Компоненты скачиваются с исходных CDN, версии и SHA512 закреплены.
[NTGL] NukaTeam's Gun Lib 3.2.0 — https://cdn.modrinth.com/data/5m2kV8xK/versions/zd7xJnqO/ntgl-1.21.1-3.2.0.jar
Async Logger 2.2.3+1.21.1-neoforge — https://cdn.modrinth.com/data/zvNzKfGF/versions/z6QoWGKq/asynclogger-2.2.3%2B1.21.1-neoforge.jar
Balm 21.0.66+neoforge-1.21.1 — https://cdn.modrinth.com/data/MBAkmtvl/versions/CquiaiDj/balm-neoforge-1.21.1-21.0.66.jar
Brewin' And Chewin' 4.5.0+1.21.1-neoforge — https://cdn.modrinth.com/data/hIu9KJTT/versions/MbcR48Ou/BrewinAndChewin-neoforge-4.5.0%2B1.21.1.jar
Carry On 2.2.6 — https://cdn.modrinth.com/data/joEfVgkn/versions/PV8oLZ1q/carryon-neoforge-1.21.1-2.2.6.13.jar
Carved Wood 1.9.8-B-NeoForge-1.21.1 — https://cdn.modrinth.com/data/WuwijfrW/versions/TQmOwXRa/Carved%20Wood-neoforge-1.21.1-1.9.8-B.jar
Cooking for Blockheads 21.1.24+neoforge-1.21.1 — https://cdn.modrinth.com/data/vJnhuDde/versions/MQCIy6VF/cookingforblockheads-neoforge-1.21.1-21.1.24.jar
Create 6.0.10+mc1.21.1 — https://cdn.modrinth.com/data/LNytGWDc/versions/UjX6dr61/create-1.21.1-6.0.10.jar
Create Aeronautics 1.3.2+mc1.21.1 — https://cdn.modrinth.com/data/oWaK0Q19/versions/44pLdPGg/create-aeronautics-bundled-1.21.1-1.3.2.jar
Create Aeronautics: Rechiseled Compatibility 1.2.2 — https://cdn.modrinth.com/data/ub0jAGhg/versions/b6O6XLL6/create-aeronautics-rechiseled-compat-1.21.1-1.2.2.jar
Create Crafts & Additions neoforge-1.21.1-1.7.2 — https://cdn.modrinth.com/data/kU1G12Nn/versions/hsjVajlP/createaddition-1.7.2.jar
Create Deco 2.1.3 — https://cdn.modrinth.com/data/sMvUb4Rb/versions/qrcMVoBD/createdeco-2.1.3.jar
Create Jetpack 5.2.1 — https://cdn.modrinth.com/data/UbFnAd4l/versions/sCwiqLqq/create_jetpack-forge-5.2.1.jar
Create Slice & Dice 4.3.4 — https://cdn.modrinth.com/data/GmjmRQ0A/versions/D6mQaFRW/sliceanddice-4.3.4-neoforge.jar
Create Stuff 'N Additions 2.1.4.b — https://cdn.modrinth.com/data/aq9qUUQG/versions/gMWQ1LX9/create-stuff-additions1.21.1_v2.1.4b.jar
Create Stuff 'N Additions x Sable & Aeronautics Compat 1.0.4 — https://cdn.modrinth.com/data/gsAqDfOu/versions/iGTmXDCM/sable_sa_compat-1.0.4.jar
Create: Bells & Whistles v0.4.7-1.21.1 — https://cdn.modrinth.com/data/gJ5afkVv/versions/w0mifib8/bellsandwhistles-0.4.7-1.21.1.jar
Create: Connected 1.3.3-mc1.21.1 — https://cdn.modrinth.com/data/Vg5TIO6d/versions/Xe7EqzfQ/create_connected-1.3.3-mc1.21.1.jar
Create: Copycats+ 3.0.9+mc.1.21.1-neoforge — https://cdn.modrinth.com/data/UT2M39wf/versions/bPYeUWZx/copycats-3.0.9%2Bmc.1.21.1-neoforge.jar
Create: Crafts & Additions and Aeronautics Compat 1.0.0 — https://cdn.modrinth.com/data/tum2vG0T/versions/zibO5DQH/aeroadditionbridge-1.0.0.jar
Create: Diesel Generators 1.21.1-1.3.15 — https://cdn.modrinth.com/data/ZM3tt6p1/versions/UoPH8lO1/createdieselgenerators-1.21.1-1.3.15.jar
Create: Dragons Plus 1.11.9 — https://cdn.modrinth.com/data/dzb1a5WV/versions/b0u9vk8C/CreateDragonsPlus-1.11.9.jar
Create: Enchantment Industry 2.5.4b — https://cdn.modrinth.com/data/JWGBpFUP/versions/L6VSDdC4/create-enchantment-industry-2.5.4b.jar
Create: Food 3.0.0 — https://cdn.modrinth.com/data/4HnO3el1/versions/uaxLGKon/createfood-neoforge-1.21.1-3.0.0.jar
Create: Gunsmithing 1.4.9 — https://cdn.modrinth.com/data/7KCNsGPM/versions/AmBZCjMo/create-gunsmithing-1.21.1-1.4.9.jar
Create: Interiors 0.6.1 — https://cdn.modrinth.com/data/r4Knci2k/versions/gBrfZy6S/interiors-1.21.1-neoforge-0.6.1.jar
Create: Lift n' Load |  Simulated/Aeronautics Addon 1.0c — https://cdn.modrinth.com/data/aJR8vXL6/versions/G7N1k717/Lift-n-Load-1.21.1-1.0c.jar
Create: Liquid Fuel 3.0.0-1.21.1 — https://cdn.modrinth.com/data/sH9tXU9f/versions/rLn2bDVE/createliquidfuel-3.0.0-1.21.1.jar
Create: Mobile Packages 1.21.1-0.7.8 — https://cdn.modrinth.com/data/1vXRfEHZ/versions/xSPt2JXH/create_mobile_packages-1.21.1-0.7.8.jar
Create: Sophisticated Backpacks Compat 1.0 — https://cdn.modrinth.com/data/BAEkFrvn/versions/MGpIgh9e/create_sophback_compat-1.0.jar
Create: Tracks+ 1.0.6b7 — https://cdn.modrinth.com/data/E8eHF2Yl/versions/qUDRhHla/tracks_plus-1.0.6b7.jar
Create: Vibrant Vaults 0.3.2 — https://cdn.modrinth.com/data/hddN8ksR/versions/t17qYXjn/create_vibrant_vaults-0.3.2.jar
CreativeCore 2.13.51 — https://cdn.modrinth.com/data/OsZiaDHq/versions/vRMtFt35/CreativeCore_NEOFORGE_v2.13.51_mc1.21.1.jar
Delightful Creators 1.2.1 — https://cdn.modrinth.com/data/jmJ87gsb/versions/xde79BbO/delightfulcreators-1.2.1.jar
Display Delight 1.7.0 — https://cdn.modrinth.com/data/yXepZhp8/versions/xiS3GrrW/displaydelight-1.7.0.jar
Ecologics 2.3.7-NeoForge — https://cdn.modrinth.com/data/NCKpPR0Z/versions/ihEiqSv4/ecologics-1.21.1-2.3.7.jar
Exposure 1.9.19 — https://cdn.modrinth.com/data/hB899VmG/versions/iBvaR6AK/exposure-neoforge-1.21.1-1.9.19.jar
Exposure: Polaroid 1.1.6 — https://cdn.modrinth.com/data/WEWiqYkW/versions/WfVyzdJL/exposure_polaroid-neoforge-1.21.1-1.1.6.jar
FallingTree 1.21.1-1.21.1.11 — https://cdn.modrinth.com/data/Fb4jn8m6/versions/wxGXaJMA/FallingTree-1.21.1-1.21.1.11.jar
Farmer's Delight 1.21.1-1.3.4 — https://cdn.modrinth.com/data/R2OftAxM/versions/XTVZDOol/FarmersDelight-1.21.1-1.3.4.jar
Fast Noise 1.0.13+1.21.1+neoforge — https://cdn.modrinth.com/data/OnlVIpq5/versions/9vSFkDAr/zfastnoise-1.0.13%2B1.21.1%2Bneoforge.jar
FerriteCore 7.0.3-neoforge — https://cdn.modrinth.com/data/uXXizFIs/versions/x7kQWVju/ferritecore-7.0.3-neoforge.jar
Forgified Fabric API 0.116.15+2.3.6+1.21.1 — https://cdn.modrinth.com/data/Aqlf1Shp/versions/C4eskNuR/forgified-fabric-api-0.116.15%2B2.3.6%2B1.21.1.jar
Geckolib 4.9.3 — https://cdn.modrinth.com/data/8BmcQJ2H/versions/Grwn5rUB/geckolib-neoforge-1.21.1-4.9.3.jar
GlitchCore 2.1.0.2 — https://cdn.modrinth.com/data/s3dmwKy5/versions/S2TfWrZR/GlitchCore-neoforge-1.21.1-2.1.0.2.jar
Global Packs 21.0.6 — https://cdn.modrinth.com/data/NRLPy2mk/versions/FPcUOp35/globalpacks-neoforge-1.21.1-21.0.6.jar
Gravestone and Sable Compatibility Patch 1.0.0 — https://cdn.modrinth.com/data/xJqwA0XO/versions/bdUGV5X8/gravestone_sable_compat-1.0.0.jar
GraveStone Mod neoforge-1.21.1-1.0.40 — https://cdn.modrinth.com/data/RYtXKJPr/versions/rMGJpjaM/gravestone-neoforge-1.21.1-1.0.40.jar
Jade 🔍 15.10.6+neoforge — https://cdn.modrinth.com/data/nvQzSEkH/versions/eYz2YBGT/Jade-1.21.1-NeoForge-15.10.6.jar
Kotlin for Forge 5.12.0 — https://cdn.modrinth.com/data/ordsPcFz/versions/uhJhCT7X/kotlinforforge-5.12.0-all.jar
Lithium mc1.21.1-0.15.4-neoforge — https://cdn.modrinth.com/data/gvQqBUqZ/versions/DDUrRVCA/lithium-neoforge-0.15.4%2Bmc1.21.1.jar
Lithostitched 1.8.1-neoforge-21.1 — https://cdn.modrinth.com/data/XaDC71GB/versions/cZu4cHY3/lithostitched-1.8.1-neoforge-21.1.jar
Macaw's Doors 1.1.5 — https://cdn.modrinth.com/data/kNxa8z3e/versions/u7BRX44F/mcw-doors-1.1.5-mc1.21.1neoforge.jar
Macaw's Fences and Walls 1.2.1 — https://cdn.modrinth.com/data/GmwLse2I/versions/jVdb0r4W/mcw-mcwfences-1.2.1-mc1.21.1neoforge.jar
Macaw's Furniture 3.4.1 — https://cdn.modrinth.com/data/dtWC90iB/versions/Z5V3Ps7S/mcw-furniture-3.4.1-mc1.21.1neoforge.jar
Macaw's Lights and Lamps 1.1.5 — https://cdn.modrinth.com/data/w4an97C2/versions/5U2kQZIL/mcw-lights-1.1.5-mc1.21.1neoforge.jar
Macaw's Paths and Pavings 1.1.1 — https://cdn.modrinth.com/data/VRLhWB91/versions/tlymsxUG/mcw-mcwpaths-1.1.1-mc1.21.1neoforge.jar
Macaw's Roofs 2.3.2 — https://cdn.modrinth.com/data/B8jaH3P1/versions/jiXRXiSt/mcw-roofs-2.3.2-mc1.21.1neoforge.jar
Macaw's Windows 2.4.2 — https://cdn.modrinth.com/data/C7I0BCni/versions/rQUE4LCz/mcw-mcwwindows-2.4.2-mc1.21.1neoforge.jar
MDM (formerly Modern Decorations Mod) 3.0.3 — https://cdn.modrinth.com/data/TmUXSYKk/versions/layVL2QV/mdm-3.0.3-neoforge-1.21.1.jar
MezzConfig 0.6.8 — https://cdn.modrinth.com/data/7tEfOcA7/versions/idpM3DKC/mezz_config-1.21.1-neoforge-0.6.8-standalone.jar
ModernDeco 4.0.2 — https://cdn.modrinth.com/data/zJ5aaMEg/versions/n35LG26X/moderndeco-4.0.2-neoforge-1.21.1.jar
ModernFix 5.27.26+mc1.21.1 — https://cdn.modrinth.com/data/nmDcB62a/versions/7Jy58lnT/modernfix-neoforge-5.27.26%2Bmc1.21.1.jar
Puzzles Lib 21.1.65 — https://cdn.modrinth.com/data/QAGBst4M/versions/kiX1lfse/puzzleslib-v21.1.65-mc1.21.1%2Bneoforge.jar
Rechiseled 1.2.6-neoforge-mc1.21 — https://cdn.modrinth.com/data/B0g2vT6l/versions/6muGRqvu/rechiseled-1.2.6-neoforge-mc1.21.jar
Rechiseled: Create 1.1.1-neoforge-mc1.21 — https://cdn.modrinth.com/data/E6867niZ/versions/VnOezhJR/rechiseledcreate-1.1.1-neoforge-mc1.21.jar
Resourceful Config 3.0.11 — https://cdn.modrinth.com/data/M1953qlQ/versions/lSbyRD6v/resourcefulconfig-neoforge-1.21-3.0.11.jar
Rustic Delight 1.7.1 — https://cdn.modrinth.com/data/foa4fGIH/versions/sAaG4pSA/rusticdelight-neoforge-1.21-1.7.1.jar
Sable 2.0.6+mc1.21.1 — https://cdn.modrinth.com/data/T9PomCSv/versions/fg9dTRz9/sable-neoforge-1.21.1-2.0.6.jar
Serene Seasons 10.1.0.9 — https://cdn.modrinth.com/data/e0bNACJD/versions/pHEgQQUE/SereneSeasons-neoforge-1.21.1-10.1.0.9.jar
Simple Voice Chat neoforge-1.21.1-2.6.25 — https://cdn.modrinth.com/data/9eGKb6K1/versions/KDRDUnk4/voicechat-neoforge-1.21.1-2.6.25.jar
Sinytra Connector 2.0.0-beta.17+1.21.1 — https://cdn.modrinth.com/data/u58R1TMW/versions/IITF0PRC/connector-2.0.0-beta.17%2B1.21.1-full.jar
Skniro's Furniture 1.5.0-1.21.1-NeoForge — https://cdn.modrinth.com/data/pezpt98N/versions/3p5JPoG1/SkniroFurniture-1.5.0-1.21.1-NeoForge.jar
Sophisticated Backpacks 1.21.1-3.26.14.2222 — https://cdn.modrinth.com/data/TyCTlI4b/versions/eg9lPtG4/sophisticatedbackpacks-1.21.1-3.26.14.2222.jar
Sophisticated Core 1.21.1-1.5.17.2426 — https://cdn.modrinth.com/data/nmoqTijg/versions/gtPF4VTh/sophisticatedcore-1.21.1-1.5.17.2426.jar
Steam 'n' Rails Neoforge 0.3.0-beta.2+neoforge-mc1.21.1 — https://cdn.modrinth.com/data/L3Jv0QZI/versions/czVeSmZo/railways-0.3.0-beta.2%2Bneoforge-mc1.21.1.jar
Stoneworks v21.1.0-1.21.1-NeoForge — https://cdn.modrinth.com/data/FzyTKtVF/versions/9XTU6J5n/Stoneworks-v21.1.0-1.21.1-NeoForge.jar
Storage Delight 26.09.17-1.21-neoforge — https://cdn.modrinth.com/data/LTTvOp5L/versions/7I2UUB9l/storagedelight-26.09.17-1.21-neoforge.jar
Structure Layout Optimizer 1.0.12+1.21.1-neoforge — https://cdn.modrinth.com/data/ayPU0OHc/versions/eTz03Gfd/structure_layout_optimizer-neoforge-1.0.12.jar
SuperMartijn642's Config Lib 1.1.8-neoforge-mc1.21 — https://cdn.modrinth.com/data/LN9BxssP/versions/qKL9jM75/supermartijn642configlib-1.1.8-neoforge-mc1.21.jar
SuperMartijn642's Core Lib 1.1.25-neoforge-mc1.21 — https://cdn.modrinth.com/data/rOUBggPv/versions/OG6Edgmm/supermartijn642corelib-1.1.25-neoforge-mc1.21.jar
Terralith 2.6.2 — https://cdn.modrinth.com/data/8oi3bsk5/versions/IY93YaEe/Terralith_1.21.1_v2.6.2_Neoforge.jar
Tiny Flowers v2.1.0+1.21.1-neoforge — https://cdn.modrinth.com/data/S0Lqneqb/versions/WDVl3yUg/tiny_flowers-neoforge-1.21.1-2.1.0%2B1.21.1.jar
Traveler's Backpack 1.21.1-10.1.40 — https://cdn.modrinth.com/data/rlloIFEV/versions/ZqrwMSn5/travelersbackpack-neoforge-1.21.1-10.1.40.jar
Visual Workbench 21.1.2 — https://cdn.modrinth.com/data/kfqD1JRw/versions/3646RfLS/VisualWorkbench-v21.1.2-1.21.1-NeoForge.jar
Create: Fishery Industry 5.1.2 — https://mediafilez.forgecdn.net/files/8863/886/createfisheryindustry-5.1.2.jar
Fusion (Connected Textures) 1.3.16-neoforge-mc1.21.1 — https://cdn.modrinth.com/data/p19vrgc2/versions/AYDaLPK8/fusion-1.3.16-neoforge-mc1.21.1.jar
Just Enough Items 19.32.0.359 — https://cdn.modrinth.com/data/u6dRKJwZ/versions/MAi4uKUF/jei-1.21.1-neoforge-19.32.0.359.jar
FallensUpdater 0.2 - MIT - source: https://fallenqwe.github.io/fallens-dream/neo/tools/client/FallensUpdater.java
packwiz-installer 0.5.14 - MIT - https://github.com/packwiz/packwiz-installer; license: licenses/packwiz-installer.txt

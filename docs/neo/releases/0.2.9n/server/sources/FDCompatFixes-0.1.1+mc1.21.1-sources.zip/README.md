# Fallen's Dream Compatibility Fixes 0.1.1

Minecraft1.21.1, NeoForge21.1.264, Java21. MIT, original source only. The mod may be installed on both physical sides and also works on the logical server in singleplayer. It registers no content, custom registries, network payloads or client assets, so a client is not required to carry this JAR when connecting to a dedicated server.

## Fixes

1. While `StructureTemplate` places vanilla paintings, item/glow item frames or leash knots, its already transformed `StructureEntityInfo.blockPos` is written to the temporary copied NBT Tile coordinates before entity creation. Source template NBT, unrelated entities and partial/missing anchors remain unchanged. This does not modify arbitrary entities loaded from saved chunks or migrate existing world data.
2. Two WDA advancement resource objects with the known broken parent are copied in memory and reparented directly to the existing WDA root. No fake hidden bridge is added, and no WDA assets are redistributed.

## Removed in 0.1.1: large-dripstone wind limit

0.1.0 limited the wind (tilt) of every `minecraft:large_dripstone` placement, including Terralith frostfire columns, by a bound computed from the whole dimension height. Review showed that this removed almost all tilt instead of only unsafe offsets. The original symptom was a harmless log warning about a write outside the generation region, which vanilla already rejects itself. 0.1.1 removes the limit and its mixins completely (`WindBounds`, `LargeDripstoneFeatureMixin`, `WindOffsetterMixin`, `WorldGenRegionStepAccessor`); large dripstone generation is vanilla again, including vanilla's own rejection of such writes and its log warning.

Chunks generated while 0.1.0 was installed keep their nearly vertical large stalactites and columns; the mod never rewrites generated chunks. Only newly generated chunks get vanilla tilt, so a visible seam can appear between old and new areas.

## Standalone build

Install JDK21 and Gradle8.14.3, then run `gradle build` in this source folder. The checked ModDevGradle2.0.148 build downloads NeoForge21.1.264 and compile dependencies from official repositories. Output: `gradle-build/libs/FDCompatFixes-0.1.1+mc1.21.1.jar`.

Only `src/`, `resources/` and `LICENSE` enter the production JAR. `test-src/`, `run_native.py` and `build.py` are local integration-review tooling and never enter it. `build.py` reuses an existing private workspace's cached native dependencies for offline compilation; it is not the standalone build entry point. The standalone Gradle build needs no workspace paths, original mod JAR copies, worlds, server credentials or EULA.

## Verification and limits

The local harness copies an existing accepted EULA and an isolated old test world, starts dedicated servers on loopback, and compares RED/GREEN without a game client or GUI. It executes actual native large-dripstone placement and the native chunk-write guard over a synthetic cavern block store and, for 0.1.1, requires identical results with and without the mod. It also executes native structure-template entity placement for all mirror/rotation combinations, checks payload preservation, negative inputs, absence of the removed wind classes, registered channels and WDA tree visibility. The harness requires the original project's cached test fixtures; they are not distributed.

The fixes affect future template placement and advancement reloads. They do not rebuild already generated chunks. Renderer, exact appearance, integrated-client startup and real player networking require a player test; dedicated-server tests do not establish those results.

Third-party Minecraft/NeoForge/Mixin APIs are compile/runtime dependencies and are not bundled. Original Terralith and WDA artifacts remain unchanged and must be obtained from their authors.

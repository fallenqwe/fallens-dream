package fd.test;

import com.google.gson.GsonBuilder;
import java.lang.reflect.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.function.Predicate;
import net.minecraft.commands.Commands;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.nbt.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.util.RandomSource;
import net.minecraft.world.entity.decoration.ItemFrame;
import net.minecraft.world.entity.decoration.BlockAttachedEntity;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.block.*;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.chunk.status.*;
import net.minecraft.world.level.levelgen.feature.*;
import net.minecraft.world.level.levelgen.feature.configurations.LargeDripstoneConfiguration;
import net.minecraft.world.level.levelgen.structure.templatesystem.*;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.phys.Vec3;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.common.NeoForge;
import net.neoforged.neoforge.event.RegisterCommandsEvent;

@Mod(value="fd_worldgen_test",dist=Dist.DEDICATED_SERVER)
public final class WorldgenProbe {
    public WorldgenProbe() { NeoForge.EVENT_BUS.addListener(WorldgenProbe::commands); }
    private static void commands(RegisterCommandsEvent event) {
        event.getDispatcher().register(Commands.literal("fdworldgentest").requires(s->s.hasPermission(4)).executes(c->{
            try { run(c.getSource().getServer()); return 1; }
            catch(Throwable error) { save("worldgen-failure.json",Map.of("error",error.toString(),"stack",Arrays.toString(error.getStackTrace()),"cause",String.valueOf(error.getCause())));error.printStackTrace();return 0; }
        }));
    }
    private static void save(String name,Object value) {
        try { Files.writeString(Path.of(name),new GsonBuilder().setPrettyPrinting().create().toJson(value),StandardCharsets.UTF_8); }
        catch(Exception e) { throw new RuntimeException(e); }
    }
    private static void run(MinecraftServer server)throws Exception {
        ServerLevel level=server.overworld();
        List<Object> results=new ArrayList<>();long rejected=0,placed=0;
        for(String id:List.of("terralith:cave/frostfire/pillar","terralith:cave/frostfire/pillar_huge")) {
            var configured=level.registryAccess().registryOrThrow(Registries.CONFIGURED_FEATURE).get(ResourceLocation.parse(id));
            var config=(LargeDripstoneConfiguration)configured.config();
            for(int seed=0;seed<8;seed++) for(int[] corner:List.of(new int[]{0,0},new int[]{0,15},new int[]{15,0},new int[]{15,15})) {
                var world=new Cavern(level);
                BlockPos origin=new BlockPos(corner[0],50,corner[1]);
                boolean done=Feature.LARGE_DRIPSTONE.place(new FeaturePlaceContext<>(Optional.empty(),world,
                    level.getChunkSource().getGenerator(),RandomSource.create(seed),origin,config));
                results.add(Map.of("feature",id,"seed",seed,"x",corner[0],"z",corner[1],"placed",world.placed,"rejected",world.rejected,"feature_result",done));
                rejected+=world.rejected;placed+=world.placed;
            }
        }
        // Direct native StructureTemplate placement with deliberately stale author-world Tile coordinates.
        List<Object> entities=new ArrayList<>();
        Method add=StructureTemplate.class.getDeclaredMethod("addEntitiesToWorld",net.minecraft.world.level.ServerLevelAccessor.class,BlockPos.class,StructurePlaceSettings.class);
        add.setAccessible(true);
        Field infos=StructureTemplate.class.getDeclaredField("entityInfoList");infos.setAccessible(true);
        int caseIndex=0;
        for(String kind:List.of("minecraft:item_frame","minecraft:glow_item_frame","minecraft:painting","minecraft:leash_knot"))
        for(Mirror mirror:Mirror.values()) for(Rotation rotation:Rotation.values()) {
            StructureTemplate template=new StructureTemplate();
            CompoundTag tag=new CompoundTag();tag.putString("id",kind);
            tag.putInt("TileX",-17);tag.putInt("TileY",-56);tag.putInt("TileZ",2208);
            tag.putByte("Facing",(byte)2);tag.putByte("ItemRotation",(byte)3);tag.putBoolean("Fixed",true);
            tag.putString("variant","minecraft:kebab");
            tag.put("Item",new ItemStack(Items.DIAMOND,1).save(level.registryAccess()));
            @SuppressWarnings("unchecked") List<StructureTemplate.StructureEntityInfo> list=(List<StructureTemplate.StructureEntityInfo>)infos.get(template);
            list.add(new StructureTemplate.StructureEntityInfo(new Vec3(0.5,0.5,0.03125),BlockPos.ZERO,tag));
            BlockPos origin=new BlockPos(8,180,8);
            level.getChunk(origin);
            var before=level.getEntitiesOfClass(BlockAttachedEntity.class,new net.minecraft.world.phys.AABB(origin).inflate(6));
            add.invoke(template,level,origin,new StructurePlaceSettings().setMirror(mirror).setRotation(rotation));
            var after=level.getEntitiesOfClass(BlockAttachedEntity.class,new net.minecraft.world.phys.AABB(origin).inflate(6));
            after.removeAll(before);
            if(after.size()!=1) throw new AssertionError("Expected one native item frame, got "+after.size());
            BlockAttachedEntity frame=after.get(0);
            if(!frame.getPos().equals(origin)) throw new AssertionError("Wrong transformed anchor: "+frame.getPos()+" != "+origin);
            if(frame instanceof ItemFrame itemFrame&&(!itemFrame.getItem().is(Items.DIAMOND)||itemFrame.getItem().getCount()!=1||itemFrame.getRotation()!=3||!itemFrame.saveWithoutId(new CompoundTag()).getBoolean("Fixed"))) throw new AssertionError("Payload changed");
            if(tag.getInt("TileX")!=-17||tag.getInt("TileY")!=-56||tag.getInt("TileZ")!=2208) throw new AssertionError("Source template NBT changed");
            entities.add(Map.of("kind",kind,"mirror",mirror.name(),"rotation",rotation.name(),"anchor",frame.getPos().toShortString(),"payload_preserved",true,"source_nbt_preserved",true));
            frame.discard();caseIndex++;
        }
        Map<String,Boolean> advancements=new TreeMap<>();
        for(String name:List.of("find_small_prairie_house","find_fishing_hut","find_thornborn_towers")) advancements.put(name,server.getAdvancements().get(ResourceLocation.parse("dungeons_arise:"+name))!=null);
        Map<String,Object> advancementTree=new TreeMap<>();
        var rootId=ResourceLocation.parse("dungeons_arise:wda_root");
        for(String name:List.of("find_small_prairie_house","find_fishing_hut","find_thornborn_towers")) {
            var node=server.getAdvancements().tree().get(ResourceLocation.parse("dungeons_arise:"+name));
            advancementTree.put(name,node==null?Map.of("present",false):Map.of("present",true,"parent",node.parent()==null?"none":node.parent().holder().id().toString(),
                "visible_after_root",net.minecraft.server.advancements.AdvancementVisibilityEvaluator.isVisible(node,p->p.holder().id().equals(rootId))));
        }
        boolean compatPresent=net.neoforged.fml.ModList.get().isLoaded("fd_compat_fixes");
        boolean windBoundsAbsent=false;int negativeCases=0;
        if(compatPresent) {
            // 0.1.1 removed the dripstone wind limit entirely; its classes must not ship.
            try { Class.forName("fd.compat.WindBounds");throw new AssertionError("WindBounds still present"); }
            catch(ClassNotFoundException expected) { windBoundsAbsent=true; }
            var normalize=Class.forName("fd.compat.StructureAnchorFix").getMethod("normalize",CompoundTag.class,BlockPos.class);
            for(String kind:List.of("minecraft:item_frame","minecraft:glow_item_frame","minecraft:painting","minecraft:leash_knot","minecraft:pig","example:item_frame")) {
                var original=new CompoundTag();original.putString("id",kind);original.putInt("TileX",0);original.putInt("TileY",1);original.putInt("TileZ",2);original.putString("marker","payload");
                CompoundTag target=original.copy();normalize.invoke(null,target,new BlockPos(40,50,60));
                if(kind.equals("minecraft:pig")||kind.startsWith("example:")) { if(!target.equals(original)) throw new AssertionError("Unrelated entity changed"); }
                else { if(target.getInt("TileX")!=40||target.getInt("TileY")!=50||target.getInt("TileZ")!=60||!target.getString("marker").equals("payload")) throw new AssertionError("Anchor unit failed"); }
                negativeCases++;
            }
            var missing=new CompoundTag();missing.putString("id","minecraft:item_frame");missing.putInt("TileX",0);
            var missingBefore=missing.copy();normalize.invoke(null,missing,new BlockPos(40,50,60));
            if(!missing.equals(missingBefore)) throw new AssertionError("Partial anchor changed");negativeCases++;
        }
        Field registrations=Class.forName("net.neoforged.neoforge.network.registration.NetworkRegistry").getDeclaredField("PAYLOAD_REGISTRATIONS");registrations.setAccessible(true);
        @SuppressWarnings("unchecked") Map<Object,Map<ResourceLocation,Object>> protocols=(Map<Object,Map<ResourceLocation,Object>>)registrations.get(null);
        List<String> ownChannels=protocols.values().stream().flatMap(m->m.keySet().stream()).map(Object::toString).filter(s->s.startsWith("fd_compat_fixes:")).toList();
        if(!ownChannels.isEmpty()) throw new AssertionError("Unexpected required network channels");
        long ownRegistryEntries=java.util.stream.Stream.of(net.minecraft.core.registries.BuiltInRegistries.ITEM,net.minecraft.core.registries.BuiltInRegistries.BLOCK,net.minecraft.core.registries.BuiltInRegistries.ENTITY_TYPE)
            .flatMap(r->r.keySet().stream()).filter(id->id.getNamespace().equals("fd_compat_fixes")).count();
        if(ownRegistryEntries!=0) throw new AssertionError("Unexpected client-required registry entries");
        Map<String,Object> output=new TreeMap<>(Map.of("status","PASS","compat_present",compatPresent,"placed_blocks",placed,"rejected_blocks",rejected,
            "feature_cases",results,"structure_entity_cases",entities,"native_structure_placement_cases",caseIndex,
            "wind_bounds_absent",windBoundsAbsent,"advancements",advancements,"worldgen_guard_radius",ChunkPyramid.GENERATION_PYRAMID.getStepTo(ChunkStatus.FEATURES).blockStateWriteRadius()));
        output.put("negative_cases",negativeCases);output.put("custom_channels",ownChannels);output.put("own_registry_entries",ownRegistryEntries);output.put("advancement_tree",advancementTree);save("worldgen-test.json",output);
    }
    /** The feature and write-guard are native; only the test cavern's block storage is synthetic. */
    private static class Cavern extends WorldGenRegion {
        final Map<BlockPos,BlockState> blocks=new HashMap<>();long rejected,placed;
        Cavern(ServerLevel level) { super(level,null,ChunkPyramid.GENERATION_PYRAMID.getStepTo(ChunkStatus.FEATURES),level.getChunk(0,0));setCurrentlyGenerating(()->"fd_native_cavern_test"); }
        @Override public BlockState getBlockState(BlockPos pos) { return blocks.getOrDefault(pos,pos.getY()>0&&pos.getY()<100?Blocks.CAVE_AIR.defaultBlockState():Blocks.STONE.defaultBlockState()); }
        @Override public FluidState getFluidState(BlockPos pos) { return getBlockState(pos).getFluidState(); }
        @Override public boolean isStateAtPosition(BlockPos pos,Predicate<BlockState> test) { return test.test(getBlockState(pos)); }
        @Override public boolean isFluidAtPosition(BlockPos pos,Predicate<FluidState> test) { return test.test(getFluidState(pos)); }
        @Override public boolean isEmptyBlock(BlockPos pos) { return getBlockState(pos).isAir(); }
        @Override public int getHeight(net.minecraft.world.level.levelgen.Heightmap.Types kind,int x,int z) { return 320; }
        @Override public boolean setBlock(BlockPos pos,BlockState state,int flags,int recursion) {
            if(!ensureCanWrite(pos)) { rejected++;return false; }
            blocks.put(pos.immutable(),state);placed++;return true;
        }
    }
}

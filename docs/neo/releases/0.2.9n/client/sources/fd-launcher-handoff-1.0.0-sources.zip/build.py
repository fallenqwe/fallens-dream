"""Reproducible build of the Fallen's Dream updater 0.3.0 artifacts. No download, no live change, no Minecraft.

Outputs in build/:
  launcher.jar (client FallensUpdater), server-updater.jar, fd-neoforge-starter.jar (pins server-updater.jar),
  fd-launcher-handoff-1.0.0.jar (NeoForge mod embedding launcher.jar + both launch scripts),
  Fallens-Dream-1.21.1-Windows.zip / -macOS.zip (starter ZIPs, same layout as the published ones),
  launch.ps1 / launch-macos.sh (normalized), baseline/ (old 0.2 launcher rebuilt from the review sources), hashes.json.
Every JAR is built twice and must be byte-identical. Usage: python -I build.py
"""
import hashlib, json, shutil, subprocess, sys, zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
PROJECT = HERE.parents[2]
JDK = Path(r'C:\Users\falle\AppData\Roaming\PrismLauncher\instances\Fallens-Dream-1.21.1\runtime\java21\bin')  # read-only
LIBS = Path(r'C:\Users\falle\AppData\Roaming\PrismLauncher\libraries')  # read-only
FML_CP = [LIBS / 'net/neoforged/fancymodloader/loader/4.0.45/loader-4.0.45.jar']
REPRO = PROJECT / 'work/codex-review-2026-10-27/delivery/repro'
TEMPLATES = PROJECT / 'work/server-polish-2026-10-24/delivery'  # the currently published starter ZIPs (d718f04a / 1a36163a)
TEMPLATE_SHA = {'Fallens-Dream-1.21.1-Windows.zip': 'd718f04ad6ffbbdeef5ffe6e56d5b1a53817404ef8f5c201b506b6645d0d015a',
                'Fallens-Dream-1.21.1-macOS.zip': '1a36163abc90ba7986a6021640723e5c9f7586f1d48ae595a7d9504650b071f6'}
OLD = {'launcher.jar': '47317e1ef1b2771e391e72ad47a64168d52f450d20f71c179a97495fd51a3595',
       'server-updater.jar': 'bae23e590077504ddea778bad147ab49970ff89c959b5fc1e6e00b00f692e465',
       'fd-neoforge-starter.jar': '4b534f5f66fbf5ae6e12668322e4eab3454f9e42856bd5f8bbff452faa7756ac'}
HANDOFF_VERSION = '1.0.0'
DATE = '1980-01-01T00:00:02Z'
OUT = HERE / 'build'
WORK = HERE / 'build-work'


def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def run(*args, cwd=None):
    p = subprocess.run([str(a) for a in args], capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=600, cwd=cwd)
    assert p.returncode == 0, (args, p.stdout + p.stderr)
    return p.stdout


def fresh(d):
    if d.exists(): shutil.rmtree(d)
    d.mkdir(parents=True)
    return d


def compile_jar(sources, name, main=None, cp=(), resources=None, manifest=None):
    """javac --release 21 + jar --date, twice; returns the JAR path."""
    hashes = []
    for attempt in (1, 2):
        classes = fresh(WORK / f'{name}-classes-{attempt}')
        args = [JDK / 'javac.exe', '--release', '21', '-encoding', 'UTF-8', '-proc:none', '-d', classes]
        if cp: args += ['-cp', ';'.join(str(c) for c in cp)]
        run(*args, *sources)
        if resources:
            for rel, data in resources.items():
                t = classes / rel; t.parent.mkdir(parents=True, exist_ok=True); t.write_bytes(data)
        target = WORK / f'{name}-{attempt}.jar'
        if target.exists(): target.unlink()
        jar = [JDK / 'jar.exe', '--create', '--file', target, '--date', DATE]
        if main: jar += ['--main-class', main]
        if manifest:
            mf = WORK / f'{name}-manifest.txt'; mf.write_text(manifest, 'ascii', newline='\n'); jar += ['--manifest', mf]
        run(*jar, '-C', classes, '.')
        hashes.append(sha(target))
    assert hashes[0] == hashes[1], f'{name} is not reproducible'
    out = OUT / name
    shutil.copyfile(WORK / f'{name}-1.jar', out)
    return out


def text_lf(path, ascii_only):
    data = path.read_bytes()
    assert not data.startswith(b'\xef\xbb\xbf'), f'{path.name} must not start with a BOM'
    data = data.replace(b'\r\n', b'\n')
    if ascii_only: data.decode('ascii')
    return data


def variant(source, server):
    text = source.read_text('utf-8')
    marker = '    static final boolean SERVER = false; // FD-VARIANT\n'
    assert text.count(marker) == 1, 'variant marker'
    if server: text = text.replace(marker, marker.replace('false', 'true'))
    d = fresh(WORK / ('src-server' if server else 'src-client'))
    (d / 'FallensUpdater.java').write_text(text, 'utf-8', newline='\n')
    return d / 'FallensUpdater.java'


NOTES = {
    'win': """Fallen's Dream — Minecraft 1.21.1 / NeoForge 21.1.264 (обновлятор 0.3.0)

Импортируйте ZIP в Prism Launcher → войдите в Minecraft-аккаунт → Запустить.
Нужны Java 21 (Prism скачает её сам, если включено автоматическое скачивание Java) и 6–8 ГБ памяти. Адрес сервера уже указан.
Первый запуск скачивает текущую версию сборки, следующие проверяют и восстанавливают файлы.
Если сервер обновлений недоступен, запускается уже установленная проверенная версия; предупреждение видно в консоли Prism.
При обрыве загрузки уже скачанные файлы повторно не качаются; прерванный файл качается заново.
Старый профиль 26.3 оставьте отдельно. Миры и настройки игрока не переносятся автоматически.
""",
    'mac': """Fallen's Dream — Minecraft 1.21.1 / NeoForge 21.1.264 (обновлятор 0.3.0)

Импортируйте ZIP в Prism Launcher → войдите в Minecraft-аккаунт → Запустить.
Нужны Java 21 (Prism скачает её сам, если включено автоматическое скачивание Java) и 6–8 ГБ памяти. Адрес сервера уже указан.
Первый запуск скачивает текущую версию сборки, следующие проверяют и восстанавливают файлы.
Если сервер обновлений недоступен, запускается уже установленная проверенная версия; предупреждение видно в консоли Prism.
При обрыве загрузки уже скачанные файлы повторно не качаются; прерванный файл качается заново.
Старый профиль 26.3 оставьте отдельно. Миры и настройки игрока не переносятся автоматически.
На настоящем Mac запуск пока не проверен. Импортируйте ZIP, а не распакованную Safari папку.
""",
}


def build_zip(name, kind, replacements):
    src = TEMPLATES / name
    assert sha(src) == TEMPLATE_SHA[name], 'template ZIP changed: ' + name
    target = OUT / name
    with zipfile.ZipFile(src) as zin, zipfile.ZipFile(target, 'w') as zout:
        for info in zin.infolist():
            data = replacements.get(info.filename, None)
            if data is None:
                if info.filename in ('notes.txt', 'minecraft/.fallens/docs/README.md'): data = NOTES[kind].encode('utf-8')
                else: data = zin.read(info.filename)
            out = zipfile.ZipInfo(info.filename, date_time=info.date_time)
            out.external_attr = info.external_attr
            out.create_system = info.create_system
            out.compress_type = zipfile.ZIP_DEFLATED
            zout.writestr(out, data)
    return target


def main():
    OUT.mkdir(exist_ok=True)
    WORK.mkdir(exist_ok=True)
    report = {'jdk': run(JDK / 'java.exe', '-version') or 'see stderr', 'date': DATE}
    p = subprocess.run([str(JDK / 'java.exe'), '-version'], capture_output=True, text=True)
    report['jdk'] = p.stderr.strip().splitlines()[1]

    # 0. Toolchain proof: the published 0.2 binaries are rebuilt byte-for-byte from the review sources.
    base = fresh(OUT / 'baseline')
    old_client = compile_jar([REPRO / 'src-client/FallensUpdater.java'], 'baseline/launcher-0.2.jar', 'FallensUpdater')
    old_server = compile_jar([REPRO / 'src-server/FallensUpdater.java'], 'baseline/server-updater-0.2.jar', 'FallensUpdater')
    old_starter = compile_jar([REPRO / 'src-starter/FdNeoForgeStarter.java'], 'baseline/fd-neoforge-starter-0.2.jar', 'FdNeoForgeStarter')
    report['baseline'] = {'launcher-0.2.jar': sha(old_client), 'server-updater-0.2.jar': sha(old_server), 'fd-neoforge-starter-0.2.jar': sha(old_starter)}
    assert sha(old_client) == OLD['launcher.jar'] and sha(old_server) == OLD['server-updater.jar'] and sha(old_starter) == OLD['fd-neoforge-starter.jar'], report['baseline']

    # 1. Updaters (one source, two variants).
    launcher = compile_jar([variant(HERE / 'src/FallensUpdater.java', False)], 'launcher.jar', 'FallensUpdater')
    server_updater = compile_jar([variant(HERE / 'src/FallensUpdater.java', True)], 'server-updater.jar', 'FallensUpdater')

    # 2. Starter pinned to the server updater.
    starter_src = (HERE / 'src/FdNeoForgeStarter.java').read_text('utf-8')
    assert starter_src.count('"BUILD_PIN"') == 1
    d = fresh(WORK / 'src-starter')
    (d / 'FdNeoForgeStarter.java').write_text(starter_src.replace('"BUILD_PIN"', '"' + sha(server_updater) + '"'), 'utf-8', newline='\n')
    starter = compile_jar([d / 'FdNeoForgeStarter.java'], 'fd-neoforge-starter.jar', 'FdNeoForgeStarter')

    # 3. Launch scripts.
    ps1 = text_lf(HERE / 'scripts/launch.ps1', True)
    sh = text_lf(HERE / 'scripts/launch-macos.sh', True)
    (OUT / 'launch.ps1').write_bytes(ps1)
    (OUT / 'launch-macos.sh').write_bytes(sh)
    for script in ('launch.ps1', 'launch-macos.sh'):
        assert (OUT / script).read_bytes().count(b"https://fallenqwe.github.io/fallens-dream/neo/channel.properties") == 1

    # 4. Handoff mod embedding exactly these bytes.
    pins = {'@HANDOFF_VERSION@': HANDOFF_VERSION, '@LAUNCHER_SHA256@': sha(launcher),
            '@PS1_SHA256@': hashlib.sha256(ps1).hexdigest(), '@SH_SHA256@': hashlib.sha256(sh).hexdigest()}
    hd = fresh(WORK / 'src-handoff/fdhandoff')
    for name in ('Handoff.java', 'FdLauncherHandoff.java'):
        text = (HERE / 'src/handoff/fdhandoff' / name).read_text('utf-8')
        for k, v in pins.items(): text = text.replace(k, v)
        assert '@' + 'LAUNCHER' not in text and '@PS1' not in text and '@SH_' not in text and '@HANDOFF' not in text
        (hd / name).write_text(text, 'utf-8', newline='\n')
    toml = (HERE / 'src/handoff/META-INF/neoforge.mods.toml').read_text('utf-8').replace('@HANDOFF_VERSION@', HANDOFF_VERSION)
    resources = {'META-INF/neoforge.mods.toml': toml.encode('utf-8'),
                 'META-INF/fd-handoff/launcher.bin': launcher.read_bytes(),
                 'META-INF/fd-handoff/launch.ps1': ps1, 'META-INF/fd-handoff/launch-macos.sh': sh}
    manifest = ('Manifest-Version: 1.0\nAutomatic-Module-Name: fdhandoff\nImplementation-Title: fd_launcher_handoff\n'
                f'Implementation-Version: {HANDOFF_VERSION}\n')
    handoff = compile_jar([hd / 'Handoff.java', hd / 'FdLauncherHandoff.java'], f'fd-launcher-handoff-{HANDOFF_VERSION}.jar',
                          cp=FML_CP, resources=resources, manifest=manifest)

    # 5. Starter ZIPs (same entries, order, dates and modes as the published ones).
    win = build_zip('Fallens-Dream-1.21.1-Windows.zip', 'win', {'minecraft/.fallens/launcher.jar': launcher.read_bytes(), 'minecraft/.fallens/launch.ps1': ps1})
    mac = build_zip('Fallens-Dream-1.21.1-macOS.zip', 'mac', {'minecraft/.fallens/launcher.jar': launcher.read_bytes(), 'minecraft/.fallens/launch-macos.sh': sh})
    zip_hashes = []
    for attempt in (1, 2):
        zip_hashes.append((sha(build_zip('Fallens-Dream-1.21.1-Windows.zip', 'win', {'minecraft/.fallens/launcher.jar': launcher.read_bytes(), 'minecraft/.fallens/launch.ps1': ps1})),
                           sha(build_zip('Fallens-Dream-1.21.1-macOS.zip', 'mac', {'minecraft/.fallens/launcher.jar': launcher.read_bytes(), 'minecraft/.fallens/launch-macos.sh': sh}))))
    assert zip_hashes[0] == zip_hashes[1], 'ZIP not reproducible'
    # Template extracts for the tests (old launcher, old scripts, instance files).
    tpl = fresh(OUT / 'template')
    for name in TEMPLATE_SHA:
        with zipfile.ZipFile(TEMPLATES / name) as z: z.extractall(tpl / name.removesuffix('.zip'))
    assert sha(tpl / 'Fallens-Dream-1.21.1-Windows/minecraft/.fallens/launcher.jar') == OLD['launcher.jar']

    files = {p.name: {'sha256': sha(p), 'size': p.stat().st_size} for p in
             [launcher, server_updater, starter, handoff, win, mac, OUT / 'launch.ps1', OUT / 'launch-macos.sh']}
    report.update({'files': files, 'starter_pins_server_updater': sha(server_updater), 'handoff_pins': {k: v for k, v in pins.items() if 'SHA' in k},
                   'installer_pin': 'c9f646908d340d84773948a9a7d98bc1dae250d35e1016dc6e2b8459760b5598', 'reproducible': True})
    (OUT / 'hashes.json').write_text(json.dumps(report, indent=2, ensure_ascii=False) + '\n', 'utf-8', newline='\n')
    print(json.dumps(report, indent=2, ensure_ascii=False))


if __name__ == '__main__':
    main()

/* SPDX-License-Identifier: MIT */
package fdhandoff;

import net.neoforged.fml.common.Mod;
import net.neoforged.fml.loading.FMLPaths;

/** NeoForge entry point: runs the handoff once per game start; any failure is only logged. */
@Mod("fd_launcher_handoff")
public final class FdLauncherHandoff {
    public FdLauncherHandoff() {
        try {
            Handoff.run(FMLPaths.GAMEDIR.get(), System.out);
        } catch (Throwable t) {
            System.out.println("[fd_launcher_handoff] skipped: " + t);
        }
    }
}

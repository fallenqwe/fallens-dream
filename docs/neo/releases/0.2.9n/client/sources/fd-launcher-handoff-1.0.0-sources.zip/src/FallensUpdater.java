/* SPDX-License-Identifier: MIT
 * Fallen's Dream pre-launch updater: client launcher.jar and server-updater.jar are built from this one file
 * (build.py flips the SERVER constant). Java 21+, no external dependencies. It runs the pinned packwiz-installer
 * only; it never starts Minecraft or a graphical UI. Exit code 0 lets the launcher/starter start Minecraft,
 * any other code blocks the start.
 *
 * 0.3.0 (2026-10-28), after the independent delivery review of 2026-10-27:
 *  - no update server (refused connection, DNS, timeout, HTTP error, missing pack, refused pack) starts the
 *    verified installed version with a warning; so does a failed update that was rolled back;
 *  - the channel may carry a monotonic `build` and `rollback=true`; an older release is not applied silently;
 *  - backups hold only pack-managed files (JAR/ZIP as hard links where possible), the last 2 are kept,
 *    recovery folders are limited by age and size, a partial backup is deleted;
 *  - files downloaded before an interruption are kept in .fallens/download-cache and reused by the next attempt;
 *  - Windows junctions are links; packwiz receives relative paths (no ANSI conversion of the instance path);
 *  - an interrupted update is rolled back and the update continues in the same launch.
 * 0.2 (2026-10-23): the generated Create JAR and the Catalog JAR are optional (unchanged here).
 */
import java.io.*;
import java.net.*;
import java.net.http.*;
import java.nio.ByteBuffer;
import java.nio.channels.*;
import java.nio.charset.StandardCharsets;
import java.nio.charset.CodingErrorAction;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.DosFileAttributeView;
import java.nio.file.attribute.FileTime;
import java.security.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.Pattern;
import java.util.zip.*;

public final class FallensUpdater {
    static final boolean SERVER = false; // FD-VARIANT
    static final String UPDATER_VERSION = "0.3.0";
    static final String INSTALLER_SHA256 = "c9f646908d340d84773948a9a7d98bc1dae250d35e1016dc6e2b8459760b5598";
    static final String GENERATED = "mods/fallens-create.jar";
    static final String CATALOG_TARGET = "mods/fallens-catalog.jar";
    static final List<String> TREES = SERVER
        ? List.of("mods", "config", "world-neoforge/datapacks/fd-server-fixes")
        : List.of("mods", "config", "datapacks", "resourcepacks", "shaderpacks", ".fallens/create", ".fallens/catalog");
    static final List<String> FILES = SERVER
        ? List.of("packwiz.json", ".fallens/state.properties")
        : List.of("options.txt", "packwiz.json", ".fallens/state.properties");
    static final String MMC = "instance/mmc-pack.json";
    static final long ENTRY_LIMIT = 512L * 1024 * 1024;
    static final long TOTAL_LIMIT = 4L * 1024 * 1024 * 1024;
    static final long SNAPSHOT_COPY_LIMIT = 2L * 1024 * 1024 * 1024;
    static final int LISTING_LIMIT = 500_000;
    static final int KEEP_BACKUPS = 2;
    static final Duration KEEP_RECOVERY = Duration.ofDays(14);
    static final long RECOVERY_LIMIT = 1024L * 1024 * 1024;
    static final long PACKWIZ_TIMEOUT_MINUTES = 45;
    static final boolean WINDOWS = System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("win");
    static final boolean CASE_INSENSITIVE = WINDOWS || System.getProperty("os.name", "").toLowerCase(Locale.ROOT).contains("mac");

    static final class Network {
        static final HttpClient HTTP = HttpClient.newBuilder().connectTimeout(Duration.ofSeconds(15))
            .followRedirects(HttpClient.Redirect.NORMAL).build();
    }

    // ---------------------------------------------------------------- messages

    /** A user-facing error with an English and a Russian text (the Russian line is printed on clients only). */
    static class Msg extends IOException {
        final String ru;
        Msg(String en, String ru) { super(en); this.ru = ru; }
        Msg(String en, String ru, Throwable cause) { super(en, cause); this.ru = ru; }
    }
    static final class HttpStatus extends Msg {
        final int code;
        HttpStatus(int code) { super("the update server answered HTTP " + code, "сервер обновлений ответил HTTP " + code); this.code = code; }
    }
    record Reason(String en, String ru) {}

    static void print(PrintStream stream, String levelEn, String levelRu, String en, String ru) {
        stream.println("Fallen's Dream" + levelEn + ": " + en);
        if (!SERVER && ru != null) stream.println("Fallen's Dream" + levelRu + ": " + ru);
        stream.flush();
    }
    static void info(String en, String ru) { print(System.out, "", "", en, ru); }
    static void warn(String en, String ru) { print(System.err, " WARNING", " ВНИМАНИЕ", en, ru); }
    static void error(String en, String ru) { print(System.err, " ERROR", " ОШИБКА", en, ru); }

    static String text(Throwable t) {
        String m = t.getMessage();
        if (m == null || m.isBlank()) return t.getClass().getSimpleName();
        return t.getClass() == IOException.class ? m : t.getClass().getSimpleName() + ": " + m;
    }

    /** Never returns an empty or "null" description. */
    static Reason describe(Throwable e) {
        for (Throwable t = e; t != null; t = t.getCause()) {
            if (t instanceof Msg m) return new Reason(m.getMessage(), m.ru);
            // java.net.http reports an unresolvable name as ConnectException caused by UnresolvedAddressException.
            if (t instanceof UnknownHostException || t instanceof java.nio.channels.UnresolvedAddressException) {
                String host = t.getMessage() == null ? "the name could not be resolved" : t.getMessage();
                return new Reason("the server name was not found (DNS: " + host + ")", "имя сервера не найдено (DNS: " + host + ")");
            }
        }
        for (Throwable t = e; t != null; t = t.getCause()) {
            if (t instanceof HttpConnectTimeoutException) return new Reason("the connection timed out", "истекло время ожидания подключения");
            if (t instanceof HttpTimeoutException || t instanceof SocketTimeoutException) return new Reason("the server did not answer in time", "сервер не ответил вовремя");
            if (t instanceof ConnectException || t instanceof NoRouteToHostException) return new Reason("the connection was refused or the server is unreachable", "соединение отклонено или сервер недоступен");
            if (t instanceof javax.net.ssl.SSLException) return new Reason("the secure connection failed (" + text(t) + ")", "не удалось установить защищённое соединение (" + text(t) + ")");
            if (t instanceof AccessDeniedException a) return new Reason("access denied: " + a.getFile(), "доступ запрещён: " + a.getFile());
            if (t instanceof NoSuchFileException n) return new Reason("file not found: " + n.getFile(), "файл не найден: " + n.getFile());
            if (t instanceof FileSystemException f) return new Reason("file system error at " + f.getFile() + (f.getReason() == null ? "" : ": " + f.getReason()),
                "ошибка файловой системы: " + f.getFile() + (f.getReason() == null ? "" : ": " + f.getReason()));
        }
        String fallback = text(e);
        return new Reason(fallback, fallback);
    }

    static boolean network(Throwable e) {
        for (Throwable t = e; t != null; t = t.getCause()) {
            if (t instanceof UnknownHostException || t instanceof java.nio.channels.UnresolvedAddressException ||
                t instanceof HttpTimeoutException || t instanceof SocketTimeoutException ||
                t instanceof SocketException || t instanceof javax.net.ssl.SSLException || t instanceof EOFException) return true;
        }
        return false;
    }

    static Reason unreachable(String whatEn, String whatRu, IOException e) {
        if (e instanceof HttpStatus s) return new Reason(whatEn + " is unavailable (HTTP " + s.code + ").", whatRu + " недоступен (HTTP " + s.code + ").");
        Reason d = describe(e);
        if (network(e)) return new Reason("no connection to the update server (" + d.en() + ").", "нет связи с сервером обновлений (" + d.ru() + ").");
        return new Reason(whatEn + " could not be downloaded (" + d.en() + ").", whatRu + " не удалось скачать (" + d.ru() + ").");
    }

    // ---------------------------------------------------------------- entry point

    public static void main(String[] args) {
        int code;
        try {
            code = run(args);
        } catch (Throwable e) {
            Reason r = describe(e);
            error("the update stopped: " + r.en() + ".", "обновление остановлено: " + r.ru() + ".");
            error("Minecraft was not started. Worlds and screenshots are outside the updater's file scope.",
                  "Minecraft не запущен. Миры и скриншоты находятся вне области файлов обновлятора.");
            code = 1;
        }
        System.out.flush();
        System.err.flush();
        System.exit(code);
    }

    static int run(String[] args) throws Exception {
        if (args.length == 1 && args[0].equals("--version")) {
            System.out.println("FallensUpdater " + UPDATER_VERSION + (SERVER ? " (server)" : " (client)"));
            return 0;
        }
        // Publisher check: the same channel parser and downgrade rule as an update.
        // --check-channel <channel-file> [<installed-version> <installed-build or ->]
        if ((args.length == 2 || args.length == 4) && args[0].equals("--check-channel")) {
            Channel ch = parseChannel(Files.readAllBytes(Path.of(args[1])));
            System.out.println("version=" + ch.version() + "\npack.url=" + ch.packUrl() + "\npack.sha256=" + ch.packSha()
                + "\nbuild=" + (ch.build() == null ? "-" : ch.build()) + "\nrollback=" + ch.rollback());
            if (args.length == 2) return 0;
            Properties state = new Properties();
            state.setProperty("version", args[2]);
            if (!args[3].equals("-")) state.setProperty("build", args[3]);
            boolean refused = isDowngrade(ch, state);
            System.out.println("decision=" + (refused ? "refused" : "applied") + " (installed " + args[2] + ", build " + args[3] + ")");
            return refused ? 3 : 0;
        }
        // Diagnostics: the paths a pack will manage, as computed before an update. --index-targets <pack.toml> <index.toml>
        if (args.length == 3 && args[0].equals("--index-targets")) {
            MiniToml pack = MiniToml.parse(Files.readAllBytes(Path.of(args[1])));
            byte[] index = Files.readAllBytes(Path.of(args[2]));
            if (!digestHex(pack.value("index.hash-format"), index).equalsIgnoreCase(pack.value("index.hash"))) throw new Msg("index hash mismatch", "хеш индекса не совпадает");
            Targets t = targetsOf(pack.value("index.file"), index);
            System.out.println("exact=" + t.exact().size() + " dirs=" + t.dirs().size());
            new TreeSet<>(t.exact()).forEach(p -> System.out.println("exact " + p));
            new TreeSet<>(t.dirs()).forEach(p -> System.out.println("dir " + p));
            return 0;
        }
        boolean manualRollback = args.length == 3 && args[1].equals("--rollback");
        if (!manualRollback && !(args.length == 2 && !args[1].startsWith("--"))) {
            throw new Msg("usage: java -jar launcher.jar <minecraft-dir> <channel-url>, or <minecraft-dir> --rollback <backup-dir>",
                "использование: java -jar launcher.jar <папка-minecraft> <url-канала> или <папка-minecraft> --rollback <папка-копии>");
        }
        Path mc = Path.of(args[0]).toAbsolutePath().normalize();
        initRoot(mc);
        Files.createDirectories(resolve(mc, ".fallens"));
        Path lockPath = resolve(mc, ".fallens/update.lock");
        try (FileChannel channel = FileChannel.open(lockPath, StandardOpenOption.CREATE, StandardOpenOption.WRITE)) {
            FileLock lock;
            try { lock = channel.tryLock(); }
            catch (OverlappingFileLockException e) { lock = null; }
            if (lock == null) throw new Msg("another Fallen's Dream update is already running for this instance",
                "для этого профиля уже выполняется другое обновление Fallen's Dream");
            try (FileLock held = lock) {
                if (manualRollback) {
                    Path backup = validateBackupLocation(mc, Path.of(args[2]));
                    restoreAny(mc, backup, false, true);
                    Files.deleteIfExists(resolve(mc, ".fallens/pending.properties"));
                    info("the backup was restored. The next launch checks the update channel again.",
                         "резервная копия восстановлена. Следующий запуск снова проверит канал обновлений.");
                    return 0;
                }
                return update(mc, args[1]);
            }
        }
    }

    // ---------------------------------------------------------------- channel

    record Channel(String version, URI packUrl, String packSha, Long build, boolean rollback) {}

    static Channel parseChannel(byte[] bytes) throws Msg {
        try {
            String text = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(bytes)).toString();
            if (text.startsWith("﻿")) text = text.substring(1);
            Properties feed = new Properties();
            feed.load(new StringReader(text));
            String version = required(feed, "version");
            if (version.length() > 100 || version.chars().anyMatch(Character::isISOControl)) throw new IOException("invalid version");
            URI pack = uri(required(feed, "pack.url"));
            String hash = hashValue(required(feed, "pack.sha256"));
            Long build = null;
            String rawBuild = feed.getProperty("build");
            if (rawBuild != null) {
                rawBuild = rawBuild.trim();
                if (!rawBuild.matches("\\d{1,18}")) throw new IOException("invalid build");
                build = Long.parseLong(rawBuild);
            }
            String rollback = feed.getProperty("rollback", "false").trim().toLowerCase(Locale.ROOT);
            if (!rollback.equals("true") && !rollback.equals("false")) throw new IOException("invalid rollback flag");
            return new Channel(version, pack, hash, build, rollback.equals("true"));
        } catch (IOException | IllegalArgumentException e) {
            Reason d = describe(e);
            throw new Msg("the update channel is malformed (" + d.en() + ")", "канал обновлений повреждён (" + d.ru() + ")", e);
        }
    }

    /** Numbers of a version such as 0.2.10n: [0, 2, 10]; null when there are none. */
    static long[] versionKey(String version) {
        if (version == null) return null;
        java.util.regex.Matcher m = Pattern.compile("\\d{1,9}").matcher(version);
        List<Long> parts = new ArrayList<>();
        while (m.find() && parts.size() < 12) parts.add(Long.parseLong(m.group()));
        if (parts.isEmpty()) return null;
        long[] key = new long[parts.size()];
        for (int i = 0; i < key.length; i++) key[i] = parts.get(i);
        return key;
    }
    static Integer compareVersions(String a, String b) {
        long[] x = versionKey(a), y = versionKey(b);
        if (x == null || y == null) return null;
        for (int i = 0; i < Math.max(x.length, y.length); i++) {
            long p = i < x.length ? x[i] : 0, q = i < y.length ? y[i] : 0;
            if (p != q) return Long.compare(p, q);
        }
        return 0;
    }
    static Long installedBuild(Properties state) {
        String b = state == null ? null : state.getProperty("build");
        return b != null && b.trim().matches("\\d{1,18}") ? Long.parseLong(b.trim()) : null;
    }

    /** The highest build seen so far: a channel never lowers it, also when the pack itself does not change. */
    static Long highestBuild(Channel ch, Properties state) {
        Long installed = installedBuild(state);
        if (ch.build() == null) return installed;
        return installed == null ? ch.build() : Math.max(ch.build(), installed);
    }

    /**
     * A pack change. Both sides have a build: only a strictly higher build is applied (a rollback is published as
     * old pack + a new higher build). Otherwise the versions are compared, and an older version needs rollback=true.
     */
    static boolean isDowngrade(Channel ch, Properties state) {
        Long installed = installedBuild(state);
        if (ch.build() != null && installed != null) return ch.build() <= installed;
        Integer c = compareVersions(ch.version(), state.getProperty("version"));
        return c != null && c < 0 && !ch.rollback();
    }

    // ---------------------------------------------------------------- update

    static int update(Path mc, String channelUrl) throws Exception {
        Path pending = resolve(mc, ".fallens/pending.properties");
        cleanTemporaryFiles(mc);
        if (Files.exists(pending, LinkOption.NOFOLLOW_LINKS)) {
            Path backup = validateBackupLocation(mc, mc.resolve(required(load(pending), "backup")));
            try {
                restoreAny(mc, backup, true, false);
            } catch (Exception rollback) {
                Reason d = describe(rollback);
                throw new Msg("an interrupted update could not be rolled back automatically (" + d.en() + "). Backup: " + backup +
                    ". Do not start this instance before restoring it",
                    "не удалось автоматически откатить прерванное обновление (" + d.ru() + "). Резервная копия: " + backup +
                    ". Не запускайте этот профиль, пока она не восстановлена", rollback);
            }
            Files.delete(pending);
            warn("the previous update was interrupted; the previous files were restored. Checking the update channel again.",
                 "предыдущее обновление было прервано; прежние файлы восстановлены. Проверяю канал обновлений ещё раз.");
        }

        byte[] channelBytes;
        try { channelBytes = fetch(uri(channelUrl), 64 * 1024); }
        catch (IOException e) { return launchInstalled(mc, unreachable("the update channel", "канал обновлений", e)); }
        Channel ch;
        try { ch = parseChannel(channelBytes); }
        catch (Msg e) { return launchInstalled(mc, new Reason(e.getMessage() + ".", e.ru + ".")); }
        byte[] pack;
        try { pack = fetch(ch.packUrl(), 4 * 1024 * 1024); }
        catch (IOException e) { return launchInstalled(mc, unreachable("the pack of version " + ch.version(), "пак версии " + ch.version(), e)); }
        if (!sha(pack).equals(ch.packSha())) {
            return launchInstalled(mc, new Reason(
                "the pack of version " + ch.version() + " does not match the checksum in the update channel; the update was refused.",
                "пак версии " + ch.version() + " не совпадает с контрольной суммой из канала обновлений; обновление отклонено."));
        }

        Path statePath = resolve(mc, ".fallens/state.properties");
        Properties old = Files.exists(statePath, LinkOption.NOFOLLOW_LINKS) ? load(statePath) : new Properties();
        boolean changed = !ch.packSha().equalsIgnoreCase(old.getProperty("pack.sha256", "").trim());
        if (changed && isDowngrade(ch, old)) {
            String installed = old.getProperty("version", "?");
            return launchInstalled(mc, new Reason(
                "the update channel offers version " + ch.version() + ", which is older than the installed " + installed +
                    ", without permission to roll back; it was not applied.",
                "канал обновлений предлагает версию " + ch.version() + ", которая старше установленной " + installed +
                    ", без разрешения на откат; она не применена."));
        }
        Path installer = resolve(mc, ".fallens/packwiz-installer.jar");
        if (!Files.isRegularFile(installer, LinkOption.NOFOLLOW_LINKS) || !sha(installer).equals(INSTALLER_SHA256)) {
            return launchInstalled(mc, new Reason(
                "the pinned packwiz-installer 0.5.14 is missing or damaged, so updates cannot be installed; re-import the starter ZIP.",
                "закреплённый packwiz-installer 0.5.14 отсутствует или повреждён, обновления установить нельзя; заново импортируйте стартовый ZIP."));
        }
        managedFiles(mc); // preflight: a link or special file inside a managed path stops before any change

        if (!changed) {
            try {
                runInstaller(mc, ch.packUrl());
                requireInstalledPack(mc, ch.packSha());
            } catch (IOException e) {
                Reason d = describe(e);
                return launchInstalled(mc, new Reason(
                    "the installed files could not be checked with the update server (" + d.en() + ").",
                    "установленные файлы не удалось сверить с сервером обновлений (" + d.ru() + ")."));
            }
            if (!generatedCurrent(mc)) {
                info("repairing generated files.", "восстанавливаю сгенерированные файлы.");
                generateAll(mc);
                saveState(statePath, ch, old, mc); // keeps max(installed, channel) build
            } else if (!Objects.equals(highestBuild(ch, old), installedBuild(old))) {
                // Raise the high-water mark even without a pack change (for example a rollback channel with the
                // pack this player already has), so a stale copy of a withdrawn release is refused later.
                saveState(statePath, ch, old, mc);
            }
            info("version " + ch.version() + ": installed files are current.", "версия " + ch.version() + ": установленные файлы актуальны.");
            safePrune(mc);
            return 0;
        }

        Manifest previous = readManifest(mc); // before pending exists: a damaged manifest stops here, nothing to roll back
        Targets targets;
        try { targets = indexTargets(ch.packUrl(), pack); }
        catch (IOException e) {
            if (e instanceof HttpStatus || network(e)) return launchInstalled(mc, unreachable("the file list of version " + ch.version(), "список файлов версии " + ch.version(), e));
            Reason d = describe(e);
            return launchInstalled(mc, new Reason(
                "the file list of version " + ch.version() + " could not be read (" + d.en() + "); the update was postponed.",
                "список файлов версии " + ch.version() + " прочитать не удалось (" + d.ru() + "); обновление отложено."));
        }
        Path backup;
        try { backup = snapshot(mc, targets); }
        catch (IOException e) {
            Reason d = describe(e);
            return launchInstalled(mc, new Reason(
                "the backup before the update to " + ch.version() + " could not be created (" + d.en() + "); the update was postponed.",
                "резервную копию перед обновлением до " + ch.version() + " создать не удалось (" + d.ru() + "); обновление отложено."));
        }
        Properties transaction = new Properties();
        transaction.setProperty("backup", mc.relativize(backup).toString().replace('\\', '/'));
        transaction.setProperty("target.pack.sha256", ch.packSha());
        transaction.setProperty("target.version", ch.version());
        save(pending, transaction);
        String shown = mc.relativize(backup).toString();
        info("updating to " + ch.version() + ". Backup: " + shown, "обновляю до " + ch.version() + ". Резервная копия: " + shown);
        try {
            List<String> resumed = resumeDownloads(mc);
            runInstaller(mc, ch.packUrl());
            requireInstalledPack(mc, ch.packSha());
            keepPlayerSettings(mc, previous, backup);
            // Inside the transaction: a reused file the new pack does not own must leave mods/ before the
            // installation counts as done; if that fails, the update is rolled back instead.
            settleResumed(mc, resumed);
            generateAll(mc);
            keepReplacedPlayerFiles(mc, backup);
            saveState(statePath, ch, old, mc);
            Files.delete(pending);
        } catch (Exception original) {
            try {
                restoreAny(mc, backup, false, false);
                Files.deleteIfExists(pending);
            } catch (Exception rollback) {
                original.addSuppressed(rollback);
                Reason a = describe(original), b = describe(rollback);
                throw new Msg("the update to " + ch.version() + " failed (" + a.en() + ") and the automatic rollback also failed (" + b.en() +
                    "). Backup: " + backup + ". Do not start this instance before restoring it",
                    "обновление до " + ch.version() + " не удалось (" + a.ru() + "), и автоматический откат тоже не удался (" + b.ru() +
                    "). Резервная копия: " + backup + ". Не запускайте этот профиль, пока она не восстановлена", original);
            }
            Reason d = describe(original);
            return launchInstalled(mc, new Reason(
                "the update to " + ch.version() + " failed (" + d.en() + "); the previous files were restored, downloaded files are kept for the next attempt.",
                "обновление до " + ch.version() + " не удалось (" + d.ru() + "); прежние файлы восстановлены, скачанное сохранено для следующей попытки."));
        }
        info("version " + ch.version() + ": update complete.", "версия " + ch.version() + ": обновление завершено.");
        safePrune(mc);
        return 0;
    }

    /** Starts the verified installed version (exit 0) or explains why it cannot be started (exit 1). */
    static int launchInstalled(Path mc, Reason why) {
        Trust t = installedState(mc);
        if (t.ok()) {
            warn(why.en() + " Launching the installed version " + t.version() + ".",
                 why.ru() + " Запускаю установленную версию " + t.version() + ".");
            if (!t.missing().isEmpty()) {
                String list = String.join(", ", t.missing().subList(0, Math.min(5, t.missing().size()))) + (t.missing().size() > 5 ? ", ..." : "");
                warn(t.missing().size() + " setting file(s) are missing and will be restored when the update server is reachable: " + list,
                     "не хватает файлов настроек (" + t.missing().size() + "), они вернутся, когда сервер обновлений станет доступен: " + list);
            }
            safePrune(mc);
            return 0;
        }
        error(why.en() + " " + t.why().en() + "; Minecraft was not started.",
              why.ru() + " " + t.why().ru() + "; Minecraft не запущен.");
        return 1;
    }

    record Trust(boolean ok, String version, Reason why, List<String> missing) {}
    static Trust notTrusted(String en, String ru) { return new Trust(false, null, new Reason(en, ru), List.of()); }

    /** The installed state can be started without the update server: record, packwiz manifest and immutable files agree. */
    static Trust installedState(Path mc) {
        try {
            Path statePath = resolve(mc, ".fallens/state.properties");
            if (!Files.isRegularFile(statePath, LinkOption.NOFOLLOW_LINKS)) return notTrusted("The modpack is not installed yet", "Сборка ещё не установлена");
            if (Files.exists(resolve(mc, ".fallens/pending.properties"), LinkOption.NOFOLLOW_LINKS)) {
                return notTrusted("An unfinished update is pending", "Есть незавершённое обновление");
            }
            Properties state = load(statePath);
            String version = state.getProperty("version"), hash = state.getProperty("pack.sha256");
            if (version == null || version.isBlank() || hash == null || !hash.trim().matches("[a-fA-F0-9]{64}")) {
                return notTrusted("The installation record is damaged", "Запись об установке повреждена");
            }
            Manifest manifest = readManifest(mc);
            if (manifest == null) return notTrusted("packwiz.json is missing", "Отсутствует packwiz.json");
            if (manifest.packSha() == null || !manifest.packSha().equalsIgnoreCase(hash.trim()) || manifest.indexSha() == null) {
                return notTrusted("The installed files do not belong to the recorded version " + version, "Установленные файлы не соответствуют записанной версии " + version);
            }
            List<String> missing = new ArrayList<>();
            for (CachedFile f : manifest.files()) {
                Path file = resolve(mc, f.location());
                if (immutableCached(f.location())) {
                    if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) return notTrusted("The installed file " + f.location() + " is missing", "Отсутствует установленный файл " + f.location());
                    if (!digest(file, f).equalsIgnoreCase(f.hashValue())) return notTrusted("The installed file " + f.location() + " is damaged", "Повреждён установленный файл " + f.location());
                } else if (!Files.exists(file, LinkOption.NOFOLLOW_LINKS)) {
                    missing.add(f.location());
                }
            }
            if (!generatedCurrent(mc)) return notTrusted("A generated file is missing or damaged", "Сгенерированный файл отсутствует или повреждён");
            return new Trust(true, version.trim(), null, missing);
        } catch (Exception e) {
            Reason d = describe(e);
            return notTrusted("The installed files could not be checked (" + d.en() + ")", "Установленные файлы не удалось проверить (" + d.ru() + ")");
        }
    }

    static void requireInstalledPack(Path mc, String expected) throws IOException {
        Manifest manifest = readManifest(mc);
        if (manifest == null || manifest.packSha() == null || !manifest.packSha().equalsIgnoreCase(expected)) {
            throw new Msg("packwiz installed a different pack.toml than the update channel announced",
                "packwiz установил не тот pack.toml, который указан в канале обновлений");
        }
    }

    static void runInstaller(Path mc, URI packUrl) throws Exception {
        Set<String> previous = manifestLocations(mc);
        verifyCachedImmutable(mc, true);
        Path java = Path.of(System.getProperty("java.home"), "bin", WINDOWS ? "java.exe" : "java");
        // Relative paths with the instance folder as working directory: the Java launcher converts command-line
        // arguments through the ANSI code page on Windows, the working directory is inherited as Unicode.
        List<String> command = new ArrayList<>(List.of(java.toString(), "-Djava.awt.headless=true", "-cp", ".fallens/packwiz-installer.jar",
            "link.infra.packwiz.installer.Main", "-g"));
        if (SERVER) command.addAll(List.of("-s", "server"));
        command.addAll(List.of("--pack-folder", ".", "--multimc-folder", "..", packUrl.toString()));
        Process child = new ProcessBuilder(command).directory(mc.toFile()).inheritIO().start();
        try {
            if (!child.waitFor(PACKWIZ_TIMEOUT_MINUTES, TimeUnit.MINUTES)) {
                child.destroy();
                if (!child.waitFor(5, TimeUnit.SECONDS)) child.destroyForcibly().waitFor();
                throw new Msg("packwiz did not finish within " + PACKWIZ_TIMEOUT_MINUTES + " minutes",
                    "packwiz не завершился за " + PACKWIZ_TIMEOUT_MINUTES + " минут");
            }
            if (child.exitValue() != 0) throw new Msg("packwiz exited with code " + child.exitValue() + " (see the lines above)",
                "packwiz завершился с кодом " + child.exitValue() + " (подробности в строках выше)");
            verifyCachedImmutable(mc, false);
            Set<String> current = manifestLocations(mc);
            for (String old : previous) {
                if (!current.contains(old) && Files.exists(resolve(mc, old), LinkOption.NOFOLLOW_LINKS)) {
                    throw new Msg("packwiz left an obsolete managed file in place: " + old, "packwiz оставил устаревший файл: " + old);
                }
            }
        } catch (InterruptedException e) {
            child.destroyForcibly().waitFor();
            Thread.currentThread().interrupt();
            throw new Msg("the update was interrupted", "обновление прервано", e);
        }
    }

    // ---------------------------------------------------------------- packwiz manifest

    record CachedFile(String location, String hashType, String hashValue) {}
    record Manifest(String packSha, String indexSha, List<CachedFile> files) {}

    static String hashOf(Object raw, String requiredType) {
        if (raw instanceof Map<?, ?> h && h.get("type") instanceof String type && h.get("value") instanceof String value) {
            if (requiredType != null && !type.equalsIgnoreCase(requiredType)) return null;
            return value;
        }
        return null;
    }

    static Manifest readManifest(Path mc) throws IOException {
        Path path = resolve(mc, "packwiz.json");
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return null;
        byte[] bytes;
        try (InputStream in = Files.newInputStream(path)) { bytes = readLimited(in, 16 * 1024 * 1024); }
        Object parsed = FlatJson.parseAny(bytes);
        if (!(parsed instanceof Map<?, ?> root) || !(root.get("cachedFiles") instanceof Map<?, ?> files)) {
            throw new Msg("packwiz.json is damaged", "packwiz.json повреждён");
        }
        List<CachedFile> result = new ArrayList<>();
        for (Object raw : files.values()) {
            if (!(raw instanceof Map<?, ?> entry)) throw new Msg("packwiz.json is damaged", "packwiz.json повреждён");
            Object location = entry.get("cachedLocation");
            if (location == null) continue;
            if (!(location instanceof String name) || !scoped(pathName(name))) {
                throw new Msg("a packwiz file is outside the managed folders: " + location, "файл packwiz вне управляемых папок: " + location);
            }
            Object selected = entry.containsKey("linkedFileHash") ? entry.get("linkedFileHash") : entry.get("hash");
            String type = null, value = null;
            if (selected instanceof Map<?, ?> h && h.get("type") instanceof String t && h.get("value") instanceof String v) { type = t; value = v; }
            result.add(new CachedFile(name, type, value));
        }
        return new Manifest(hashOf(root.get("packFileHash"), "sha256"), hashOf(root.get("indexFileHash"), null), result);
    }

    static Set<String> manifestLocations(Path mc) throws IOException {
        Manifest manifest = readManifest(mc);
        Set<String> result = new HashSet<>();
        if (manifest != null) for (CachedFile f : manifest.files()) { resolve(mc, f.location()); result.add(f.location()); }
        return result;
    }

    static String algorithmOf(CachedFile f) throws IOException {
        if (f.hashType() == null || f.hashValue() == null) throw new Msg("missing checksum for " + f.location(), "нет контрольной суммы для " + f.location());
        String algorithm; int digits;
        if (f.hashType().equalsIgnoreCase("sha256")) { algorithm = "SHA-256"; digits = 64; }
        else if (f.hashType().equalsIgnoreCase("sha512")) { algorithm = "SHA-512"; digits = 128; }
        else throw new Msg("unsupported checksum " + f.hashType() + " for " + f.location(), "неподдерживаемая контрольная сумма " + f.hashType() + " для " + f.location());
        if (!f.hashValue().matches("[a-fA-F0-9]{" + digits + "}")) throw new Msg("invalid checksum for " + f.location(), "неверная контрольная сумма для " + f.location());
        return algorithm;
    }

    static String digest(Path file, CachedFile f) throws IOException {
        MessageDigest digest;
        try { digest = MessageDigest.getInstance(algorithmOf(f)); } catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
        try (InputStream in = Files.newInputStream(file)) {
            byte[] buf = new byte[65536]; int count; long read = 0;
            while ((count = in.read(buf)) != -1) {
                read += count;
                if (read > ENTRY_LIMIT) throw new Msg("a managed file is larger than 512 MiB: " + f.location(), "управляемый файл больше 512 МиБ: " + f.location());
                digest.update(buf, 0, count);
            }
        }
        return HexFormat.of().formatHex(digest.digest());
    }

    // Stock packwiz trusts its local cache when a managed file is still present.
    // Verify immutable assets ourselves; mutable player configuration is deliberately excluded.
    static void verifyCachedImmutable(Path mc, boolean repair) throws IOException {
        Manifest manifest = readManifest(mc);
        if (manifest == null) return;
        long total = 0;
        Path recovery = null;
        for (CachedFile f : manifest.files()) {
            if (!immutableCached(f.location())) continue;
            Path file = resolve(mc, f.location());
            algorithmOf(f);
            if (!Files.exists(file, LinkOption.NOFOLLOW_LINKS)) {
                if (repair) continue;
                throw new Msg("a managed file is missing after packwiz: " + f.location(), "после packwiz отсутствует файл " + f.location());
            }
            if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) throw new Msg("a managed path is not a regular file: " + f.location(), "управляемый путь не является обычным файлом: " + f.location());
            total += Files.size(file);
            if (total > TOTAL_LIMIT) throw new Msg("the managed files exceed 4 GiB", "управляемые файлы превышают 4 ГиБ");
            if (digest(file, f).equalsIgnoreCase(f.hashValue())) continue;
            if (!repair) throw new Msg("a managed file has a wrong checksum after packwiz: " + f.location(), "после packwiz неверная контрольная сумма файла " + f.location());
            if (recovery == null) recovery = resolve(mc, ".fallens/recovery/corrupt-" + stamp() + "-" + UUID.randomUUID().toString().substring(0, 8));
            Path target = resolve(recovery, f.location());
            Files.createDirectories(target.getParent());
            Files.move(file, target);
            info("a damaged file was moved aside for repair: " + f.location(), "повреждённый файл отложен для восстановления: " + f.location());
        }
    }

    static boolean immutableCached(String name) {
        return (name.startsWith("mods/") && name.endsWith(".jar")) || (SERVER && name.startsWith("world-neoforge/datapacks/fd-server-fixes/"));
    }

    // ---------------------------------------------------------------- network

    static URI uri(String value) throws IOException {
        try {
            URI u = URI.create(value.trim());
            boolean local = "http".equals(u.getScheme()) && Set.of("127.0.0.1", "localhost", "[::1]", "::1").contains(u.getHost());
            if (!("https".equals(u.getScheme()) || local) || u.getHost() == null || u.getUserInfo() != null || u.getFragment() != null) {
                throw new IllegalArgumentException();
            }
            return u;
        } catch (IllegalArgumentException e) {
            throw new Msg("an update URL must use HTTPS (HTTP is allowed only on loopback for tests)",
                "адрес обновлений должен использовать HTTPS (HTTP разрешён только на loopback для тестов)");
        }
    }

    static byte[] fetch(URI url, int limit) throws IOException {
        HttpRequest request = HttpRequest.newBuilder(url).timeout(Duration.ofSeconds(45))
            .header("User-Agent", "FallensDreamUpdater/" + UPDATER_VERSION).GET().build();
        HttpResponse<InputStream> response;
        try { response = Network.HTTP.send(request, HttpResponse.BodyHandlers.ofInputStream()); }
        catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new Msg("the download was interrupted", "загрузка прервана", e); }
        try (InputStream in = response.body()) {
            uri(response.uri().toString());
            if (response.statusCode() != 200) throw new HttpStatus(response.statusCode());
            FutureTask<byte[]> read = new FutureTask<>(() -> readLimited(in, limit));
            Thread worker = Thread.ofVirtual().name("fallens-http-body").start(read);
            try { return read.get(45, TimeUnit.SECONDS); }
            catch (TimeoutException e) { read.cancel(true); in.close(); throw new Msg("the download timed out", "истекло время загрузки", e); }
            catch (ExecutionException e) { Reason d = describe(e.getCause()); throw new Msg("the download failed (" + d.en() + ")", "загрузка не удалась (" + d.ru() + ")", e.getCause()); }
            catch (InterruptedException e) { Thread.currentThread().interrupt(); throw new Msg("the download was interrupted", "загрузка прервана", e); }
            finally { if (worker.isAlive()) worker.interrupt(); }
        }
    }

    // ---------------------------------------------------------------- small helpers

    static String required(Properties p, String key) throws IOException {
        String value = p.getProperty(key);
        if (value == null || value.isBlank()) throw new Msg("missing property " + key, "нет свойства " + key);
        return value.trim();
    }

    static String hashValue(String value) throws IOException {
        if (!value.matches("[a-fA-F0-9]{64}")) throw new Msg("invalid SHA-256 value", "неверное значение SHA-256");
        return value.toLowerCase(Locale.ROOT);
    }

    static String stamp() {
        return DateTimeFormatter.ofPattern("yyyyMMdd'T'HHmmss'Z'").withZone(ZoneOffset.UTC).format(Instant.now());
    }

    static String sha(byte[] data) { return HexFormat.of().formatHex(digest().digest(data)); }
    static MessageDigest digest() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException e) { throw new AssertionError(e); }
    }
    static String sha(Path path) throws IOException {
        try (InputStream in = Files.newInputStream(path)) { return sha(in); }
    }
    static String sha(InputStream in) throws IOException {
        MessageDigest hash = digest();
        byte[] buf = new byte[64 * 1024];
        int n;
        long size = 0;
        while ((n = in.read(buf)) != -1) {
            size += n;
            if (size > ENTRY_LIMIT) throw new Msg("a file exceeds the updater's 512 MiB per-file limit", "файл больше лимита обновлятора 512 МиБ");
            hash.update(buf, 0, n);
        }
        return HexFormat.of().formatHex(hash.digest());
    }

    static String pathName(String name) throws IOException {
        if (name.isEmpty() || name.startsWith("/") || name.contains("\\") || name.contains(":") ||
            name.chars().anyMatch(Character::isISOControl)) throw new Msg("unsafe path: " + name, "небезопасный путь: " + name);
        for (String part : name.split("/", -1)) {
            if (part.isEmpty() || part.equals(".") || part.equals("..") || part.endsWith(".") || part.endsWith(" ")) {
                throw new Msg("unsafe path: " + name, "небезопасный путь: " + name);
            }
        }
        return name;
    }

    static boolean safeName(String name) {
        try { pathName(name); return true; } catch (IOException e) { return false; }
    }

    static Path resolve(Path root, String name) throws IOException {
        Path result = root.resolve(pathName(name)).normalize();
        if (!result.startsWith(root)) throw new Msg("a path escaped its allowed folder", "путь вышел за пределы разрешённой папки");
        noLinks(result);
        return result;
    }

    // ---------------------------------------------------------------- links and junctions

    static Path ROOT, ROOT_REAL;
    static final Map<Path, Path> REAL_DIRS = new HashMap<>();

    /** The instance folder itself may be reached through a link; everything below it must be link-free. */
    static void initRoot(Path mc) throws IOException {
        Files.createDirectories(mc);
        ROOT = mc;
        ROOT_REAL = mc.toRealPath();
        REAL_DIRS.clear();
        REAL_DIRS.put(ROOT, ROOT_REAL);
    }

    static boolean sameEntry(Path actualReal, Path expectedParentReal, String name) {
        Path parent = actualReal.getParent(), fileName = actualReal.getFileName();
        if (parent == null || fileName == null || !parent.equals(expectedParentReal)) return false;
        return CASE_INSENSITIVE ? fileName.toString().equalsIgnoreCase(name) : fileName.toString().equals(name);
    }

    static Msg linkError(Path path) {
        return new Msg("the folder " + path + " is a symbolic link or junction; the updater does not read or write through links. Replace it with a regular folder",
            "папка " + path + " является символической ссылкой или junction; обновлятор не читает и не пишет через ссылки. Замените её обычной папкой");
    }

    /** Rejects symbolic links, Windows junctions/mount points and special files on the way from the instance folder to path. */
    static void noLinks(Path path) throws IOException {
        Path abs = path.toAbsolutePath().normalize();
        if (ROOT == null || !abs.startsWith(ROOT)) {
            if (Files.isSymbolicLink(abs)) throw linkError(abs);
            if (Files.exists(abs, LinkOption.NOFOLLOW_LINKS)) {
                BasicFileAttributes a = Files.readAttributes(abs, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
                if (!a.isRegularFile()) throw new Msg("not a regular file: " + abs, "не обычный файл: " + abs);
            }
            return;
        }
        Path current = ROOT, real = ROOT_REAL;
        for (Path part : ROOT.relativize(abs)) {
            String name = part.toString();
            if (name.isEmpty()) continue;
            current = current.resolve(name);
            Path known = REAL_DIRS.get(current);
            if (known != null) { real = known; continue; }
            if (Files.isSymbolicLink(current)) throw linkError(current);
            BasicFileAttributes a;
            try { a = Files.readAttributes(current, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS); }
            catch (NoSuchFileException e) { return; }
            if (a.isDirectory()) {
                Path actual = current.toRealPath();
                if (!sameEntry(actual, real, name)) throw linkError(current);
                REAL_DIRS.put(current, actual);
                real = actual;
            } else if (!a.isRegularFile()) {
                throw new Msg("special files are not allowed in managed paths: " + current, "специальные файлы недопустимы в управляемых путях: " + current);
            } else {
                return; // a regular file; nothing can exist below it
            }
        }
    }

    interface FileVisit { void file(Path file, String name) throws IOException; }

    /** Walks a folder without following links or junctions (they are skipped, never entered). */
    static void walkPlain(Path start, Path base, String prefix, FileVisit visit) throws IOException {
        if (!Files.exists(start, LinkOption.NOFOLLOW_LINKS)) return;
        Map<Path, Path> reals = new HashMap<>();
        Files.walkFileTree(start, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) throws IOException {
                Path parent = dir.getParent();
                Path parentReal = reals.containsKey(parent) ? reals.get(parent) : parent.toRealPath();
                Path actual = dir.toRealPath();
                if (!sameEntry(actual, parentReal, dir.getFileName().toString())) return FileVisitResult.SKIP_SUBTREE;
                reals.put(dir, actual);
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path file, BasicFileAttributes a) throws IOException {
                if (a.isRegularFile()) visit.file(file, prefix + base.relativize(file).toString().replace('\\', '/'));
                return FileVisitResult.CONTINUE;
            }
        });
    }

    // ---------------------------------------------------------------- properties and files

    static Properties load(Path path) throws IOException {
        noLinks(path);
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(path, StandardCharsets.UTF_8)) { p.load(r); }
        return p;
    }
    static void save(Path path, Properties p) throws IOException {
        noLinks(path);
        Files.createDirectories(path.getParent());
        Path temp = Files.createTempFile(path.getParent(), ".fallens-", ".tmp");
        try {
            try (Writer w = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) { p.store(w, "Fallen's Dream updater " + UPDATER_VERSION); }
            replace(temp, path);
        } finally { Files.deleteIfExists(temp); }
    }
    static void replace(Path source, Path destination) throws IOException {
        noLinks(destination);
        try { Files.move(source, destination, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
        catch (AtomicMoveNotSupportedException e) { Files.move(source, destination, StandardCopyOption.REPLACE_EXISTING); }
    }

    static boolean temporaryName(Path file) {
        String n = file.getFileName().toString();
        return n.startsWith(".fallens-") && n.endsWith(".tmp");
    }

    /** Leftovers of a killed save/restore/generation: only our own temporary names, in the folders we write to. */
    static void cleanTemporaryFiles(Path mc) throws IOException {
        for (String dir : List.of(".fallens", "mods")) {
            Path folder = resolve(mc, dir);
            if (!Files.isDirectory(folder, LinkOption.NOFOLLOW_LINKS)) continue;
            try (DirectoryStream<Path> files = Files.newDirectoryStream(folder)) {
                for (Path f : files) if (temporaryName(f) && Files.isRegularFile(f, LinkOption.NOFOLLOW_LINKS)) Files.deleteIfExists(f);
            }
        }
    }

    static boolean scoped(String name) {
        return FILES.contains(name) || TREES.stream().anyMatch(t -> name.startsWith(t + "/"));
    }

    static boolean linkable(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".jar") || n.endsWith(".zip");
    }

    /** Files whose presence changes the game (code, data, settings). Left-over packs and options are harmless. */
    static boolean affectsGame(String inner) {
        return !(inner.startsWith("resourcepacks/") || inner.startsWith("shaderpacks/") || inner.equals("options.txt"));
    }

    // ---------------------------------------------------------------- snapshot (format 2)

    /** Pack-managed files only: the packwiz manifest, our records and generated JARs. Player files are not copied. */
    static Map<String, Path> managedFiles(Path mc) throws IOException {
        Map<String, Path> files = new TreeMap<>();
        for (String f : FILES) addManaged(files, mc, f);
        for (String location : manifestLocations(mc)) addManaged(files, mc, location);
        addManaged(files, mc, GENERATED);
        addManaged(files, mc, CATALOG_TARGET);
        if (!SERVER) {
            for (String tree : List.of(".fallens/create", ".fallens/catalog")) {
                Path root = resolve(mc, tree);
                if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) continue;
                Files.walkFileTree(root, new SimpleFileVisitor<>() {
                    @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) throws IOException { noLinks(dir); return FileVisitResult.CONTINUE; }
                    @Override public FileVisitResult visitFile(Path file, BasicFileAttributes a) throws IOException {
                        noLinks(file);
                        if (!a.isRegularFile()) throw new Msg("special files are not allowed in " + tree, "специальные файлы недопустимы в " + tree);
                        files.put("mc/" + pathName(mc.relativize(file).toString().replace('\\', '/')), file);
                        return FileVisitResult.CONTINUE;
                    }
                });
            }
            Path mmc = mc.getParent().resolve("mmc-pack.json");
            noLinks(mmc);
            if (Files.exists(mmc, LinkOption.NOFOLLOW_LINKS)) files.put(MMC, mmc);
        }
        return files;
    }

    static void addManaged(Map<String, Path> files, Path mc, String name) throws IOException {
        Path path = resolve(mc, name);
        if (!Files.exists(path, LinkOption.NOFOLLOW_LINKS)) return;
        if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS)) throw new Msg("a managed path is not a regular file: " + name, "управляемый путь не является обычным файлом: " + name);
        files.put("mc/" + name, path);
    }

    /** Names of every regular file in the update folders before the update (player files included, never read). */
    static List<String> listing(Path mc) throws IOException {
        List<String> names = new ArrayList<>();
        for (String tree : TREES) {
            Path root = mc.resolve(tree);
            noLinksAbove(mc, root);
            walkPlain(root, mc, "mc/", (file, name) -> {
                names.add(name);
                if (names.size() > LISTING_LIMIT) throw new Msg("too many files in the update folders", "слишком много файлов в папках обновления");
            });
        }
        for (String f : FILES) if (Files.exists(mc.resolve(f), LinkOption.NOFOLLOW_LINKS)) names.add("mc/" + f);
        return names;
    }

    /** The parent folders of an update folder (for example world-neoforge/datapacks) must not be links. */
    static void noLinksAbove(Path mc, Path root) throws IOException {
        Path parent = root.getParent();
        if (parent != null && parent.startsWith(mc)) noLinks(parent);
    }

    static boolean tryLink(Path link, Path existing) {
        try { Files.createLink(link, existing); return true; }
        catch (IOException | UnsupportedOperationException | SecurityException e) {
            try { Files.deleteIfExists(link); } catch (IOException ignored) { }
            return false;
        }
    }

    static String copyHashing(Path source, Path destination) throws IOException {
        MessageDigest hash = digest();
        try (InputStream in = Files.newInputStream(source); OutputStream out = Files.newOutputStream(destination, StandardOpenOption.CREATE_NEW)) {
            byte[] buf = new byte[64 * 1024]; int n; long size = 0;
            while ((n = in.read(buf)) != -1) {
                size += n;
                if (size > ENTRY_LIMIT) throw new Msg("a managed file is larger than 512 MiB", "управляемый файл больше 512 МиБ");
                hash.update(buf, 0, n); out.write(buf, 0, n);
            }
        }
        return HexFormat.of().formatHex(hash.digest());
    }

    /**
     * Player files the new pack may overwrite (packwiz replaces a file without preserve at a path it starts to manage):
     * existing files at the exact paths of the new index and every file in a folder that holds one of its metafiles
     * (a metafile names its target file only inside the metafile, so its folder is protected as a whole).
     */
    static Map<String, Path> atRisk(Path mc, Targets targets, Set<String> managed) throws IOException {
        Map<String, Path> out = new TreeMap<>();
        if (targets == null) return out;
        for (String path : targets.exact()) {
            String name = "mc/" + path;
            if (!scoped(path) || managed.contains(name)) continue;
            Path file = resolve(mc, path);
            if (Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) out.put(name, file);
        }
        for (String dir : targets.dirs()) {
            Path folder = dir.isEmpty() ? mc : resolve(mc, dir);
            if (!Files.isDirectory(folder, LinkOption.NOFOLLOW_LINKS)) continue;
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(folder)) {
                for (Path file : stream) {
                    String rel = (dir.isEmpty() ? "" : dir + "/") + file.getFileName();
                    if (!safeName(rel) || !scoped(rel) || temporaryName(file) || managed.contains("mc/" + rel)) continue;
                    if (Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) out.putIfAbsent("mc/" + rel, file);
                }
            }
        }
        return out;
    }

    static final long SUPERSET_COPY_LIMIT = 16L * 1024 * 1024;

    static Path snapshot(Path mc, Targets targets) throws IOException {
        Map<String, Path> files = managedFiles(mc);
        Map<String, Path> user = atRisk(mc, targets, files.keySet());
        List<String> names = listing(mc);
        Path root = resolve(mc, ".fallens/backups");
        Files.createDirectories(root);
        Path backup = Files.createTempDirectory(root, stamp() + "-");
        try {
            Properties p = new Properties();
            p.setProperty("format", "fallens-backup-2");
            p.setProperty("created.utc", Instant.now().toString());
            p.setProperty("updater", UPDATER_VERSION);
            int i = 0, linked = 0, userCount = 0, skipped = 0;
            long copied = 0;
            Map<String, Path> all = new TreeMap<>(files);
            all.putAll(user);
            for (Map.Entry<String, Path> entry : all.entrySet()) {
                String name = entry.getKey();
                Path source = entry.getValue();
                boolean isUser = user.containsKey(name);
                boolean exact = !isUser || targets.exact().contains(name.substring(3));
                long size = Files.size(source);
                if (size > ENTRY_LIMIT) {
                    if (!exact) { skipped++; continue; }
                    throw new Msg("the file " + name + " is larger than 512 MiB", "файл " + name + " больше 512 МиБ");
                }
                Path stored = resolve(backup, "files/" + name);
                Files.createDirectories(stored.getParent());
                String hash;
                if (linkable(name) && tryLink(stored, source)) {
                    hash = sha(stored);
                    p.setProperty("entry." + i + ".mode", "link");
                    linked++;
                } else {
                    // Next to a metafile only the file with the metafile's name is really at risk: skip big copies there.
                    if (!exact && size > SUPERSET_COPY_LIMIT) { skipped++; continue; }
                    copied += size;
                    if (copied > SNAPSHOT_COPY_LIMIT) throw new Msg("the files to copy into the backup exceed 2 GiB", "файлы для копирования в резервную копию превышают 2 ГиБ");
                    hash = copyHashing(source, stored);
                    p.setProperty("entry." + i + ".mode", "copy");
                }
                p.setProperty("entry." + i + ".path", name);
                p.setProperty("entry." + i + ".sha256", hash);
                p.setProperty("entry." + i + ".kind", isUser ? "user" : "managed");
                if (isUser) userCount++;
                i++;
            }
            p.setProperty("count", Integer.toString(i));
            p.setProperty("linked", Integer.toString(linked));
            p.setProperty("user.count", Integer.toString(userCount));
            p.setProperty("user.skipped", Integer.toString(skipped));
            p.setProperty("copied.bytes", Long.toString(copied));
            p.setProperty("listing.count", Integer.toString(names.size()));
            for (int j = 0; j < names.size(); j++) p.setProperty("listing." + j, names.get(j));
            p.setProperty("complete", "true");
            save(backup.resolve("manifest.properties"), p);
            return backup;
        } catch (IOException | RuntimeException e) {
            try { deleteTree(mc, backup); } catch (IOException cleanup) { e.addSuppressed(cleanup); }
            throw e;
        }
    }

    static Path validateBackupLocation(Path mc, Path candidate) throws IOException {
        Path base = resolve(mc, ".fallens/backups");
        Path backup = candidate.toAbsolutePath().normalize();
        noLinks(backup);
        if (!backup.startsWith(base) || backup.equals(base) || !Files.isDirectory(backup, LinkOption.NOFOLLOW_LINKS)) {
            throw new Msg("the backup must be a folder inside this instance's .fallens/backups/", "резервная копия должна быть папкой внутри .fallens/backups/ этого профиля");
        }
        return backup;
    }

    static Path backupTarget(Path mc, String name) throws IOException {
        pathName(name);
        if (!SERVER && name.equals(MMC)) {
            Path p = mc.getParent().resolve("mmc-pack.json"); noLinks(p); return p;
        }
        if (!name.startsWith("mc/") || !scoped(name.substring(3))) throw new Msg("a backup entry is outside the managed scope: " + name, "запись копии вне управляемой области: " + name);
        return resolve(mc, name.substring(3));
    }

    static int count(Properties p, String key) throws IOException {
        try { int value = Integer.parseInt(required(p, key)); if (value < 0 || value > LISTING_LIMIT) throw new NumberFormatException(); return value; }
        catch (NumberFormatException e) { throw new Msg("invalid backup entry count", "неверное число записей копии"); }
    }

    /**
     * manual=true (--rollback to an older backup): only files owned by the currently installed pack version are
     * moved away; files the game or the player created since that backup (generated configs, own mods) stay.
     * manual=false (an update of this run or an interrupted one): the listing is fresh, every new file is moved.
     */
    static void restoreAny(Path mc, Path backup, boolean recordLegacyAfter, boolean manual) throws IOException {
        backup = validateBackupLocation(mc, backup);
        Properties manifest = load(backup.resolve("manifest.properties"));
        String format = manifest.getProperty("format");
        if ("fallens-backup-2".equals(format)) restoreV2(mc, backup, manifest, manual);
        else if ("fallens-backup-1".equals(format)) {
            if (recordLegacyAfter) legacyRecordAfter(mc, backup);
            legacyRestore(mc, backup, manifest);
        } else throw new Msg("unsupported backup format", "неподдерживаемый формат резервной копии");
    }

    static Path newDir(Path mc, String base, String label) throws IOException {
        Path root = resolve(mc, base);
        Files.createDirectories(root);
        return Files.createTempDirectory(root, label + "-");
    }

    static void restoreV2(Path mc, Path backup, Properties manifest, boolean manual) throws IOException {
        if (!"true".equals(manifest.getProperty("complete"))) throw new Msg("the backup is incomplete", "резервная копия неполная");
        Map<String, String> before = new LinkedHashMap<>();
        int count = count(manifest, "count");
        for (int i = 0; i < count; i++) {
            String name = required(manifest, "entry." + i + ".path");
            backupTarget(mc, name);
            String hash = hashValue(required(manifest, "entry." + i + ".sha256"));
            if (before.put(name, hash) != null) throw new Msg("duplicate backup entry", "повторная запись в копии");
            boolean user = "user".equals(manifest.getProperty("entry." + i + ".kind"));
            Path stored = resolve(backup, "files/" + name);
            // Validate the whole backup BEFORE moving, deleting or overwriting any current file.
            if (!Files.isRegularFile(stored, LinkOption.NOFOLLOW_LINKS) || !sha(stored).equals(hash)) {
                // A player's file kept as a hard link and later edited in place: the live file is that same newer
                // data, there is nothing older to put back. Pack-managed entries must be intact.
                if (user) { before.remove(name); continue; }
                throw new Msg("the backup entry " + name + " is missing or damaged; restoration was not started",
                    "запись копии " + name + " отсутствует или повреждена; восстановление не начиналось");
            }
        }
        Set<String> listed = new HashSet<>();
        for (int i = 0, n = count(manifest, "listing.count"); i < n; i++) listed.add(required(manifest, "listing." + i));
        Set<String> owned = null;
        if (manual) {
            owned = manifestLocations(mc);
            owned.add(GENERATED);
            owned.add(CATALOG_TARGET);
        }
        Set<String> ownedNow = owned;

        // 1. Files that appeared during the update leave the active folders. Downloads are kept for the next attempt.
        List<Path> created = new ArrayList<>();
        List<String> createdNames = new ArrayList<>();
        for (String tree : TREES) {
            Path root = mc.resolve(tree);
            noLinksAbove(mc, root);
            walkPlain(root, mc, "mc/", (file, name) -> {
                if (before.containsKey(name) || listed.contains(name)) return;
                if (temporaryName(file)) { Files.deleteIfExists(file); return; }
                if (ownedNow != null && !ownedNow.contains(name.substring(3))) return; // made by the game or the player
                created.add(file); createdNames.add(name);
            });
        }
        for (String f : FILES) {
            String name = "mc/" + f;
            Path path = resolve(mc, f);
            if (!Files.isRegularFile(path, LinkOption.NOFOLLOW_LINKS) || before.containsKey(name) || listed.contains(name)) continue;
            if (f.equals("packwiz.json") || f.equals(".fallens/state.properties")) Files.delete(path); // records of the failed update
            else { created.add(path); createdNames.add(name); }
        }
        Path cache = resolve(mc, ".fallens/download-cache");
        int kept = 0;
        for (int i = 0; i < created.size(); i++) {
            String inner = createdNames.get(i).substring(3);
            if (!safeName(inner)) {
                warn("a file created during the update has an unusual name and stays in place: " + inner, "файл, созданный во время обновления, с необычным именем оставлен на месте: " + inner);
                continue;
            }
            Path destination = resolve(cache, inner);
            Files.createDirectories(destination.getParent());
            replace(created.get(i), destination);
            kept++;
        }

        // 2. Managed files return to their exact previous bytes.
        Path recovery = null;
        for (Map.Entry<String, String> entry : before.entrySet()) {
            String name = entry.getKey();
            Path target = backupTarget(mc, name);
            Path storedCopy = resolve(backup, "files/" + name);
            if (Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) && Files.isSameFile(target, storedCopy)) continue; // untouched hard link
            if (Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) && sha(target).equals(entry.getValue())) continue;
            if (Files.exists(target, LinkOption.NOFOLLOW_LINKS)) {
                if (!Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) throw new Msg("cannot restore over a non-file: " + name, "нельзя восстановить поверх не-файла: " + name);
                if (name.equals("mc/packwiz.json") || name.equals("mc/.fallens/state.properties")) {
                    Files.delete(target); // our own records of the failed update, nothing to preserve
                } else if (name.startsWith("mc/") && linkable(name)) {
                    Path destination = resolve(cache, name.substring(3));
                    Files.createDirectories(destination.getParent());
                    replace(target, destination);
                    kept++;
                } else {
                    if (recovery == null) recovery = newDir(mc, ".fallens/recovery-files", backup.getFileName().toString());
                    Path destination = resolve(recovery, name);
                    Files.createDirectories(destination.getParent());
                    replace(target, destination);
                }
            }
            Path stored = resolve(backup, "files/" + name);
            Files.createDirectories(target.getParent());
            Path temp = Files.createTempFile(target.getParent(), ".fallens-restore-", ".tmp");
            try {
                Files.copy(stored, temp, StandardCopyOption.REPLACE_EXISTING);
                if (!sha(temp).equals(entry.getValue())) throw new Msg("a restored file does not match its backup: " + name, "восстановленный файл не совпадает с копией: " + name);
                replace(temp, target);
            } finally { Files.deleteIfExists(temp); }
        }
        if (kept > 0) info(kept + " file(s) from the unfinished update were kept in .fallens/download-cache for the next attempt.",
            "файлы незавершённого обновления (" + kept + ") сохранены в .fallens/download-cache для следующей попытки.");
        if (recovery != null) {
            String shown = mc.relativize(recovery).toString();
            info("settings changed during the update were preserved in " + shown, "настройки, изменённые во время обновления, сохранены в " + shown);
        }
    }

    /**
     * packwiz deletes every file that left the index, preserve=true included. A setting file that the player had
     * changed (its bytes differ from the pack's recorded hash) is put back from the backup and stays unmanaged;
     * an unchanged pack default stays deleted, as the pack intended.
     */
    static void keepPlayerSettings(Path mc, Manifest before, Path backup) throws IOException {
        if (before == null) return;
        Set<String> now = manifestLocations(mc);
        Properties manifest = load(backup.resolve("manifest.properties"));
        Map<String, String> stored = new HashMap<>();
        for (int i = 0, n = count(manifest, "count"); i < n; i++) stored.put(required(manifest, "entry." + i + ".path"), required(manifest, "entry." + i + ".sha256"));
        List<String> kept = new ArrayList<>();
        for (CachedFile f : before.files()) {
            String location = f.location();
            if (now.contains(location) || immutableCached(location) || linkable(location) || f.hashValue() == null || !"sha256".equalsIgnoreCase(f.hashType())) continue;
            Path target = resolve(mc, location);
            if (Files.exists(target, LinkOption.NOFOLLOW_LINKS)) continue;
            String saved = stored.get("mc/" + location);
            if (saved == null || saved.equalsIgnoreCase(f.hashValue())) continue;
            Path source = resolve(backup, "files/mc/" + location);
            Files.createDirectories(target.getParent());
            Path temp = Files.createTempFile(target.getParent(), ".fallens-restore-", ".tmp");
            try {
                Files.copy(source, temp, StandardCopyOption.REPLACE_EXISTING);
                if (!sha(temp).equals(saved)) throw new Msg("a kept setting file does not match its backup: " + location, "сохраняемый файл настроек не совпадает с копией: " + location);
                replace(temp, target);
            } finally { Files.deleteIfExists(temp); }
            kept.add(location);
        }
        if (!kept.isEmpty()) info("kept your changed setting file(s) that the new version no longer manages: " + String.join(", ", kept),
            "сохранены ваши изменённые файлы настроек, которыми новая версия больше не управляет: " + String.join(", ", kept));
    }

    /** After a successful update: a player's file that the new pack replaced is kept in recovery-files, as 0.2 kept it. */
    static void keepReplacedPlayerFiles(Path mc, Path backup) throws IOException {
        Properties manifest = load(backup.resolve("manifest.properties"));
        Path recovery = null;
        List<String> kept = new ArrayList<>();
        for (int i = 0, n = count(manifest, "count"); i < n; i++) {
            if (!"user".equals(manifest.getProperty("entry." + i + ".kind"))) continue;
            String name = required(manifest, "entry." + i + ".path"), hash = hashValue(required(manifest, "entry." + i + ".sha256"));
            Path stored = resolve(backup, "files/" + name);
            if (!Files.isRegularFile(stored, LinkOption.NOFOLLOW_LINKS)) continue;
            Path target = backupTarget(mc, name);
            if (Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) && (Files.isSameFile(target, stored) || sha(target).equals(hash))) continue;
            if (!sha(stored).equals(hash)) continue;
            if (recovery == null) recovery = newDir(mc, ".fallens/recovery-files", "replaced-by-pack-" + stamp());
            Path destination = resolve(recovery, name);
            Files.createDirectories(destination.getParent());
            if (!(linkable(name) && tryLink(destination, stored))) Files.copy(stored, destination);
            kept.add(name.substring(3));
        }
        if (!kept.isEmpty()) {
            String shown = mc.relativize(recovery).toString(), list = String.join(", ", kept);
            info("the new version replaced your own file(s) " + list + "; your copies are kept in " + shown,
                 "новая версия заменила ваши файлы " + list + "; ваши копии сохранены в " + shown);
        }
    }

    // ---------------------------------------------------------------- the new index (paths the pack will manage)

    record Targets(Set<String> exact, Set<String> dirs) {}

    static Targets indexTargets(URI packUrl, byte[] packBytes) throws IOException {
        MiniToml pack = MiniToml.parse(packBytes);
        String file = pathName(pack.value("index.file"));
        byte[] index = fetch(resolveRelative(packUrl, file), 16 * 1024 * 1024);
        if (!digestHex(pack.value("index.hash-format"), index).equalsIgnoreCase(pack.value("index.hash"))) {
            throw new Msg("the downloaded file list does not match pack.toml", "скачанный список файлов не совпадает с pack.toml");
        }
        return targetsOf(file, index);
    }

    /** Paths in index.toml are relative to its folder; a metafile names its target only inside, so its folder counts. */
    static Targets targetsOf(String indexFile, byte[] index) throws IOException {
        String base = indexFile.contains("/") ? indexFile.substring(0, indexFile.lastIndexOf('/') + 1) : "";
        Set<String> exact = new HashSet<>(), dirs = new HashSet<>();
        for (Map<String, String> entry : MiniToml.parse(index).arrays.getOrDefault("files", List.of())) {
            String file = entry.get("file");
            if (file == null) throw new Msg("an entry of index.toml has no file", "в index.toml есть запись без file");
            String path = pathName(base + file);
            if ("true".equals(entry.get("metafile"))) dirs.add(path.contains("/") ? path.substring(0, path.lastIndexOf('/')) : "");
            else exact.add(path);
        }
        return new Targets(exact, dirs);
    }

    static String digestHex(String format, byte[] data) throws IOException {
        String algorithm = switch (format.toLowerCase(Locale.ROOT)) {
            case "sha256" -> "SHA-256"; case "sha512" -> "SHA-512"; case "sha1" -> "SHA-1"; case "md5" -> "MD5";
            default -> throw new Msg("unsupported index hash format " + format, "неподдерживаемый формат хеша индекса " + format);
        };
        try { return HexFormat.of().formatHex(MessageDigest.getInstance(algorithm).digest(data)); }
        catch (NoSuchAlgorithmException e) { throw new AssertionError(e); }
    }

    static URI resolveRelative(URI base, String relative) throws IOException {
        StringJoiner encoded = new StringJoiner("/");
        for (String part : pathName(relative).split("/")) encoded.add(URLEncoder.encode(part, StandardCharsets.UTF_8).replace("+", "%20"));
        return uri(base.resolve(encoded.toString()).toString());
    }

    /**
     * Minimal TOML reader for packwiz pack.toml / index.toml: tables, arrays of tables, basic and literal strings,
     * booleans, numbers and dates. Arrays, inline tables and multi-line strings are read over and kept raw.
     */
    static final class MiniToml {
        final Map<String, String> values = new LinkedHashMap<>();
        final Map<String, List<Map<String, String>>> arrays = new LinkedHashMap<>();
        private final String s;
        private int p;
        private MiniToml(String s) { this.s = s; }

        String value(String key) throws Msg {
            String v = values.get(key);
            if (v == null) throw new Msg("pack.toml has no " + key, "в pack.toml нет " + key);
            return v;
        }

        static MiniToml parse(byte[] bytes) throws IOException {
            String text = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
            if (text.startsWith("﻿")) text = text.substring(1);
            MiniToml t = new MiniToml(text);
            t.document();
            return t;
        }

        private Msg bad() { return new Msg("unreadable TOML near character " + p, "нечитаемый TOML около символа " + p); }
        private void ws() { while (p < s.length() && (s.charAt(p) == ' ' || s.charAt(p) == '\t')) p++; }
        private void endOfLine() throws Msg {
            ws();
            if (p < s.length() && s.charAt(p) == '#') while (p < s.length() && s.charAt(p) != '\n') p++;
            if (p < s.length() && s.charAt(p) == '\r') p++;
            if (p < s.length()) { if (s.charAt(p) != '\n') throw bad(); p++; }
        }

        private void document() throws IOException {
            String table = "";
            Map<String, String> row = null;
            while (p < s.length()) {
                ws();
                if (p >= s.length()) break;
                char c = s.charAt(p);
                if (c == '\r' || c == '\n' || c == '#') { endOfLine(); continue; }
                if (c == '[') {
                    boolean array = s.startsWith("[[", p);
                    p += array ? 2 : 1;
                    ws();
                    String name = key();
                    ws();
                    if (!s.startsWith(array ? "]]" : "]", p)) throw bad();
                    p += array ? 2 : 1;
                    endOfLine();
                    if (array) { row = new LinkedHashMap<>(); arrays.computeIfAbsent(name, k -> new ArrayList<>()).add(row); }
                    else { table = name; row = null; }
                    continue;
                }
                String k = key();
                ws();
                if (p >= s.length() || s.charAt(p) != '=') throw bad();
                p++;
                ws();
                String v = value();
                endOfLine();
                if (row != null) row.put(k, v);
                else values.put(table.isEmpty() ? k : table + "." + k, v);
            }
        }

        private String key() throws IOException {
            StringBuilder out = new StringBuilder();
            while (true) {
                ws();
                if (p >= s.length()) throw bad();
                char c = s.charAt(p);
                if (c == '"') out.append(basic());
                else if (c == '\'') out.append(literal());
                else {
                    int start = p;
                    while (p < s.length() && (Character.isLetterOrDigit(s.charAt(p)) || s.charAt(p) == '_' || s.charAt(p) == '-')) p++;
                    if (start == p) throw bad();
                    out.append(s, start, p);
                }
                ws();
                if (p < s.length() && s.charAt(p) == '.') { out.append('.'); p++; continue; }
                return out.toString();
            }
        }

        private String value() throws IOException {
            if (p >= s.length()) throw bad();
            if (s.startsWith("\"\"\"", p)) return skipUntil("\"\"\"", true);
            if (s.startsWith("'''", p)) return skipUntil("'''", false);
            char c = s.charAt(p);
            if (c == '"') return basic();
            if (c == '\'') return literal();
            if (c == '[' || c == '{') return bracketed();
            int start = p;
            while (p < s.length() && " \t\r\n#".indexOf(s.charAt(p)) < 0) p++;
            String token = s.substring(start, p);
            if (!token.matches("[A-Za-z0-9_+.:-]+")) throw bad();
            return token;
        }

        private String basic() throws IOException {
            p++;
            StringBuilder out = new StringBuilder();
            while (p < s.length()) {
                char c = s.charAt(p++);
                if (c == '"') return out.toString();
                if (c == '\n') throw bad();
                if (c != '\\') { out.append(c); continue; }
                if (p >= s.length()) throw bad();
                char e = s.charAt(p++);
                switch (e) {
                    case 'b' -> out.append('\b'); case 't' -> out.append('\t'); case 'n' -> out.append('\n');
                    case 'f' -> out.append('\f'); case 'r' -> out.append('\r'); case '"' -> out.append('"'); case '\\' -> out.append('\\');
                    case 'u', 'U' -> {
                        int len = e == 'u' ? 4 : 8;
                        if (p + len > s.length()) throw bad();
                        try { out.appendCodePoint(Integer.parseInt(s.substring(p, p + len), 16)); }
                        catch (IllegalArgumentException x) { throw bad(); }
                        p += len;
                    }
                    default -> throw bad();
                }
            }
            throw bad();
        }

        private String literal() throws IOException {
            int start = ++p;
            while (p < s.length() && s.charAt(p) != '\'' && s.charAt(p) != '\n') p++;
            if (p >= s.length() || s.charAt(p) != '\'') throw bad();
            return s.substring(start, p++);
        }

        private String skipUntil(String close, boolean escapes) throws IOException {
            int start = p;
            p += 3;
            while (p < s.length()) {
                if (escapes && s.charAt(p) == '\\') { p += 2; continue; }
                if (s.startsWith(close, p)) { p += 3; while (p < s.length() && s.charAt(p) == close.charAt(0)) p++; return s.substring(start, p); }
                p++;
            }
            throw bad();
        }

        private String bracketed() throws IOException {
            int start = p, depth = 0;
            while (p < s.length()) {
                char c = s.charAt(p);
                if (c == '"' || c == '\'') {
                    if (s.startsWith("\"\"\"", p)) skipUntil("\"\"\"", true);
                    else if (s.startsWith("'''", p)) skipUntil("'''", false);
                    else if (c == '"') basic(); else literal();
                    continue;
                }
                if (c == '#') { while (p < s.length() && s.charAt(p) != '\n') p++; continue; }
                if (c == '[' || c == '{') depth++;
                if (c == ']' || c == '}') { depth--; if (depth == 0) { p++; return s.substring(start, p); } }
                p++;
            }
            throw bad();
        }
    }

    // ---------------------------------------------------------------- resume

    /** Moves files kept from an earlier attempt back where they were; packwiz validates them by hash. */
    static List<String> resumeDownloads(Path mc) throws IOException {
        Path cache = resolve(mc, ".fallens/download-cache");
        if (!Files.isDirectory(cache, LinkOption.NOFOLLOW_LINKS)) return List.of();
        List<Path> files = new ArrayList<>();
        List<String> names = new ArrayList<>();
        walkPlain(cache, cache, "", (file, name) -> { files.add(file); names.add(name); });
        List<String> resumed = new ArrayList<>();
        for (int i = 0; i < files.size(); i++) {
            String inner = names.get(i);
            if (!safeName(inner) || !scoped(inner) || FILES.contains(inner) && !inner.equals("options.txt")) continue;
            Path target = resolve(mc, inner);
            if (Files.exists(target, LinkOption.NOFOLLOW_LINKS)) continue;
            Files.createDirectories(target.getParent());
            replace(files.get(i), target);
            resumed.add(inner);
        }
        if (!resumed.isEmpty()) info("reusing " + resumed.size() + " file(s) kept from an earlier attempt; packwiz checks them by hash.",
            "использую файлы, сохранённые с прошлой попытки (" + resumed.size() + "); packwiz проверит их по хешу.");
        return resumed;
    }

    /** After a successful update: reused files the new pack does not own leave the game folders; the cache is emptied. */
    static void settleResumed(Path mc, List<String> resumed) throws IOException {
        Set<String> owned = manifestLocations(mc);
        owned.add(GENERATED);
        owned.add(CATALOG_TARGET);
        Path recovery = null;
        int moved = 0;
        for (String inner : resumed) {
            if (owned.contains(inner) || !affectsGame(inner)) continue;
            Path file = resolve(mc, inner);
            if (!Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) continue;
            if (recovery == null) recovery = newDir(mc, ".fallens/recovery-files", "not-in-pack-" + stamp());
            Path destination = resolve(recovery, "mc/" + inner);
            Files.createDirectories(destination.getParent());
            replace(file, destination);
            moved++;
        }
        Path cache = resolve(mc, ".fallens/download-cache");
        if (Files.isDirectory(cache, LinkOption.NOFOLLOW_LINKS)) {
            List<Path> files = new ArrayList<>();
            List<String> names = new ArrayList<>();
            walkPlain(cache, cache, "", (file, name) -> { files.add(file); names.add(name); });
            for (int i = 0; i < files.size(); i++) {
                String inner = names.get(i);
                Path target = safeName(inner) && scoped(inner) ? resolve(mc, inner) : null;
                if (target != null && Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) && Files.size(target) == Files.size(files.get(i))
                    && sha(target).equals(sha(files.get(i)))) {
                    Files.delete(files.get(i));
                    continue;
                }
                if (!safeName(inner)) { Files.delete(files.get(i)); continue; }
                if (recovery == null) recovery = newDir(mc, ".fallens/recovery-files", "not-in-pack-" + stamp());
                Path destination = resolve(recovery, "mc/" + inner);
                Files.createDirectories(destination.getParent());
                replace(files.get(i), destination);
                moved++;
            }
            deleteTree(mc, cache);
        }
        if (moved > 0) {
            String shown = mc.relativize(recovery).toString();
            info(moved + " file(s) that the new version does not use were moved to " + shown,
                "файлы, которые новая версия не использует (" + moved + "), перенесены в " + shown);
        }
    }

    // ---------------------------------------------------------------- retention

    static boolean completeBackup(Path dir) {
        try {
            Path manifest = dir.resolve("manifest.properties");
            if (!Files.isRegularFile(manifest, LinkOption.NOFOLLOW_LINKS)) return false;
            Properties p = new Properties();
            try (Reader r = Files.newBufferedReader(manifest, StandardCharsets.UTF_8)) { p.load(r); }
            if ("fallens-backup-2".equals(p.getProperty("format"))) return "true".equals(p.getProperty("complete"));
            return "fallens-backup-1".equals(p.getProperty("format")) && p.getProperty("snapshot.sha256") != null
                && Files.isRegularFile(dir.resolve("snapshot.zip"), LinkOption.NOFOLLOW_LINKS);
        } catch (IOException | IllegalArgumentException e) { return false; }
    }

    /** Retention never blocks a launch: a failure is reported and retried next time. */
    static void safePrune(Path mc) {
        try { prune(mc); }
        catch (Exception e) {
            Reason d = describe(e);
            warn("old backups could not be cleaned up (" + d.en() + "); this does not affect the game.",
                 "старые резервные копии не удалось очистить (" + d.ru() + "); на игру это не влияет.");
        }
    }

    static void prune(Path mc) throws IOException {
        Path pendingBackup = null;
        Path pending = resolve(mc, ".fallens/pending.properties");
        if (Files.exists(pending, LinkOption.NOFOLLOW_LINKS)) {
            String b = load(pending).getProperty("backup");
            if (b != null) pendingBackup = mc.resolve(b).toAbsolutePath().normalize();
        }
        Path backups = resolve(mc, ".fallens/backups");
        int deleted = 0;
        if (Files.isDirectory(backups, LinkOption.NOFOLLOW_LINKS)) {
            List<Path> complete = new ArrayList<>();
            List<Path> entries = new ArrayList<>();
            try (DirectoryStream<Path> stream = Files.newDirectoryStream(backups)) { for (Path d : stream) entries.add(d); }
            for (Path d : entries) {
                if (d.equals(pendingBackup)) continue;
                if (!Files.isDirectory(d, LinkOption.NOFOLLOW_LINKS)) continue;
                if (completeBackup(d)) complete.add(d);
                else { deleteTree(mc, d); deleted++; }
            }
            complete.sort(Comparator.comparing((Path d) -> d.getFileName().toString()).reversed());
            for (int i = KEEP_BACKUPS; i < complete.size(); i++) { deleteTree(mc, complete.get(i)); deleted++; }
        }
        Path cache = resolve(mc, ".fallens/download-cache");
        if (Files.isDirectory(cache, LinkOption.NOFOLLOW_LINKS)) {
            FileTime limit = FileTime.from(Instant.now().minus(KEEP_RECOVERY));
            List<Path> old = new ArrayList<>();
            List<String> names = new ArrayList<>();
            walkPlain(cache, cache, "", (file, name) -> {
                if (Files.getLastModifiedTime(file, LinkOption.NOFOLLOW_LINKS).compareTo(limit) < 0) { old.add(file); names.add(name); }
            });
            Path recovery = null;
            for (int i = 0; i < old.size(); i++) {
                if (!safeName(names.get(i))) { Files.delete(old.get(i)); continue; }
                if (recovery == null) recovery = newDir(mc, ".fallens/recovery-files", "old-download-cache-" + stamp());
                Path destination = resolve(recovery, "mc/" + names.get(i));
                Files.createDirectories(destination.getParent());
                replace(old.get(i), destination);
            }
        }
        deleted += pruneFolder(mc, ".fallens/recovery");
        deleted += pruneFolder(mc, ".fallens/recovery-files");
        if (deleted > 0) info("removed " + deleted + " old backup/recovery folder(s); the last " + KEEP_BACKUPS + " backups are kept.",
            "удалены старые резервные копии и папки восстановления (" + deleted + "); последние " + KEEP_BACKUPS + " копии сохранены.");
    }

    /** Keeps entries younger than 14 days and at most 1 GiB in total (newest first). */
    static int pruneFolder(Path mc, String folder) throws IOException {
        Path root = resolve(mc, folder);
        if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS)) return 0;
        List<Path> entries = new ArrayList<>();
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(root)) { for (Path p : stream) entries.add(p); }
        Map<Path, FileTime> times = new HashMap<>();
        for (Path p : entries) times.put(p, Files.getLastModifiedTime(p, LinkOption.NOFOLLOW_LINKS));
        entries.sort(Comparator.comparing((Path p) -> times.get(p)).reversed());
        FileTime limit = FileTime.from(Instant.now().minus(KEEP_RECOVERY));
        long total = 0;
        int deleted = 0;
        for (Path p : entries) {
            long size = treeSize(p);
            if (times.get(p).compareTo(limit) < 0 || total + size > RECOVERY_LIMIT) { deleteTree(mc, p); deleted++; }
            else total += size;
        }
        return deleted;
    }

    static long treeSize(Path start) throws IOException {
        long[] size = {0};
        if (Files.isRegularFile(start, LinkOption.NOFOLLOW_LINKS)) return Files.size(start);
        walkPlain(start, start, "", (file, name) -> size[0] += Files.size(file));
        return size[0];
    }

    /** Deletes a folder inside .fallens without ever entering a link or junction (the link itself is removed). */
    static void deleteTree(Path mc, Path start) throws IOException {
        Path fallens = resolve(mc, ".fallens");
        Path target = start.toAbsolutePath().normalize();
        if (!target.startsWith(fallens) || target.equals(fallens)) throw new Msg("refusing to delete outside .fallens: " + target, "отказ удалять вне .fallens: " + target);
        if (!Files.exists(target, LinkOption.NOFOLLOW_LINKS)) return;
        if (!Files.isDirectory(target, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(target)) { deleteFile(target); return; }
        Map<Path, Path> reals = new HashMap<>();
        Files.walkFileTree(target, new SimpleFileVisitor<>() {
            @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) throws IOException {
                Path parent = dir.getParent();
                Path parentReal = reals.containsKey(parent) ? reals.get(parent) : parent.toRealPath();
                Path actual = dir.toRealPath();
                if (!sameEntry(actual, parentReal, dir.getFileName().toString())) { Files.delete(dir); return FileVisitResult.SKIP_SUBTREE; }
                reals.put(dir, actual);
                return FileVisitResult.CONTINUE;
            }
            @Override public FileVisitResult visitFile(Path file, BasicFileAttributes a) throws IOException { deleteFile(file); return FileVisitResult.CONTINUE; }
            @Override public FileVisitResult postVisitDirectory(Path dir, IOException e) throws IOException {
                if (e != null) throw e;
                Files.delete(dir);
                return FileVisitResult.CONTINUE;
            }
        });
    }

    static void deleteFile(Path file) throws IOException {
        try { Files.delete(file); }
        catch (AccessDeniedException e) {
            DosFileAttributeView dos = Files.getFileAttributeView(file, DosFileAttributeView.class, LinkOption.NOFOLLOW_LINKS);
            if (dos == null) throw e;
            dos.setReadOnly(false);
            Files.delete(file);
        }
    }

    // ---------------------------------------------------------------- legacy backups (format 1, launcher 0.2)

    static Map<String, Path> legacyInventory(Path mc) throws IOException {
        Map<String, Path> files = new TreeMap<>();
        for (String tree : TREES) {
            Path root = resolve(mc, tree);
            if (!Files.exists(root, LinkOption.NOFOLLOW_LINKS)) continue;
            Files.walkFileTree(root, new SimpleFileVisitor<>() {
                @Override public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes a) throws IOException { noLinks(dir); return FileVisitResult.CONTINUE; }
                @Override public FileVisitResult visitFile(Path file, BasicFileAttributes a) throws IOException {
                    noLinks(file);
                    if (!a.isRegularFile()) throw new Msg("managed paths must contain regular files only", "управляемые пути должны содержать только обычные файлы");
                    files.put("mc/" + pathName(mc.relativize(file).toString().replace('\\', '/')), file);
                    return FileVisitResult.CONTINUE;
                }
            });
        }
        for (String f : FILES) {
            Path file = resolve(mc, f);
            if (Files.isRegularFile(file, LinkOption.NOFOLLOW_LINKS)) files.put("mc/" + f, file);
        }
        if (!SERVER) {
            Path mmc = mc.getParent().resolve("mmc-pack.json"); noLinks(mmc);
            if (Files.isRegularFile(mmc, LinkOption.NOFOLLOW_LINKS)) files.put(MMC, mmc);
        }
        return files;
    }

    static void legacyRecordAfter(Path mc, Path backup) throws IOException {
        Properties after = new Properties(); int i = 0;
        for (Map.Entry<String, Path> entry : legacyInventory(mc).entrySet()) {
            after.setProperty("entry." + i + ".path", entry.getKey());
            after.setProperty("entry." + i + ".sha256", sha(entry.getValue())); i++;
        }
        after.setProperty("count", Integer.toString(i));
        save(backup.resolve("after.properties"), after);
    }

    static String shaLarge(Path path) throws IOException {
        MessageDigest hash = digest();
        try (InputStream in = Files.newInputStream(path)) { byte[] b = new byte[65536]; int n; while ((n = in.read(b)) != -1) hash.update(b, 0, n); }
        return HexFormat.of().formatHex(hash.digest());
    }

    static void legacyRestore(Path mc, Path backup, Properties manifest) throws IOException {
        Path snapshot = backup.resolve("snapshot.zip"); noLinks(snapshot);
        if (!shaLarge(snapshot).equals(hashValue(required(manifest, "snapshot.sha256")))) throw new Msg("the backup ZIP is damaged; restoration was not started", "ZIP резервной копии повреждён; восстановление не начиналось");
        Map<String, String> before = new LinkedHashMap<>();
        int count = count(manifest, "count");
        for (int i = 0; i < count; i++) {
            String name = required(manifest, "entry." + i + ".path");
            backupTarget(mc, name);
            if (before.put(name, hashValue(required(manifest, "entry." + i + ".sha256"))) != null) throw new Msg("duplicate backup entry", "повторная запись в копии");
        }
        try (ZipFile zip = new ZipFile(snapshot.toFile())) {
            checkZip(zip);
            if (zip.size() != before.size()) throw new Msg("the backup inventory does not match its ZIP", "опись копии не совпадает с её ZIP");
            for (Map.Entry<String, String> entry : before.entrySet()) {
                ZipEntry e = zip.getEntry(entry.getKey());
                if (e == null || e.isDirectory()) throw new Msg("a backup entry is missing", "в копии нет записи");
                try (InputStream in = zip.getInputStream(e)) { if (!sha(in).equals(entry.getValue())) throw new Msg("a backup entry is damaged", "запись копии повреждена"); }
            }
            Path afterPath = backup.resolve("after.properties");
            Map<Path, String> added = new LinkedHashMap<>();
            if (Files.exists(afterPath, LinkOption.NOFOLLOW_LINKS)) {
                Properties after = load(afterPath);
                for (int i = 0, n = count(after, "count"); i < n; i++) {
                    String name = required(after, "entry." + i + ".path");
                    Path target = backupTarget(mc, name);
                    String recorded = hashValue(required(after, "entry." + i + ".sha256"));
                    if (!before.containsKey(name)) added.put(target, recorded);
                }
            }
            for (Map.Entry<String, String> entry : before.entrySet()) {
                Path target = backupTarget(mc, entry.getKey());
                if (Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) {
                    String currentHash = sha(target);
                    if (!currentHash.equals(entry.getValue())) added.put(target, currentHash);
                }
            }
            Path recovery = null;
            for (Map.Entry<Path, String> entry : added.entrySet()) {
                if (Files.isRegularFile(entry.getKey(), LinkOption.NOFOLLOW_LINKS) && sha(entry.getKey()).equals(entry.getValue())) {
                    if (recovery == null) recovery = newDir(mc, ".fallens/recovery-files", backup.getFileName().toString());
                    String relative = entry.getKey().startsWith(mc) ? "mc/" + mc.relativize(entry.getKey()).toString().replace('\\', '/') : MMC;
                    Path destination = resolve(recovery, relative); Files.createDirectories(destination.getParent());
                    replace(entry.getKey(), destination);
                }
            }
            if (recovery != null) info("rollback preserved additional or changed files in " + mc.relativize(recovery), "откат сохранил дополнительные или изменённые файлы в " + mc.relativize(recovery));
            for (String name : before.keySet()) {
                Path target = backupTarget(mc, name);
                if (Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS) && sha(target).equals(before.get(name))) continue;
                Files.createDirectories(target.getParent());
                Path temp = Files.createTempFile(target.getParent(), ".fallens-restore-", ".tmp");
                try {
                    try (InputStream in = zip.getInputStream(zip.getEntry(name)); OutputStream out = Files.newOutputStream(temp)) { in.transferTo(out); }
                    replace(temp, target);
                } finally { Files.deleteIfExists(temp); }
            }
        }
    }

    // ---------------------------------------------------------------- state

    static void saveState(Path state, Channel ch, Properties previous, Path mc) throws IOException {
        Properties p = new Properties();
        p.setProperty("format", "2");
        p.setProperty("version", ch.version());
        p.setProperty("pack.sha256", ch.packSha());
        Long build = highestBuild(ch, previous); // never lowered, also by the repair branch
        if (build != null) p.setProperty("build", Long.toString(build));
        p.setProperty("updater", UPDATER_VERSION);
        if (Files.isRegularFile(resolve(mc, GENERATED), LinkOption.NOFOLLOW_LINKS)) p.setProperty("generatedjar.sha256", sha(mc.resolve(GENERATED)));
        if (Files.isRegularFile(resolve(mc, CATALOG_TARGET), LinkOption.NOFOLLOW_LINKS)) p.setProperty("catalogjar.sha256", sha(mc.resolve(CATALOG_TARGET)));
        save(state, p);
    }

    // ---------------------------------------------------------------- generated Create / Catalog JARs (unchanged since 0.2)

    record Plan(String name, String hash, char mode, String source) {}

    static List<Plan> plans(ZipFile overlay) throws IOException {
        ZipEntry entry = overlay.getEntry("plan.tsv");
        if (entry == null) throw new IOException("Create overlay has no plan.tsv.");
        byte[] data;
        try (InputStream in = overlay.getInputStream(entry)) { data = readLimited(in, 16 * 1024 * 1024); }
        List<Plan> result = new ArrayList<>();
        Set<String> names = new HashSet<>();
        for (String line : new String(data, StandardCharsets.UTF_8).split("\\R")) {
            if (line.isBlank() || line.startsWith("#")) continue;
            String[] fields = line.split("\\t", -1);
            if (fields.length != 4 || fields[2].length() != 1 || "CFDN".indexOf(fields[2].charAt(0)) < 0) {
                throw new IOException("Malformed Create overlay plan.");
            }
            String name = pathName(fields[0]);
            if (!names.add(name) || names.size() > 100000) throw new IOException("Duplicate or excessive Create plan entries.");
            result.add(new Plan(name, hashValue(fields[1]), fields[2].charAt(0), pathName(fields[3])));
        }
        if (result.isEmpty()) throw new IOException("Create overlay plan is empty.");
        return result;
    }

    static byte[] entryBytes(ZipFile zip, String name) throws IOException {
        ZipEntry entry = zip.getEntry(name);
        if (entry == null || entry.isDirectory()) throw new IOException("Missing Create source entry: " + name);
        try (InputStream in = zip.getInputStream(entry)) { return readLimited(in, ENTRY_LIMIT); }
    }

    static void checkZip(ZipFile zip) throws IOException {
        rejectZipLinks(Path.of(zip.getName()));
        Set<String> names = new HashSet<>();
        Enumeration<? extends ZipEntry> entries = zip.entries();
        while (entries.hasMoreElements()) {
            ZipEntry e = entries.nextElement();
            String n = e.getName();
            if (e.isDirectory()) n = n.substring(0, n.length() - 1);
            pathName(n);
            if (!names.add(e.getName())) throw new IOException("Duplicate ZIP entry: " + e.getName());
        }
    }

    static void rejectZipLinks(Path path) throws IOException {
        // java.util.zip does not expose Unix external attributes. Read only the central
        // directory metadata to reject link entries; extraction still uses ZipFile.
        try (RandomAccessFile f = new RandomAccessFile(path.toFile(), "r")) {
            long length = f.length();
            if (length < 22) throw new IOException("Truncated ZIP.");
            long start = Math.max(0, length - 65557);
            byte[] tail = new byte[(int) (length - start)]; f.seek(start); f.readFully(tail);
            ByteBuffer b = ByteBuffer.wrap(tail).order(java.nio.ByteOrder.LITTLE_ENDIAN);
            int end = -1;
            for (int p = tail.length - 22; p >= 0; p--) {
                if (b.getInt(p) == 0x06054b50 && p + 22 + Short.toUnsignedInt(b.getShort(p + 20)) == tail.length) { end = p; break; }
            }
            if (end < 0) throw new IOException("Missing ZIP end record.");
            int count = Short.toUnsignedInt(b.getShort(end + 10));
            long offset = Integer.toUnsignedLong(b.getInt(end + 16));
            if (count == 65535 || offset == 0xffffffffL || b.getShort(end + 4) != 0 || b.getShort(end + 6) != 0) {
                throw new IOException("ZIP64 or split archives are not supported for updater inputs.");
            }
            f.seek(offset); byte[] header = new byte[46];
            for (int i = 0; i < count; i++) {
                f.readFully(header); ByteBuffer h = ByteBuffer.wrap(header).order(java.nio.ByteOrder.LITTLE_ENDIAN);
                if (h.getInt(0) != 0x02014b50) throw new IOException("Invalid ZIP central directory.");
                int attrs = h.getInt(38), unixType = (attrs >>> 16) & 0170000;
                if (unixType == 0120000 || (attrs & 0x400) != 0) throw new IOException("Archive symbolic links are forbidden.");
                long skip = Short.toUnsignedInt(h.getShort(28)) + Short.toUnsignedInt(h.getShort(30)) + Short.toUnsignedInt(h.getShort(32));
                f.seek(f.getFilePointer() + skip);
            }
        }
    }

    static byte[] readLimited(InputStream in, long limit) throws IOException {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[64 * 1024];
        int n;
        long size = 0;
        while ((n = in.read(buf)) != -1) {
            size += n;
            if (size > limit) throw new IOException("Input exceeds its allowed size.");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    static byte[] applyDelta(byte[] original, byte[] encoded) throws IOException {
        try (DataInputStream in = new DataInputStream(new ByteArrayInputStream(encoded))) {
            if (in.readInt() != 0x46444431) throw new IOException("Invalid FDD1 delta header.");
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            while (true) {
                int opcode = in.readUnsignedByte();
                if (opcode == 0) {
                    if (in.read() != -1) throw new IOException("Trailing data in FDD1 delta.");
                    return out.toByteArray();
                }
                if (opcode == 1) {
                    int offset = in.readInt(), length = in.readInt();
                    if (offset < 0 || length < 0 || (long) offset + length > original.length || (long) out.size() + length > ENTRY_LIMIT) {
                        throw new IOException("FDD1 copy is outside its source or output limit.");
                    }
                    out.write(original, offset, length);
                } else if (opcode == 2) {
                    int length = in.readInt();
                    if (length < 0 || (long) out.size() + length > ENTRY_LIMIT) throw new IOException("Invalid FDD1 insert length.");
                    byte[] data = in.readNBytes(length);
                    if (data.length != length) throw new EOFException("Truncated FDD1 insert.");
                    out.write(data);
                } else throw new IOException("Unknown FDD1 opcode: " + opcode);
            }
        }
    }

    static boolean validGenerated(Path mc) throws IOException {
        Path overlayPath = resolve(mc, ".fallens/create/overlay.zip");
        Path generated = resolve(mc, GENERATED);
        if (!Files.isRegularFile(overlayPath, LinkOption.NOFOLLOW_LINKS) || !Files.isRegularFile(generated, LinkOption.NOFOLLOW_LINKS)) return false;
        try (ZipFile overlay = new ZipFile(overlayPath.toFile()); ZipFile target = new ZipFile(generated.toFile())) {
            checkZip(overlay); checkZip(target);
            List<Plan> plan = plans(overlay);
            Enumeration<? extends ZipEntry> entries = target.entries();
            for (Plan p : plan) {
                if (!entries.hasMoreElements()) return false;
                ZipEntry e = entries.nextElement();
                if (!e.getName().equals(p.name()) || e.isDirectory()) return false;
                try (InputStream in = target.getInputStream(e)) { if (!sha(in).equals(p.hash())) return false; }
            }
            return !entries.hasMoreElements();
        } catch (ZipException e) { return false; }
    }

    static void generateCreate(Path mc) throws IOException {
        Path original = resolve(mc, ".fallens/create/upstream.jar");
        Path overlayPath = resolve(mc, ".fallens/create/overlay.zip");
        Path target = resolve(mc, GENERATED);
        if (!Files.isRegularFile(original, LinkOption.NOFOLLOW_LINKS) || !Files.isRegularFile(overlayPath, LinkOption.NOFOLLOW_LINKS)) {
            throw new IOException("Create upstream JAR or overlay is missing.");
        }
        Files.createDirectories(target.getParent());
        Path temp = Files.createTempFile(target.getParent(), ".fallens-create-", ".tmp");
        try {
            try (ZipFile source = new ZipFile(original.toFile()); ZipFile overlay = new ZipFile(overlayPath.toFile());
                 ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(temp))) {
                checkZip(source); checkZip(overlay);
                long total = 0;
                for (Plan p : plans(overlay)) {
                    byte[] data = switch (p.mode()) {
                        case 'C' -> entryBytes(source, p.source());
                        case 'N' -> normalizeCrlf(entryBytes(source, p.source()));
                        case 'F' -> entryBytes(overlay, p.source());
                        case 'D' -> applyDelta(entryBytes(source, p.name()), entryBytes(overlay, p.source()));
                        default -> throw new IOException("Unknown Create mode.");
                    };
                    total += data.length;
                    if (total > TOTAL_LIMIT || !sha(data).equals(p.hash())) throw new IOException("Create reconstructed entry checksum mismatch: " + p.name());
                    ZipEntry e = new ZipEntry(p.name());
                    e.setTime(315532800000L); // 1980-01-01: reproducible ZIP timestamps.
                    out.putNextEntry(e); out.write(data); out.closeEntry();
                }
            }
            replace(temp, target);
        } finally { Files.deleteIfExists(temp); }
        if (!validGenerated(mc)) throw new IOException("Generated Create JAR failed verification.");
    }

    static byte[] normalizeCrlf(byte[] data) {
        ByteArrayOutputStream out = new ByteArrayOutputStream(data.length);
        for (int i = 0; i < data.length; i++) {
            if (data[i] == '\r' && i + 1 < data.length && data[i + 1] == '\n') continue;
            out.write(data[i]);
        }
        return out.toByteArray();
    }

    /** Both Create inputs present: generate. Both absent: this pack has no generated Create JAR. One: broken pack. */
    static boolean hasCreate(Path mc) throws IOException {
        boolean upstream = Files.exists(resolve(mc, ".fallens/create/upstream.jar"), LinkOption.NOFOLLOW_LINKS);
        boolean overlay = Files.exists(resolve(mc, ".fallens/create/overlay.zip"), LinkOption.NOFOLLOW_LINKS);
        if (upstream != overlay) throw new IOException("Create upstream JAR or overlay is missing.");
        return upstream;
    }

    static boolean hasCatalog(Path mc) throws IOException {
        boolean base = Files.exists(resolve(mc, ".fallens/catalog/base.jar"), LinkOption.NOFOLLOW_LINKS);
        boolean recipe = Files.exists(resolve(mc, ".fallens/catalog/recipe.properties"), LinkOption.NOFOLLOW_LINKS);
        if (base != recipe) throw new IOException("Catalog base JAR or recipe is missing.");
        return base;
    }

    /** Generated files are current: valid when their inputs exist, absent when the pack ships no inputs. */
    static boolean generatedCurrent(Path mc) throws IOException {
        boolean create = hasCreate(mc) ? validGenerated(mc) : !Files.exists(resolve(mc, GENERATED), LinkOption.NOFOLLOW_LINKS);
        boolean catalog = hasCatalog(mc) ? validCatalog(mc) : !Files.exists(resolve(mc, CATALOG_TARGET), LinkOption.NOFOLLOW_LINKS);
        return create && catalog;
    }

    static void generateAll(Path mc) throws IOException {
        // A reserved generated name without its inputs is a leftover of another pack; it is removed
        // (on a version change it is still inside the pre-update snapshot).
        if (hasCreate(mc)) generateCreate(mc); else Files.deleteIfExists(resolve(mc, GENERATED));
        if (hasCatalog(mc)) generateCatalog(mc); else Files.deleteIfExists(resolve(mc, CATALOG_TARGET));
    }

    static final String CATALOG_ENTRY = "resourcepacks/readable_russian/assets/mcwwindows/lang/ru_ru.json";

    static String sha512(byte[] bytes) {
        try { return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-512").digest(bytes)); }
        catch (NoSuchAlgorithmException e) { throw new AssertionError(e); }
    }
    static String sha512(Path path) throws IOException {
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-512");
            try (InputStream in = Files.newInputStream(path)) { byte[] b = new byte[65536]; int n; while ((n = in.read(b)) != -1) digest.update(b, 0, n); }
            return HexFormat.of().formatHex(digest.digest());
        } catch (NoSuchAlgorithmException e) { throw new AssertionError(e); }
    }

    static Properties catalogRecipe(Path mc) throws IOException {
        Properties p = load(resolve(mc, ".fallens/catalog/recipe.properties"));
        String upstream = pathName(required(p, "upstream.path"));
        if (!upstream.startsWith("mods/") || !CATALOG_ENTRY.equals(required(p, "target.entry"))) throw new IOException("Invalid Catalog recipe paths.");
        for (String key : List.of("upstream.sha512", "source.ru.sha512", "source.en.sha512", "target.sha512")) {
            if (!required(p, key).matches("[a-fA-F0-9]{128}")) throw new IOException("Invalid Catalog SHA-512.");
        }
        hashValue(required(p, "base.sha256"));
        return p;
    }

    static boolean validCatalog(Path mc) throws IOException {
        Path target = resolve(mc, CATALOG_TARGET);
        if (!Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) return false;
        Properties recipe = catalogRecipe(mc);
        Path base = resolve(mc, ".fallens/catalog/base.jar");
        if (!sha(base).equalsIgnoreCase(required(recipe, "base.sha256"))) throw new IOException("Catalog base checksum mismatch.");
        try (ZipFile original = new ZipFile(base.toFile()); ZipFile generated = new ZipFile(target.toFile())) {
            checkZip(original); checkZip(generated);
            Set<String> expected = new HashSet<>();
            Enumeration<? extends ZipEntry> entries = original.entries();
            while (entries.hasMoreElements()) {
                ZipEntry e = entries.nextElement();
                if (e.isDirectory() || e.getName().equals(CATALOG_ENTRY)) continue;
                expected.add(e.getName()); ZipEntry actual = generated.getEntry(e.getName());
                if (actual == null || actual.isDirectory()) return false;
                try (InputStream a = original.getInputStream(e); InputStream b = generated.getInputStream(actual)) {
                    if (!sha(a).equals(sha(b))) return false;
                }
            }
            expected.add(CATALOG_ENTRY);
            Enumeration<? extends ZipEntry> all = generated.entries(); int size = 0;
            while (all.hasMoreElements()) { ZipEntry e = all.nextElement(); if (e.isDirectory() || !expected.contains(e.getName())) return false; size++; }
            return size == expected.size() && sha512(entryBytes(generated, CATALOG_ENTRY)).equalsIgnoreCase(required(recipe, "target.sha512"));
        } catch (ZipException e) { return false; }
    }

    static void generateCatalog(Path mc) throws IOException {
        Properties recipe = catalogRecipe(mc);
        Path base = resolve(mc, ".fallens/catalog/base.jar");
        Path upstream = resolve(mc, required(recipe, "upstream.path"));
        if (!sha(base).equalsIgnoreCase(required(recipe, "base.sha256")) || !sha512(upstream).equalsIgnoreCase(required(recipe, "upstream.sha512"))) {
            throw new IOException("Catalog base or official Macaw Windows checksum mismatch.");
        }
        byte[] locale;
        try (ZipFile source = new ZipFile(upstream.toFile())) {
            checkZip(source);
            byte[] ru = entryBytes(source, "assets/mcwwindows/lang/ru_ru.json"), en = entryBytes(source, "assets/mcwwindows/lang/en_us.json");
            if (!sha512(ru).equalsIgnoreCase(required(recipe, "source.ru.sha512")) || !sha512(en).equalsIgnoreCase(required(recipe, "source.en.sha512"))) {
                throw new IOException("Official Macaw Windows language checksum mismatch.");
            }
            locale = repairWindowsLocale(ru, en);
        }
        if (!sha512(locale).equalsIgnoreCase(required(recipe, "target.sha512"))) throw new IOException("Locally repaired Catalog locale checksum mismatch.");
        Path target = resolve(mc, CATALOG_TARGET); Files.createDirectories(target.getParent());
        Path temp = Files.createTempFile(target.getParent(), ".fallens-catalog-", ".tmp");
        try {
            try (ZipFile source = new ZipFile(base.toFile()); ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(temp))) {
                checkZip(source); Enumeration<? extends ZipEntry> entries = source.entries();
                while (entries.hasMoreElements()) {
                    ZipEntry e = entries.nextElement(); if (e.isDirectory() || e.getName().equals(CATALOG_ENTRY)) continue;
                    ZipEntry dest = new ZipEntry(e.getName()); dest.setTime(315532800000L); out.putNextEntry(dest);
                    try (InputStream in = source.getInputStream(e)) { in.transferTo(out); } out.closeEntry();
                }
                ZipEntry e = new ZipEntry(CATALOG_ENTRY); e.setTime(315532800000L); out.putNextEntry(e); out.write(locale); out.closeEntry();
            }
            replace(temp, target);
        } finally { Files.deleteIfExists(temp); }
        if (!validCatalog(mc)) throw new IOException("Generated Catalog JAR failed verification.");
    }

    static byte[] repairWindowsLocale(byte[] ruRaw, byte[] enRaw) throws IOException {
        Map<String, String> ru = FlatJson.parse(ruRaw), en = FlatJson.parse(enRaw);
        Map<Character, Integer> reverse = new HashMap<>();
        String special = "€\u0081‚ƒ„…†‡ˆ‰Š‹Œ\u008dŽ\u008f\u0090‘’“”•–—˜™š›œ\u009džŸ";
        for (int b = 0; b < 256; b++) reverse.put(b >= 128 && b < 160 ? special.charAt(b - 128) : (char) b, b);
        LinkedHashMap<String, String> result = new LinkedHashMap<>(); int normal = 0;
        Pattern placeholders = Pattern.compile("%(?:\\d+\\$)?[a-zA-Z%]");
        for (Map.Entry<String, String> entry : ru.entrySet()) {
            String value = entry.getValue();
            if (value.isEmpty() || !(value.contains("Ð") || value.contains("Ñ"))) { normal++; continue; }
            byte[] bytes = new byte[value.length()];
            for (int i = 0; i < value.length(); i++) {
                Integer b = reverse.get(value.charAt(i)); if (b == null) throw new IOException("Macaw locale contains an unsupported encoding character."); bytes[i] = (byte) (int) b;
            }
            String fixed = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
            if (fixed.equals(value) || !Pattern.compile("[А-Яа-яЁё]").matcher(fixed).find() || fixed.indexOf('�') >= 0 ||
                fixed.chars().anyMatch(c -> c >= 128 && c <= 159) ||
                !placeholders.matcher(value).results().map(m -> m.group()).toList().equals(placeholders.matcher(fixed).results().map(m -> m.group()).toList())) {
                throw new IOException("Macaw locale repair did not satisfy its encoding invariants.");
            }
            result.put(entry.getKey(), fixed);
        }
        if (result.size() != 342 || normal != 2) throw new IOException("Unexpected Macaw locale key set.");
        int derived = 0;
        for (Map.Entry<String, String> entry : en.entrySet()) {
            String key = entry.getKey(); if (ru.containsKey(key) || key.equals("itemGroup.mcwwindows")) continue;
            String oak = key.replace("poplar", "oak");
            if (!key.contains("poplar") || !result.containsKey(oak) || !Objects.equals(en.get(oak), entry.getValue().replace("Poplar", "Oak"))) throw new IOException("Unexpected Macaw poplar key.");
            String candidate = result.get(oak);
            for (String[] pair : new String[][]{{"Дубов", "Тополев"}, {"дубов", "тополев"}, {"Дуба", "Тополя"}, {"дуба", "тополя"}, {"Дуб", "Тополь"}, {"дуб", "тополь"}}) candidate = candidate.replace(pair[0], pair[1]);
            if (candidate.equals(result.get(oak))) throw new IOException("Macaw poplar name was not derived.");
            result.put(key, candidate); derived++;
        }
        if (derived != 18) throw new IOException("Unexpected number of Macaw poplar keys.");
        result.put("itemGroup.mcwwindows", "Macaw’s Windows: окна и жалюзи");
        return FlatJson.encode(result);
    }

    /** Strict parser for the language files' flat JSON object of strings and for packwiz.json. */
    static final class FlatJson {
        final String text; int p;
        FlatJson(String text) { this.text = text; }
        void space() { while (p < text.length() && " \t\r\n".indexOf(text.charAt(p)) >= 0) p++; }
        void token(char c) throws IOException { space(); if (p >= text.length() || text.charAt(p++) != c) throw new IOException("Invalid flat language JSON."); }
        String string() throws IOException {
            token('"'); StringBuilder out = new StringBuilder();
            while (p < text.length()) {
                char c = text.charAt(p++); if (c == '"') return out.toString();
                if (c < 32) throw new IOException("Unescaped JSON control character.");
                if (c != '\\') { out.append(c); continue; }
                if (p >= text.length()) throw new IOException("Truncated JSON escape.");
                char escape = text.charAt(p++);
                switch (escape) {
                    case '"', '\\', '/' -> out.append(escape);
                    case 'b' -> out.append('\b'); case 'f' -> out.append('\f'); case 'n' -> out.append('\n'); case 'r' -> out.append('\r'); case 't' -> out.append('\t');
                    case 'u' -> { if (p + 4 > text.length()) throw new IOException("Truncated Unicode escape."); try { out.append((char) Integer.parseInt(text.substring(p, p + 4), 16)); } catch (NumberFormatException e) { throw new IOException("Invalid Unicode escape."); } p += 4; }
                    default -> throw new IOException("Invalid JSON escape.");
                }
            }
            throw new IOException("Unterminated JSON string.");
        }
        static Map<String, String> parse(byte[] bytes) throws IOException {
            String decoded = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
            if (decoded.startsWith("﻿")) decoded = decoded.substring(1);
            FlatJson parser = new FlatJson(decoded);
            LinkedHashMap<String, String> map = new LinkedHashMap<>(); parser.token('{'); parser.space();
            if (parser.p < parser.text.length() && parser.text.charAt(parser.p) == '}') parser.p++;
            else while (true) {
                String key = parser.string(); parser.token(':'); String value = parser.string();
                if (map.put(key, value) != null) throw new IOException("Duplicate language JSON key.");
                parser.space(); if (parser.p >= parser.text.length()) throw new IOException("Unterminated language object.");
                char c = parser.text.charAt(parser.p++); if (c == '}') break; if (c != ',') throw new IOException("Invalid language object separator.");
            }
            parser.space(); if (parser.p != parser.text.length()) throw new IOException("Trailing language JSON data.");
            return map;
        }
        static Object parseAny(byte[] bytes) throws IOException {
            String decoded = StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(bytes)).toString();
            if (decoded.startsWith("﻿")) decoded = decoded.substring(1);
            FlatJson parser = new FlatJson(decoded); Object result = parser.value(0); parser.space();
            if (parser.p != parser.text.length()) throw new IOException("Trailing JSON data."); return result;
        }
        Object value(int depth) throws IOException {
            if (depth > 40) throw new IOException("Excessively nested JSON.");
            space(); if (p >= text.length()) throw new IOException("Truncated JSON.");
            char c = text.charAt(p);
            if (c == '"') return string();
            if (c == '{') {
                p++; Map<String, Object> object = new LinkedHashMap<>(); space();
                if (p < text.length() && text.charAt(p) == '}') { p++; return object; }
                while (true) {
                    String key = string(); token(':'); Object val = value(depth + 1);
                    if (object.containsKey(key)) throw new IOException("Duplicate JSON key."); object.put(key, val); space();
                    if (p >= text.length()) throw new IOException("Truncated JSON object.");
                    c = text.charAt(p++); if (c == '}') return object; if (c != ',') throw new IOException("Invalid JSON separator.");
                }
            }
            if (c == '[') {
                p++; List<Object> array = new ArrayList<>(); space();
                if (p < text.length() && text.charAt(p) == ']') { p++; return array; }
                while (true) {
                    array.add(value(depth + 1)); space(); if (p >= text.length()) throw new IOException("Truncated JSON array.");
                    c = text.charAt(p++); if (c == ']') return array; if (c != ',') throw new IOException("Invalid JSON separator.");
                }
            }
            for (String literal : List.of("true", "false", "null")) {
                if (text.startsWith(literal, p)) { p += literal.length(); return literal.equals("null") ? null : Boolean.valueOf(literal); }
            }
            int start = p; while (p < text.length() && "-+0123456789.eE".indexOf(text.charAt(p)) >= 0) p++;
            if (start == p) throw new IOException("Invalid JSON value.");
            String number = text.substring(start, p);
            if (!number.matches("-?(?:0|[1-9][0-9]*)(?:\\.[0-9]+)?(?:[eE][+-]?[0-9]+)?")) throw new IOException("Invalid JSON number.");
            return number;
        }
        static String quote(String value) {
            StringBuilder out = new StringBuilder("\"");
            for (char c : value.toCharArray()) switch (c) {
                case '"' -> out.append("\\\""); case '\\' -> out.append("\\\\"); case '\b' -> out.append("\\b"); case '\f' -> out.append("\\f");
                case '\n' -> out.append("\\n"); case '\r' -> out.append("\\r"); case '\t' -> out.append("\\t");
                default -> { if (c < 32) out.append(String.format("\\u%04x", (int)c)); else out.append(c); }
            }
            return out.append('"').toString();
        }
        static byte[] encode(Map<String, String> map) {
            StringJoiner out = new StringJoiner(",\r\n", "{\r\n", "\r\n}\r\n");
            map.forEach((key, value) -> out.add("  " + quote(key) + ": " + quote(value)));
            return out.toString().getBytes(StandardCharsets.UTF_8);
        }
    }
}

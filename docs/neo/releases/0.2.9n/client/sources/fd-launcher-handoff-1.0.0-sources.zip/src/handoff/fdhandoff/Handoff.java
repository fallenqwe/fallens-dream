/* SPDX-License-Identifier: MIT
 * Fallen's Dream launcher handoff: replaces the pre-launch files of an existing Prism instance
 * (.fallens/launcher.jar, .fallens/launch.ps1, .fallens/launch-macos.sh) with the copies embedded in this mod.
 *
 * Why a mod: the installed launcher 0.2 runs before the game, cannot replace its own running JAR on Windows,
 * and rejects pack files inside .fallens/. The game starts only after the pre-launch command has finished,
 * so while this code runs nothing holds those files open.
 *
 * Safety rules: only files that already exist are replaced; only a known official earlier version is replaced
 * (a file changed by the player is left alone); the embedded copy must match its pinned SHA-256; the previous
 * file is kept in .fallens/previous/; the new file is written to a temporary file and moved into place.
 * Any error only skips the handoff and is logged; it never stops the game.
 */
package fdhandoff;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.channels.OverlappingFileLockException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.time.Instant;
import java.util.*;

public final class Handoff {
    public static final String VERSION = "@HANDOFF_VERSION@";
    static final String[][] FILES = {
        // target in .fallens, embedded resource, pinned new SHA-256, known official earlier SHA-256 values
        {"launcher.jar", "META-INF/fd-handoff/launcher.bin", "@LAUNCHER_SHA256@",
            "47317e1ef1b2771e391e72ad47a64168d52f450d20f71c179a97495fd51a3595,1cd56bdb27d2af0542ad0897177fe5545a192a4cdf5a52f520625c0fd798d17d"},
        {"launch.ps1", "META-INF/fd-handoff/launch.ps1", "@PS1_SHA256@",
            "c1c82a6c2cfcb018e42dfa9d63c9b6af40da6f155600a65437a8ddc961d7dcef"},
        {"launch-macos.sh", "META-INF/fd-handoff/launch-macos.sh", "@SH_SHA256@",
            "cc0ad62c23792370a982467b4b63bbdd7b8cd4c4103fc9545cf055d09a16b1ef,ea6246cc8a48454b634caf068c7f82a7a16d1a58d499334e93f1155de883a5c9"},
    };

    private Handoff() { }

    public static void main(String[] args) {
        if (args.length != 1) { System.err.println("usage: java -cp fd-launcher-handoff.jar fdhandoff.Handoff <game-dir>"); System.exit(2); }
        List<String> result = run(Path.of(args[0]), System.out);
        System.exit(result.stream().anyMatch(s -> s.startsWith("error")) ? 1 : 0);
    }

    /** Returns one status line per file; never throws. */
    public static List<String> run(Path gameDir, PrintStream log) {
        List<String> status = new ArrayList<>();
        try {
            Path fallens = gameDir.toAbsolutePath().normalize().resolve(".fallens");
            if (!Files.isDirectory(fallens, LinkOption.NOFOLLOW_LINKS) || Files.isSymbolicLink(fallens)
                || !Files.isRegularFile(fallens.resolve("launcher.jar"), LinkOption.NOFOLLOW_LINKS)) {
                status.add("skip: not a Fallen's Dream Prism instance");
                return status;
            }
            try (FileChannel channel = FileChannel.open(fallens.resolve("update.lock"), StandardOpenOption.CREATE, StandardOpenOption.WRITE)) {
                FileLock lock;
                try { lock = channel.tryLock(); } catch (OverlappingFileLockException e) { lock = null; }
                if (lock == null) { status.add("skip: an update is running"); return status; }
                try (FileLock held = lock) {
                    for (String[] file : FILES) status.add(file[0] + ": " + replace(fallens, file));
                }
            }
            Properties receipt = new Properties();
            receipt.setProperty("handoff", VERSION);
            receipt.setProperty("time.utc", Instant.now().toString());
            for (int i = 0; i < status.size(); i++) receipt.setProperty("result." + i, status.get(i));
            Path temp = Files.createTempFile(fallens, ".fd-handoff-", ".tmp");
            try {
                try (var out = Files.newBufferedWriter(temp, StandardCharsets.UTF_8)) { receipt.store(out, "Fallen's Dream launcher handoff"); }
                move(temp, fallens.resolve("handoff.properties"));
            } finally { Files.deleteIfExists(temp); }
        } catch (Throwable t) {
            status.add("error: " + t);
        }
        for (String s : status) log.println("[fd_launcher_handoff " + VERSION + "] " + s);
        log.flush();
        return status;
    }

    static String replace(Path fallens, String[] file) {
        try {
            Path target = fallens.resolve(file[0]);
            if (Files.isSymbolicLink(target) || !Files.isRegularFile(target, LinkOption.NOFOLLOW_LINKS)) return "absent, nothing to do";
            String current = sha256(Files.readAllBytes(target));
            if (current.equals(file[2])) return "current";
            Set<String> known = new HashSet<>(Arrays.asList(file[3].split(",")));
            if (!known.contains(current)) return "left unchanged (unknown version " + current.substring(0, 16) + ")";
            byte[] bytes;
            try (InputStream in = Handoff.class.getResourceAsStream("/" + file[1])) {
                if (in == null) return "error: embedded copy is missing";
                bytes = in.readAllBytes();
            }
            if (!sha256(bytes).equals(file[2])) return "error: embedded copy does not match its pin";
            Path previous = fallens.resolve("previous");
            Files.createDirectories(previous);
            Files.copy(target, previous.resolve(file[0]), StandardCopyOption.REPLACE_EXISTING);
            Path temp = Files.createTempFile(fallens, ".fd-handoff-", ".tmp");
            try {
                try (FileChannel out = FileChannel.open(temp, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING)) {
                    ByteBuffer buffer = ByteBuffer.wrap(bytes);
                    while (buffer.hasRemaining()) out.write(buffer);
                    out.force(true);
                }
                move(temp, target);
            } finally { Files.deleteIfExists(temp); }
            if (!sha256(Files.readAllBytes(target)).equals(file[2])) return "error: written file does not match its pin";
            return "replaced " + current.substring(0, 16) + " -> " + file[2].substring(0, 16) + " (previous copy in .fallens/previous)";
        } catch (Throwable t) {
            return "error: " + t;
        }
    }

    static void move(Path source, Path target) throws IOException {
        try { Files.move(source, target, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING); }
        catch (AtomicMoveNotSupportedException e) { Files.move(source, target, StandardCopyOption.REPLACE_EXISTING); }
    }

    static String sha256(byte[] data) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(data));
    }
}

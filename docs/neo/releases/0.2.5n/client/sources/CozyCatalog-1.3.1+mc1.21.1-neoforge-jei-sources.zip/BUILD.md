# Build

Requires Java21 and Gradle8.14.3. NeoForge and plugin dependencies are downloaded
from their configured official Maven repositories. The exact JEI compile dependency
is downloaded separately from its original Modrinth CDN, not redistributed here.

1. Run `python tools/fetch_jei.py` (Python3 standard library only).
2. Run `gradle --no-daemon check jar` with Java21 selected.

JEI is pinned because the category adapter intentionally targets the tested
19.32.0.359 internal API. Do not silently update its dependency or Minecraft.

The new narrow language checks read an external official Carved Wood fixture;
the fixture is not included in this source distribution. The standard `check`
tasks cover category/layout/native geometry. Compatibility regression evidence
for the release additionally runs the real transformed ClientLanguage before
Minecraft Main, with the unmodified dependency supplied at test time.

from pathlib import Path
import hashlib,json,subprocess,sys,zipfile
ROOT=Path(__file__).resolve().parent
WORK=ROOT.parents[2]/'work'
BASE=WORK/'neoforge-1.21.1-2026-10-22/cozy-catalog-neoforge'
JDK=BASE/'.tools/jdk-21.0.12.1+1'
NATIVE=BASE/'.gradle-home/caches/neoformruntime/intermediate_results/compiledWithNeoForge_9c1f49c436395830cb111ef1cbe0ad44da845152_output.jar'
LIBS=WORK/'server-migration-2026-10-24/server-payload/libraries'
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def build(test=False):
    out=ROOT/('test-build' if test else 'build');classes=out/'classes';classes.mkdir(parents=True,exist_ok=True)
    extra=next((BASE/'.gradle-home/caches/modules-2/files-2.1/io.github.llamalad7/mixinextras-neoforge/0.5.5').rglob('*.jar'))
    libraries=[p for p in LIBS.rglob('*.jar') if not p.name.endswith('-sources.jar')]
    cp=';'.join(str(p.resolve()) for p in [NATIVE,extra,*libraries])
    sources=sorted((ROOT/('test-src' if test else 'src')).rglob('*.java'))
    empty=out/'empty-sourcepath';empty.mkdir(exist_ok=True)
    args=['-proc:none','--release','21','-encoding','UTF-8','-sourcepath',str(empty.resolve()),'-cp',cp,'-d',str(classes.resolve()),*[str(p.resolve()) for p in sources]]
    argfile=out/'compile.args';argfile.write_text('\n'.join('"'+v.replace('\\','/')+'"' for v in args),'utf8')
    result=subprocess.run([str(JDK/'bin/javac.exe'),'@'+str(argfile.resolve())],capture_output=True,text=True,encoding='utf8',errors='replace')
    (out/'compile.log').write_text(result.stdout+result.stderr,'utf8')
    assert result.returncode==0,result.stdout+result.stderr
    jar=out/('fd-worldgen-test.jar' if test else 'FDCompatFixes-0.1.0+mc1.21.1.jar')
    with zipfile.ZipFile(jar,'w',zipfile.ZIP_DEFLATED) as z:
        def put(name,data):
            info=zipfile.ZipInfo(name,(1980,1,1,0,0,0));info.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(info,data)
        for p in sorted(classes.rglob('*.class')):put(p.relative_to(classes).as_posix(),p.read_bytes())
        if test:
            put('META-INF/neoforge.mods.toml',b'modLoader="javafml"\nloaderVersion="[4,)"\nlicense="MIT"\n[[mods]]\nmodId="fd_worldgen_test"\nversion="1.0.0"\ndisplayName="Test only worldgen probe"\n')
        else:
            for p in sorted((ROOT/'resources').rglob('*')):
                if p.is_file():put(p.relative_to(ROOT/'resources').as_posix(),p.read_bytes())
            put('META-INF/LICENSE', (ROOT/'LICENSE').read_bytes())
    return jar
if __name__=='__main__':
    if '--inspect' in sys.argv:
        out=ROOT/'inspect';out.mkdir(exist_ok=True)
        for cls in ['net.minecraft.world.level.levelgen.feature.LargeDripstoneFeature','net.minecraft.world.level.levelgen.feature.LargeDripstoneFeature$WindOffsetter','net.minecraft.world.level.levelgen.feature.LargeDripstoneFeature$LargeDripstone','net.minecraft.world.level.chunk.status.ChunkPyramid','net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate$StructureEntityInfo']:
            result=subprocess.run([str(JDK/'bin/javap.exe'),'-p','-c','-s','-cp',str(NATIVE),cls],capture_output=True,text=True,encoding='utf8',errors='replace')
            assert result.returncode==0,result.stderr
            (out/(cls.rsplit('.',1)[-1]+'.txt')).write_text(result.stdout,'utf8')
        print('inspected')
    else:
        path=build('--test' in sys.argv)
        print(json.dumps({'file':str(path),'sha256':sha(path)}))

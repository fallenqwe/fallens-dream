package fd.compat.mixin;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.chunk.status.ChunkStep;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(WorldGenRegion.class)
public interface WorldGenRegionStepAccessor {
    @Accessor("generatingStep") ChunkStep fd$getGeneratingStep();
}

package fd.compat;
import fd.compat.mixin.WorldGenRegionStepAccessor;
import net.minecraft.server.level.WorldGenRegion;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.configurations.LargeDripstoneConfiguration;

/** Bounds the feature's wind geometry, leaving Minecraft's write protection intact. */
public final class WindBounds {
    private static final ThreadLocal<Float> CAP=new ThreadLocal<>();
    private WindBounds() {}
    public static Float enter(FeaturePlaceContext<LargeDripstoneConfiguration> context) {
        Float previous=CAP.get();
        CAP.remove();
        if(context.level() instanceof WorldGenRegion region) {
            int radius=((WorldGenRegionStepAccessor)region).fd$getGeneratingStep().blockStateWriteRadius();
            if(radius>=0) {
                var center=region.getCenter(); var origin=context.origin();
                long minX=((long)center.x-radius)*16L,minZ=((long)center.z-radius)*16L;
                long maxX=((long)center.x+radius+1)*16L-1,maxZ=((long)center.z+radius+1)*16L-1;
                long margin=Math.min(Math.min(origin.getX()-minX,maxX-origin.getX()),Math.min(origin.getZ()-minZ,maxZ-origin.getZ()));
                // floor(negative wind) needs one extra block of margin. Every
                // placed block lies inside the dimension, so this conservative
                // vertical span also covers the native base-search adjustment.
                long drift=Math.max(0,margin-context.config().columnRadius.getMaxValue()-1L);
                float cap=(float)((double)drift/(context.level().getHeight()+20.0));
                CAP.set(Math.max(0.0F,cap));
            }
        }
        return previous;
    }
    public static void exit(Float previous) { if(previous==null) CAP.remove();else CAP.set(previous); }
    public static float clamp(float sampled) { Float cap=CAP.get();return cap==null?sampled:Math.min(sampled,cap); }
}

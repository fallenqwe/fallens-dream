package fd.compat;

import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import net.minecraft.resources.ResourceLocation;

/** Repairs two broken relationships in memory; does not ship or modify WDA assets. */
public final class WdaAdvancementParents {
    private static final String NAMESPACE = "dungeons_arise";
    private static final String MISSING_PARENT = "dungeons_arise:find_small_prairie_house";
    private static final String EXISTING_ROOT = "dungeons_arise:wda_root";
    private static final Set<String> TARGETS = Set.of("find_fishing_hut", "find_thornborn_towers");
    private WdaAdvancementParents() {}

    public static Map<ResourceLocation, JsonElement> repair(Map<ResourceLocation, JsonElement> original) {
        Map<ResourceLocation, JsonElement> changed = null;
        for (String path : TARGETS) {
            ResourceLocation id = ResourceLocation.fromNamespaceAndPath(NAMESPACE, path);
            JsonElement value = original.get(id);
            if (value == null || !value.isJsonObject()) continue;
            JsonElement parent = value.getAsJsonObject().get("parent");
            if (parent == null || !parent.isJsonPrimitive() || !parent.getAsJsonPrimitive().isString()
                    || !MISSING_PARENT.equals(parent.getAsString())) continue;
            if (changed == null) changed = new LinkedHashMap<>(original);
            JsonObject fixed = value.getAsJsonObject().deepCopy();
            fixed.addProperty("parent", EXISTING_ROOT);
            changed.put(id, fixed);
        }
        return changed == null ? original : changed;
    }
}

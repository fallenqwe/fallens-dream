package fd.compat.mixin;
import com.llamalad7.mixinextras.injector.wrapmethod.WrapMethod;
import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import fd.compat.WindBounds;
import net.minecraft.world.level.levelgen.feature.FeaturePlaceContext;
import net.minecraft.world.level.levelgen.feature.LargeDripstoneFeature;
import net.minecraft.world.level.levelgen.feature.configurations.LargeDripstoneConfiguration;
import org.spongepowered.asm.mixin.Mixin;
@Mixin(LargeDripstoneFeature.class)
public abstract class LargeDripstoneFeatureMixin {
    @WrapMethod(method="place")
    private boolean fd$windSpace(FeaturePlaceContext<LargeDripstoneConfiguration> context,Operation<Boolean> original) {
        Float previous=WindBounds.enter(context);
        try { return original.call(context); } finally { WindBounds.exit(previous); }
    }
}

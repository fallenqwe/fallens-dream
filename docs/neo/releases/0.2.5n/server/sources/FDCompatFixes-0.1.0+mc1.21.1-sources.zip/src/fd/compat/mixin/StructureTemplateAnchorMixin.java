package fd.compat.mixin;
import com.llamalad7.mixinextras.sugar.Local;
import fd.compat.StructureAnchorFix;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.world.level.levelgen.structure.templatesystem.StructureTemplate;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyArg;

@Mixin(StructureTemplate.class)
public abstract class StructureTemplateAnchorMixin {
    @ModifyArg(method="addEntitiesToWorld",at=@At(value="INVOKE",target="Lnet/minecraft/world/level/levelgen/structure/templatesystem/StructureTemplate;createEntityIgnoreException(Lnet/minecraft/world/level/ServerLevelAccessor;Lnet/minecraft/nbt/CompoundTag;)Ljava/util/Optional;"),index=1)
    private CompoundTag fd$placedAnchor(CompoundTag nbt,@Local StructureTemplate.StructureEntityInfo info) {
        return StructureAnchorFix.normalize(nbt,info.blockPos);
    }
}

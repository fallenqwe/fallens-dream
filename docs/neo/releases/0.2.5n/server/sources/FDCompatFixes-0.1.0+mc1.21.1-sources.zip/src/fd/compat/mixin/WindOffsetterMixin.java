package fd.compat.mixin;
import fd.compat.WindBounds;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;
@Mixin(targets="net.minecraft.world.level.levelgen.feature.LargeDripstoneFeature$WindOffsetter")
public abstract class WindOffsetterMixin {
    @ModifyVariable(method="<init>(ILnet/minecraft/util/RandomSource;Lnet/minecraft/util/valueproviders/FloatProvider;)V",at=@At("STORE"),ordinal=0)
    private float fd$boundedSpeed(float sampled) { return WindBounds.clamp(sampled); }
}

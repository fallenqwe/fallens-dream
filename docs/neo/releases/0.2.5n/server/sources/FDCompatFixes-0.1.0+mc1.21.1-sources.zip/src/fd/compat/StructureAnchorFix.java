package fd.compat;
import java.util.Set;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
/** The template's already transformed blockPos is the authoritative anchor. */
public final class StructureAnchorFix {
    private static final Set<String> SUPPORTED=Set.of("minecraft:painting","minecraft:item_frame","minecraft:glow_item_frame","minecraft:leash_knot");
    private StructureAnchorFix() {}
    public static CompoundTag normalize(CompoundTag nbt, BlockPos placedAnchor) {
        if(SUPPORTED.contains(nbt.getString("id"))&&nbt.contains("TileX",99)&&nbt.contains("TileY",99)&&nbt.contains("TileZ",99)) {
            nbt.putInt("TileX",placedAnchor.getX());
            nbt.putInt("TileY",placedAnchor.getY());
            nbt.putInt("TileZ",placedAnchor.getZ());
        }
        return nbt;
    }
}

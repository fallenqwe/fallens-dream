package fd.compat.mixin;

import com.google.gson.JsonElement;
import fd.compat.WdaAdvancementParents;
import java.util.Map;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.ServerAdvancementManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** NeoForge1.21.1: adjust the parsed resource map before vanilla decodes any advancement. */
@Mixin(value = ServerAdvancementManager.class, remap = false)
public abstract class ServerAdvancementManagerParentMixin {
    @ModifyVariable(method = "apply(Ljava/util/Map;Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/util/profiling/ProfilerFiller;)V",
            at = @At("HEAD"), argsOnly = true, ordinal = 0, require = 1, allow = 1, remap = false)
    private Map<ResourceLocation, JsonElement> fallenCompat$wdaParents(Map<ResourceLocation, JsonElement> resources) {
        return WdaAdvancementParents.repair(resources);
    }
}

package fd.compat;
import net.neoforged.fml.common.Mod;
/** Narrow structure-template NBT coordinate repair; no world loading or saved-data migration. */
@Mod("fd_compat_fixes")
public final class FDCompatFixes { public FDCompatFixes() {} }

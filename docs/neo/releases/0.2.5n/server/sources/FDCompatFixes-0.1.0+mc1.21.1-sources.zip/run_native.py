"""Two isolated dedicated-server phases; existing EULA copied, no GUI/live host."""
from pathlib import Path
import hashlib,json,shutil,socket,subprocess,sys,time,uuid
import build
ROOT=Path(__file__).resolve().parent
WORK=ROOT.parents[2]/'work'
PREVIOUS=WORK/'exploration-2026-10-25/test/runs/20261025T004349Z-28d5c8'
WORLD=WORK/'server-polish-2026-10-24/smoke-server-with-skins/world-neoforge'
MANIFEST=WORK/'exploration-2026-10-25/delivery-work/delivery/pack-manifest.json'
EULA=WORK/'server-migration-2026-10-24/private/existing-eula.txt'

def dump(path,value):
    path.parent.mkdir(parents=True,exist_ok=True);path.write_text(json.dumps(value,indent=2)+'\n','utf8')
def tree(path):return {p.relative_to(path).as_posix():build.sha(p) for p in path.rglob('*') if p.is_file()}
def prepare(phase,helper,compat):
    run=ROOT/'runs'/(time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+phase+'-'+uuid.uuid4().hex[:6]);run.mkdir(parents=True)
    for name in ['libraries','config','defaultconfigs']:shutil.copytree(PREVIOUS/name,run/name)
    shutil.copytree(WORLD,run/'world-neoforge')
    # Restore the checked previous fixes pack including exploration integration.
    fixes=run/'world-neoforge/datapacks/fd-server-fixes'
    shutil.copytree(PREVIOUS/'world-neoforge/datapacks/fd-server-fixes',fixes,dirs_exist_ok=True)
    mods=run/'mods';mods.mkdir()
    meta=json.loads(MANIFEST.read_text('utf8'))
    for entry in meta['server_files']:
        src=PREVIOUS/'mods'/entry['file'];assert hashlib.sha512(src.read_bytes()).hexdigest()==entry['sha512']
        shutil.copyfile(src,mods/src.name)
    shutil.copyfile(helper,mods/helper.name)
    if phase=='green':
        shutil.copyfile(compat,mods/compat.name)
        # Advancement relationship repair is runtime code; no bridge/ARR data override.
    assert build.sha(EULA)=='e32aa47e1f88724a159f7ba7de19e389cad815d4b036203fc62cad92958c844c'
    (run/'eula.txt').write_bytes(EULA.read_bytes())
    ports=[]
    for kind in [socket.SOCK_STREAM,socket.SOCK_DGRAM]:
        with socket.socket(socket.AF_INET,kind) as connection:connection.bind(('127.0.0.1',0));ports.append(connection.getsockname()[1])
    (run/'server.properties').write_text('server-ip=127.0.0.1\nserver-port='+str(ports[0])+'\nlevel-name=world-neoforge\nonline-mode=true\nview-distance=2\nsimulation-distance=2\nmax-players=1\nenable-status=false\nenable-query=false\nenable-rcon=false\ngenerate-structures=true\n','utf8')
    (run/'config/voicechat/voicechat-server.properties').write_text('bind_address=127.0.0.1\nport='+str(ports[1])+'\n','utf8')
    return run
def execute(phase,helper,compat):
    run=prepare(phase,helper,compat);log=run/'server.log'
    argv=[str(build.JDK/'bin/java.exe'),'-Xms512m','-Xmx6G','-Djava.awt.headless=true','@libraries/net/neoforged/neoforge/21.1.264/win_args.txt','nogui']
    with log.open('wb') as stream:
        process=subprocess.Popen(argv,cwd=run,stdin=subprocess.PIPE,stdout=stream,stderr=subprocess.STDOUT,text=True,encoding='utf8',creationflags=0x08000000)
    def send(value):process.stdin.write(value+'\n');process.stdin.flush()
    def wait(predicate,label,seconds=500):
        started=time.monotonic();last=started
        while time.monotonic()-started<seconds:
            if predicate():return
            if (run/'worldgen-failure.json').is_file():raise AssertionError((run/'worldgen-failure.json').read_text('utf8'))
            assert process.poll() is None,'Server exited; inspect private local log: '+str(log)
            if time.monotonic()-last>30:print(json.dumps({'phase':phase,'waiting':label,'seconds':int(time.monotonic()-started)}),flush=True);last=time.monotonic()
            time.sleep(1)
        raise TimeoutError(label)
    try:
        wait(lambda:'Done (' in log.read_text('utf8',errors='replace'),'startup')
        send('fdworldgentest')
        wait(lambda:(run/'worldgen-test.json').is_file(),'native feature and template cases')
        send('save-all flush');time.sleep(2);send('stop');process.wait(timeout=90)
        assert process.returncode==0
        result=json.loads((run/'worldgen-test.json').read_text('utf8'))
        text=log.read_text('utf8',errors='replace')
        result.update(run=str(run),exit_code=process.returncode,
                      far_chunk_errors=text.count('Detected setBlock in a far chunk'),
                      stale_anchor_errors=text.count('Block-attached entity at invalid position'),
                      eula_newly_accepted=False,game_client_started=False,gui_started=False)
        dump(ROOT/(phase+'-report.json'),result)
        print(json.dumps({k:v for k,v in result.items() if k not in ['feature_cases','structure_entity_cases']}),flush=True)
        return result
    finally:
        if process.poll() is None:
            send('stop')
            try:process.wait(timeout=90)
            except subprocess.TimeoutExpired:process.terminate();process.wait(timeout=30)
def main():
    guard=tree(WORLD);helper=build.build(True);compat=build.build(False)
    if '--resume-red' in sys.argv:
        red=json.loads((ROOT/'red-report.json').read_text('utf8'))
        previous_run=Path(red['run']).resolve();assert previous_run.is_relative_to((ROOT/'runs').resolve())
        assert build.sha(previous_run/'mods'/helper.name)==build.sha(helper),'Cannot reuse RED from different probe bytes'
    else:
        red=execute('red',helper,compat)
    # Item/glow frames and paintings read Tile*: 3*12 errors. Native leash knots
    # do not call the inherited Tile reader, but all 48 placement cases execute.
    assert red['rejected_blocks']>0 and red['stale_anchor_errors']==36
    green=execute('green',helper,compat)
    assert green['rejected_blocks']==0 and green['stale_anchor_errors']==0
    assert green['placed_blocks']==red['placed_blocks']+red['rejected_blocks']
    assert green['native_structure_placement_cases']==48
    assert green['advancement_tree']['find_fishing_hut']['visible_after_root']
    assert green['advancement_tree']['find_thornborn_towers']['visible_after_root']
    assert not green['advancement_tree']['find_small_prairie_house']['present']
    assert tree(WORLD)==guard
    dump(ROOT/'test-report.json',{'status':'PASS','red':red,'green':green,'source_world_unchanged':True,'compat_jar_sha256':build.sha(compat)})
if __name__=='__main__':main()

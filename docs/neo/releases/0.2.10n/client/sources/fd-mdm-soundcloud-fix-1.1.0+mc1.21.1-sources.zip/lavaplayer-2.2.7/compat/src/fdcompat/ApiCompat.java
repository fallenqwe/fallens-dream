package fdcompat;

import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Deque;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.objectweb.asm.ClassReader;
import org.objectweb.asm.Handle;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.FieldInsnNode;
import org.objectweb.asm.tree.FieldNode;
import org.objectweb.asm.tree.InvokeDynamicInsnNode;
import org.objectweb.asm.tree.LdcInsnNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.objectweb.asm.tree.MultiANewArrayInsnNode;
import org.objectweb.asm.tree.TryCatchBlockNode;
import org.objectweb.asm.tree.TypeInsnNode;

/**
 * Binary-linkage check: do the consumer jars (MDM's LavaPlayer adapter, youtube-source v2/common 1.18.2) still link
 * against a different LavaPlayer build? Every class/field/method/handle reference whose owner is in the checked
 * namespace (com/sedmelluq/) is resolved JVMS-style (class chain, then superinterfaces) in the OLD world and in the NEW
 * world; static/instance kind, private/package access and final-field writes are checked. Additionally: consumer
 * methods that overrode a LavaPlayer method must still override one, concrete consumer classes must not inherit new
 * unimplemented abstract methods, and public/protected API removed or narrowed between OLD and NEW is listed.
 *
 * <p>Args: report.json --old a.jar,b.jar --new a.jar,b.jar --consumers a.jar,b.jar --extra a.jar,b.jar
 * (OLD/NEW = the jars that differ; extra = the unchanged rest of the world, consumers are part of both worlds.)
 */
public final class ApiCompat {
    static final String NS = "com/sedmelluq/";

    record Member(String owner, String name, String desc, int access) {}

    static final class Cls {
        String name, sup;
        String[] itfs;
        int access;
        final Map<String, Member> methods = new HashMap<>();
        final Map<String, Member> fields = new HashMap<>();
    }

    static final class World {
        final Map<String, Cls> classes = new HashMap<>();
        final Map<String, Cls> jdk = new HashMap<>();

        Cls get(String name) {
            final Cls c = classes.get(name);
            if (c != null) return c;
            return jdk.computeIfAbsent(name, World::loadJdk);
        }

        static Cls loadJdk(String name) {
            try (InputStream in = ClassLoader.getSystemResourceAsStream(name + ".class")) {
                return in == null ? null : model(in.readAllBytes());
            } catch (IOException e) {
                return null;
            }
        }
    }

    static Cls model(byte[] bytes) {
        final ClassNode n = new ClassNode();
        new ClassReader(bytes).accept(n, ClassReader.SKIP_CODE | ClassReader.SKIP_DEBUG | ClassReader.SKIP_FRAMES);
        final Cls c = new Cls();
        c.name = n.name; c.sup = n.superName; c.access = n.access;
        c.itfs = n.interfaces.toArray(new String[0]);
        for (MethodNode m : n.methods) c.methods.put(m.name + m.desc, new Member(n.name, m.name, m.desc, m.access));
        for (FieldNode f : n.fields) c.fields.put(f.name + ":" + f.desc, new Member(n.name, f.name, f.desc, f.access));
        return c;
    }

    static Map<String, byte[]> classesOf(List<Path> jars) throws IOException {
        final Map<String, byte[]> out = new LinkedHashMap<>();
        for (Path jar : jars) {
            try (ZipInputStream z = new ZipInputStream(Files.newInputStream(jar))) {
                for (ZipEntry e; (e = z.getNextEntry()) != null; ) {
                    final String n = e.getName();
                    if (n.endsWith(".class") && !n.startsWith("META-INF/") && !n.endsWith("module-info.class")) {
                        out.putIfAbsent(n.substring(0, n.length() - 6), z.readAllBytes());
                    }
                }
            }
        }
        return out;
    }

    static World world(List<Path> jars) throws IOException {
        final World w = new World();
        for (Map.Entry<String, byte[]> e : classesOf(jars).entrySet()) w.classes.put(e.getKey(), model(e.getValue()));
        return w;
    }

    /** A reference made by a consumer. kind: class|field|method|imethod|handle. */
    record Ref(String from, String kind, String owner, String name, String desc, int opcode) {
        String key() { return kind + " " + owner + (name == null ? "" : "." + name + (kind.equals("field") ? ":" : "") + desc) + (opcode < 0 ? "" : " op" + opcode); }
    }

    static String classOf(String internalOrDesc) {
        if (internalOrDesc == null) return null;
        if (internalOrDesc.startsWith("[") || internalOrDesc.endsWith(";")) {
            final Type t = Type.getType(internalOrDesc);
            Type e = t.getSort() == Type.ARRAY ? t.getElementType() : t;
            return e.getSort() == Type.OBJECT ? e.getInternalName() : null;
        }
        return internalOrDesc;
    }

    static void addDescClasses(List<Ref> refs, String from, String desc) {
        if (desc == null) return;
        final Type t = Type.getType(desc);
        final List<Type> types = new ArrayList<>();
        if (t.getSort() == Type.METHOD) { types.add(t.getReturnType()); types.addAll(List.of(t.getArgumentTypes())); } else types.add(t);
        for (Type x : types) {
            final Type e = x.getSort() == Type.ARRAY ? x.getElementType() : x;
            if (e.getSort() == Type.OBJECT) refs.add(new Ref(from, "class", e.getInternalName(), null, null, -1));
        }
    }

    static List<Ref> refsOf(byte[] bytes) {
        final ClassNode n = new ClassNode();
        new ClassReader(bytes).accept(n, ClassReader.SKIP_FRAMES);
        final List<Ref> refs = new ArrayList<>();
        final String me = n.name;
        if (n.superName != null) refs.add(new Ref(me, "class", n.superName, null, null, -1));
        for (String i : n.interfaces) refs.add(new Ref(me, "class", i, null, null, -1));
        for (FieldNode f : n.fields) addDescClasses(refs, me, f.desc);
        for (MethodNode m : n.methods) {
            addDescClasses(refs, me, m.desc);
            if (m.exceptions != null) for (String ex : m.exceptions) refs.add(new Ref(me, "class", ex, null, null, -1));
            for (TryCatchBlockNode tc : m.tryCatchBlocks) if (tc.type != null) refs.add(new Ref(me, "class", tc.type, null, null, -1));
            for (AbstractInsnNode insn = m.instructions.getFirst(); insn != null; insn = insn.getNext()) {
                if (insn instanceof MethodInsnNode mi) {
                    final String owner = classOf(mi.owner);
                    if (mi.owner.startsWith("[")) { refs.add(new Ref(me, "class", owner, null, null, -1)); continue; }
                    refs.add(new Ref(me, mi.itf ? "imethod" : "method", mi.owner, mi.name, mi.desc, mi.getOpcode()));
                    addDescClasses(refs, me, mi.desc);
                } else if (insn instanceof FieldInsnNode fi) {
                    refs.add(new Ref(me, "field", fi.owner, fi.name, fi.desc, fi.getOpcode()));
                    addDescClasses(refs, me, fi.desc);
                } else if (insn instanceof TypeInsnNode ti) {
                    refs.add(new Ref(me, "class", classOf(ti.desc), null, null, -1));
                } else if (insn instanceof MultiANewArrayInsnNode ma) {
                    refs.add(new Ref(me, "class", classOf(ma.desc), null, null, -1));
                } else if (insn instanceof LdcInsnNode ldc && ldc.cst instanceof Type t) {
                    if (t.getSort() == Type.OBJECT || t.getSort() == Type.ARRAY) refs.add(new Ref(me, "class", classOf(t.getDescriptor()), null, null, -1));
                } else if (insn instanceof InvokeDynamicInsnNode indy) {
                    addDescClasses(refs, me, indy.desc);
                    final List<Object> hs = new ArrayList<>(List.of(indy.bsmArgs));
                    hs.add(indy.bsm);
                    for (Object a : hs) {
                        if (a instanceof Handle h) {
                            refs.add(new Ref(me, "handle", h.getOwner(), h.getName(), h.getDesc(), h.getTag()));
                            addDescClasses(refs, me, h.getDesc());
                        } else if (a instanceof Type t && t.getSort() == Type.METHOD) {
                            addDescClasses(refs, me, t.getDescriptor());
                        }
                    }
                }
            }
        }
        return refs;
    }

    static String pkg(String internal) {
        final int i = internal.lastIndexOf('/');
        return i < 0 ? "" : internal.substring(0, i);
    }

    /** Field resolution (JVMS 5.4.3.2): the class, its superinterfaces, then its superclass, recursively. */
    static Member findField(World w, String owner, String key, Set<String> missing) {
        final Cls c = w.get(owner);
        if (c == null) { missing.add(owner); return null; }
        final Member m = c.fields.get(key);
        if (m != null) return m;
        for (String i : c.itfs) { final Member r = findField(w, i, key, missing); if (r != null) return r; }
        return c.sup == null ? null : findField(w, c.sup, key, missing);
    }

    /** Method resolution: class chain first, then all superinterfaces (non-private, non-static). */
    static Member findMethod(World w, String owner, String key, Set<String> missing) {
        for (String n = owner; n != null; ) {
            final Cls c = w.get(n);
            if (c == null) { missing.add(n); return null; }
            final Member m = c.methods.get(key);
            if (m != null) return m;
            n = c.sup;
        }
        final Deque<String> todo = new ArrayDeque<>();
        final Set<String> seen = new HashSet<>();
        for (String n = owner; n != null; ) {
            final Cls c = w.get(n);
            if (c == null) break;
            for (String i : c.itfs) todo.add(i);
            n = c.sup;
        }
        while (!todo.isEmpty()) {
            final String i = todo.poll();
            if (!seen.add(i)) continue;
            final Cls c = w.get(i);
            if (c == null) { missing.add(i); continue; }
            final Member m = c.methods.get(key);
            if (m != null && (m.access & (Opcodes.ACC_PRIVATE | Opcodes.ACC_STATIC)) == 0) return m;
            for (String s : c.itfs) todo.add(s);
        }
        return null;
    }

    static boolean accessible(Member m, String from) {
        if ((m.access & Opcodes.ACC_PRIVATE) != 0) return m.owner.equals(from);
        if ((m.access & (Opcodes.ACC_PUBLIC | Opcodes.ACC_PROTECTED)) == 0) return pkg(m.owner).equals(pkg(from));
        return true;
    }

    /** null = OK, otherwise the problem. */
    static String check(World w, Ref r) {
        final Set<String> missing = new TreeSet<>();
        switch (r.kind()) {
            case "class": {
                final Cls c = w.get(r.owner());
                if (c == null) return "missing class";
                if ((c.access & Opcodes.ACC_PUBLIC) == 0 && !pkg(c.name).equals(pkg(r.from()))) return "class not public";
                return null;
            }
            case "field": {
                final Member m = findField(w, r.owner(), r.name() + ":" + r.desc(), missing);
                if (m == null) return missing.isEmpty() ? "missing field" : "missing class " + missing;
                final boolean wantStatic = r.opcode() == Opcodes.GETSTATIC || r.opcode() == Opcodes.PUTSTATIC;
                if (wantStatic != ((m.access & Opcodes.ACC_STATIC) != 0)) return "static/instance mismatch";
                if (!accessible(m, r.from())) return "field not accessible";
                if ((r.opcode() == Opcodes.PUTFIELD || r.opcode() == Opcodes.PUTSTATIC) && (m.access & Opcodes.ACC_FINAL) != 0 && !m.owner.equals(r.from())) return "write to final field";
                return null;
            }
            default: {
                final Member m = findMethod(w, r.owner(), r.name() + r.desc(), missing);
                if (m == null) return missing.isEmpty() ? "missing method" : "missing class " + missing;
                final boolean wantStatic = r.kind().equals("handle") ? r.opcode() == Opcodes.H_INVOKESTATIC : r.opcode() == Opcodes.INVOKESTATIC;
                if (wantStatic != ((m.access & Opcodes.ACC_STATIC) != 0)) return "static/instance mismatch";
                if (!accessible(m, r.from())) return "method not accessible";
                final Cls owner = w.get(r.owner());
                if (owner != null && r.kind().equals("method") && (owner.access & Opcodes.ACC_INTERFACE) != 0 && r.opcode() != Opcodes.INVOKESTATIC) return "class ref to interface";
                return null;
            }
        }
    }

    static List<String> supertypes(World w, String name) {
        final List<String> out = new ArrayList<>();
        final Deque<String> todo = new ArrayDeque<>();
        final Cls c0 = w.get(name);
        if (c0 == null) return out;
        if (c0.sup != null) todo.add(c0.sup);
        todo.addAll(List.of(c0.itfs));
        final Set<String> seen = new HashSet<>();
        while (!todo.isEmpty()) {
            final String n = todo.poll();
            if (!seen.add(n)) continue;
            out.add(n);
            final Cls c = w.get(n);
            if (c == null) continue;
            if (c.sup != null) todo.add(c.sup);
            todo.addAll(List.of(c.itfs));
        }
        return out;
    }

    /** consumer method -> owner of the LavaPlayer method it overrides (or implements). */
    static Map<String, String> overrides(World w, Set<String> consumerClasses) {
        final Map<String, String> out = new TreeMap<>();
        for (String cn : consumerClasses) {
            final Cls c = w.get(cn);
            final List<String> sups = supertypes(w, cn);
            if (sups.stream().noneMatch(s -> s.startsWith(NS))) continue;
            for (Member m : c.methods.values()) {
                if ((m.access & (Opcodes.ACC_STATIC | Opcodes.ACC_PRIVATE)) != 0 || m.name.startsWith("<")) continue;
                for (String s : sups) {
                    if (!s.startsWith(NS)) continue;
                    final Cls sc = w.get(s);
                    if (sc == null) continue;
                    final Member sm = sc.methods.get(m.name + m.desc);
                    if (sm != null && (sm.access & (Opcodes.ACC_STATIC | Opcodes.ACC_PRIVATE)) == 0) {
                        out.merge(cn + "." + m.name + m.desc, s, (a, b) -> a + "," + b);
                    }
                }
            }
        }
        return out;
    }

    /** Concrete consumer classes that would inherit an abstract LavaPlayer method with no implementation. */
    static Set<String> unimplemented(World w, Set<String> consumerClasses) {
        final Set<String> out = new TreeSet<>();
        for (String cn : consumerClasses) {
            final Cls c = w.get(cn);
            if ((c.access & (Opcodes.ACC_ABSTRACT | Opcodes.ACC_INTERFACE)) != 0) continue;
            final List<String> sups = supertypes(w, cn);
            if (sups.stream().noneMatch(s -> s.startsWith(NS))) continue;
            for (String s : sups) {
                if (!s.startsWith(NS)) continue;
                final Cls sc = w.get(s);
                if (sc == null) continue;
                for (Member am : sc.methods.values()) {
                    if ((am.access & Opcodes.ACC_ABSTRACT) == 0) continue;
                    final Member impl = findConcrete(w, cn, am.name + am.desc);
                    if (impl == null) out.add(cn + " lacks " + s + "." + am.name + am.desc);
                }
            }
        }
        return out;
    }

    static Member findConcrete(World w, String cn, String key) {
        for (String n = cn; n != null; ) {
            final Cls c = w.get(n);
            if (c == null) return null;
            final Member m = c.methods.get(key);
            if (m != null && (m.access & Opcodes.ACC_ABSTRACT) == 0) return m;
            n = c.sup;
        }
        for (String s : supertypes(w, cn)) {
            final Cls c = w.get(s);
            if (c == null || (c.access & Opcodes.ACC_INTERFACE) == 0) continue;
            final Member m = c.methods.get(key);
            if (m != null && (m.access & Opcodes.ACC_ABSTRACT) == 0) return m;  // default method
        }
        return null;
    }

    static List<Path> paths(String csv) {
        final List<Path> out = new ArrayList<>();
        if (csv != null && !csv.isEmpty()) for (String s : csv.split(",")) out.add(Paths.get(s));
        return out;
    }

    public static void main(String[] args) throws Exception {
        final Path report = Paths.get(args[0]);
        final Map<String, String> opt = new HashMap<>();
        for (int i = 1; i + 1 < args.length; i += 2) opt.put(args[i], args[i + 1]);
        final List<Path> oldJars = paths(opt.get("--old")), newJars = paths(opt.get("--new"));
        final List<Path> consumers = paths(opt.get("--consumers")), extra = paths(opt.get("--extra"));

        final List<Path> oldWorldJars = new ArrayList<>(consumers); oldWorldJars.addAll(oldJars); oldWorldJars.addAll(extra);
        final List<Path> newWorldJars = new ArrayList<>(consumers); newWorldJars.addAll(newJars); newWorldJars.addAll(extra);
        final World oldW = world(oldWorldJars), newW = world(newWorldJars);

        final Map<String, byte[]> consumerBytes = classesOf(consumers);
        final Set<String> consumerClasses = new TreeSet<>(consumerBytes.keySet());
        final Map<String, Integer> perConsumer = new TreeMap<>();
        final Set<String> distinct = new TreeSet<>();
        final List<Ref> checked = new ArrayList<>();
        for (Map.Entry<String, byte[]> e : consumerBytes.entrySet()) {
            for (Ref r : refsOf(e.getValue())) {
                if (r.owner() == null || !r.owner().startsWith(NS)) continue;
                checked.add(r);
                distinct.add(r.key());
            }
        }
        final Map<String, String> oldProblems = new TreeMap<>(), newProblems = new TreeMap<>();
        for (Ref r : checked) {
            final String po = check(oldW, r), pn = check(newW, r);
            if (po != null) oldProblems.put(r.from() + " -> " + r.key(), po);
            if (pn != null) newProblems.put(r.from() + " -> " + r.key(), pn);
        }
        final Map<String, String> regressions = new TreeMap<>(newProblems);
        regressions.keySet().removeAll(oldProblems.keySet());

        final Map<String, String> ovOld = overrides(oldW, consumerClasses), ovNew = overrides(newW, consumerClasses);
        final Map<String, String> lostOverrides = new TreeMap<>();
        for (Map.Entry<String, String> e : ovOld.entrySet()) if (!ovNew.containsKey(e.getKey())) lostOverrides.put(e.getKey(), e.getValue());
        final Set<String> absOld = unimplemented(oldW, consumerClasses), absNew = unimplemented(newW, consumerClasses);
        final Set<String> newAbstract = new TreeSet<>(absNew); newAbstract.removeAll(absOld);

        // Public/protected API removed or narrowed between OLD and NEW jars.
        final World oldOnly = world(oldJars), newOnly = world(newJars);
        final List<String> apiRemoved = new ArrayList<>();
        int apiClasses = 0;
        for (Map.Entry<String, Cls> e : oldOnly.classes.entrySet()) {
            final Cls o = e.getValue();
            if ((o.access & Opcodes.ACC_PUBLIC) == 0) continue;
            apiClasses++;
            final Cls n = newOnly.classes.get(e.getKey());
            if (n == null) { apiRemoved.add("class " + e.getKey()); continue; }
            if ((n.access & Opcodes.ACC_PUBLIC) == 0) apiRemoved.add("class no longer public " + e.getKey());
            if ((n.access & Opcodes.ACC_FINAL) != 0 && (o.access & Opcodes.ACC_FINAL) == 0) apiRemoved.add("class became final " + e.getKey());
            if (!java.util.Objects.equals(o.sup, n.sup)) apiRemoved.add("superclass changed " + e.getKey() + " " + o.sup + " -> " + n.sup);
            if (!Set.of(n.itfs).containsAll(Set.of(o.itfs))) apiRemoved.add("interfaces removed " + e.getKey());
            for (Map<String, Member>[] pair : List.of(new Map[] {o.methods, n.methods}, new Map[] {o.fields, n.fields})) {
                for (Member om : pair[0].values()) {
                    if ((om.access & (Opcodes.ACC_PUBLIC | Opcodes.ACC_PROTECTED)) == 0) continue;
                    final Member nm = pair[1].get(om.name + (pair[0] == o.fields ? ":" : "") + om.desc);
                    final String id = e.getKey() + "." + om.name + om.desc;
                    if (nm == null) { apiRemoved.add("removed " + id); continue; }
                    if ((nm.access & (Opcodes.ACC_PUBLIC | Opcodes.ACC_PROTECTED)) == 0 || ((om.access & Opcodes.ACC_PUBLIC) != 0 && (nm.access & Opcodes.ACC_PUBLIC) == 0)) apiRemoved.add("narrowed " + id);
                    if (((om.access ^ nm.access) & Opcodes.ACC_STATIC) != 0) apiRemoved.add("static changed " + id);
                    if ((nm.access & Opcodes.ACC_FINAL) != 0 && (om.access & Opcodes.ACC_FINAL) == 0 && pair[0] == o.methods) apiRemoved.add("became final " + id);
                    if ((nm.access & Opcodes.ACC_ABSTRACT) != 0 && (om.access & Opcodes.ACC_ABSTRACT) == 0) apiRemoved.add("became abstract " + id);
                }
            }
        }

        final StringBuilder sb = new StringBuilder("{\n");
        kv(sb, "consumer_jars", consumers.toString()); kv(sb, "old_jars", oldJars.toString()); kv(sb, "new_jars", newJars.toString());
        num(sb, "consumer_classes", consumerClasses.size());
        num(sb, "references_checked", checked.size());
        num(sb, "distinct_references", distinct.size());
        num(sb, "public_api_classes_compared", apiClasses);
        list(sb, "unresolved_in_old", oldProblems);
        list(sb, "unresolved_in_new", newProblems);
        list(sb, "regressions", regressions);
        num(sb, "overrides_old", ovOld.size()); num(sb, "overrides_new", ovNew.size());
        list(sb, "lost_overrides", lostOverrides);
        arr(sb, "new_unimplemented_abstract", newAbstract);
        arr(sb, "api_removed_or_narrowed", apiRemoved);
        final boolean ok = regressions.isEmpty() && lostOverrides.isEmpty() && newAbstract.isEmpty() && !checked.isEmpty();
        sb.append("  \"status\": \"").append(ok ? "COMPATIBLE" : "INCOMPATIBLE").append("\"\n}\n");
        Files.writeString(report, sb.toString(), StandardCharsets.UTF_8);
        System.out.println("FD_API_COMPAT " + (ok ? "COMPATIBLE" : "INCOMPATIBLE") + " refs=" + checked.size()
                + " distinct=" + distinct.size() + " regressions=" + regressions.size() + " api_removed=" + apiRemoved.size());
    }

    static String q(String s) { return "\"" + s.replace("\\", "\\\\").replace("\"", "\\\"") + "\""; }
    static void kv(StringBuilder sb, String k, String v) { sb.append("  ").append(q(k)).append(": ").append(q(v)).append(",\n"); }
    static void num(StringBuilder sb, String k, long v) { sb.append("  ").append(q(k)).append(": ").append(v).append(",\n"); }
    static void list(StringBuilder sb, String k, Map<String, String> m) {
        sb.append("  ").append(q(k)).append(": {");
        boolean first = true;
        for (Map.Entry<String, String> e : m.entrySet()) { sb.append(first ? "\n" : ",\n").append("    ").append(q(e.getKey())).append(": ").append(q(e.getValue())); first = false; }
        sb.append(first ? "},\n" : "\n  },\n");
    }
    static void arr(StringBuilder sb, String k, Iterable<String> it) {
        sb.append("  ").append(q(k)).append(": [");
        boolean first = true;
        for (String s : it) { sb.append(first ? "\n" : ",\n").append("    ").append(q(s)); first = false; }
        sb.append(first ? "],\n" : "\n  ],\n");
    }
}

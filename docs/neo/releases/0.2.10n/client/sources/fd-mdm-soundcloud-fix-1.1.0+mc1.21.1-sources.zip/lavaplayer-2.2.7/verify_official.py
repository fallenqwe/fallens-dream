"""Verifies the OFFICIAL net.hycrafthd.lavaplayer 2.2.7-fix-j8 binaries (repo.u-team.info) as a drop-in for the
2.2.4-fix-j8 set bundled in Music Disc Maker 3.1.2. No network: works on official/ (downloaded 29.10.2026 together
with the repository's .sha1/.sha256/.sha512/.md5 files), the local git clone ../upstream/lavaplayer, the HyCraftHD
public key saved from https://github.com/HyCraftHD.gpg, and the MDM 3.1.2 jar.

Checks
 1. sha256/sha512/sha1/md5 of the three jars equal the repository checksum files and the pins below.
 2. lava-common and lavaplayer-natives 2.2.7: every entry byte-identical to the 2.2.4 copies inside MDM -> not swapped.
 3. lavaplayer 2.2.7 vs 2.2.4: unchanged entries byte-identical; every changed/added class belongs to a source file that
    changed between tags 2.2.4-fix-j8..2.2.7-fix-j8 (or to TwitchStreamAudioSourceManager, which inlines a changed
    TwitchConstants string); each changed/added class is structurally equal to the same source of tag commit e015745
    compiled here (javac 21 --release 8 -g), ignoring only documented javac 8->21 synthetic-code differences.
 4. Tag 2.2.7-fix-j8: annotated, signed with HyCraftHD key BA1F075F663CAA9578B34FCB7A12F4B73B0E64BB (isolated GNUPGHOME),
    points to e0157454; the PR part of the merge has the same patch-id as lavalink-devs/lavaplayer#202 (807644f).
 5. Binary linkage (compat/ApiCompat, ASM): every com/sedmelluq reference of MDM's adapter lavaplayer.jar.packed and
    youtube-source v2/common 1.18.2 resolves against 2.2.7 as it does against 2.2.4; no lost overrides; no new
    unimplemented abstract methods; public/protected API removed between the versions listed. Controls: 2.2.4 vs 2.2.4
    (must be clean) and a 2.2.7 jar with SoundCloudAudioSourceManager deleted (must be INCOMPATIBLE).

Usage: python -I verify_official.py   -> out/verify-report.json
"""
import hashlib, io, json, os, re, runpy, shutil, subprocess, tempfile, zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
WS = next(p for p in HERE.parents if (p / 'AGENTS.md').is_file())
GIT_REPO = ROOT / 'upstream/lavaplayer'
OFFICIAL = HERE / 'official'
JDK = Path('C:/Users/falle/AppData/Roaming/PrismLauncher/instances/Fallens-Dream-1.21.1/runtime/java21/bin')
PRISM = Path('C:/Users/falle/AppData/Roaming/PrismLauncher/libraries')
ASM = [PRISM / 'org/ow2/asm/asm/9.10.1/asm-9.10.1.jar', PRISM / 'org/ow2/asm/asm-tree/9.10.1/asm-tree-9.10.1.jar']
SLF4J = PRISM / 'org/slf4j/slf4j-api/2.0.9/slf4j-api-2.0.9.jar'
MDM = WS / 'work/fixes-0.2.9n-2026-10-27/mods/probes/server/server-candidate-0.1.1-eb60485a/mods/music_disc_maker-3.1.2+neoforge-1.21.1.jar'
MDM_SHA256 = '0ab40af2e50140b54f334e948fccccad326640e08bdc7902302e90d6f53f0ad0'
PINS = {'lavaplayer': '9fad1837ab8d10f7e474e232adba8c6ecddb97dc7750a70550952c10aa7f6a50',
        'lava-common': '490ab8d65b0451a8248f1a0067408fd7116c4f982424340e7a05a4a265c04767',
        'lavaplayer-natives': 'af03950c596d7efec228a019fc7ead751da69e8f6d74b2d52f29133a16991e84'}
TAG, TAG_COMMIT, BASE_TAG = '2.2.7-fix-j8', 'e0157454a744ddd6d067ba1dc19f197b15470483', '2.2.4-fix-j8'
KEY_FPR = 'BA1F075F663CAA9578B34FCB7A12F4B73B0E64BB'
PR_COMMIT = '807644faa1592bf2894b6a5303198525dbe776ff'
SRC = 'main/src/main/java/'
EXTRA_SOURCES = {'com/sedmelluq/discord/lavaplayer/source/twitch/TwitchStreamAudioSourceManager'}  # inlines TwitchConstants
GPG = Path('C:/Program Files/Git/usr/bin/gpg.exe')


def sha(b, algo='sha256'): return hashlib.new(algo, b).hexdigest()


def run(argv, **kw):
    r = subprocess.run([str(a) for a in argv], capture_output=True, text=True, encoding='utf-8', errors='replace', **kw)
    return r.returncode, r.stdout + r.stderr


def git(*args):
    code, out = run(['git', '-C', GIT_REPO, *args])
    assert code == 0, out
    return out


def entries(data):
    with zipfile.ZipFile(io.BytesIO(data)) as z:
        return {i.filename: z.read(i) for i in z.infolist()}


def msys(path):
    """Git-for-Windows gpg is an MSYS program: it needs /c/... paths (a C:/... GNUPGHOME is taken as relative)."""
    p = Path(path).resolve()
    return '/' + p.drive[0].lower() + p.as_posix()[2:]


def compare(lib, a, b, work, name):
    """compare_structure plus one more documented javac 8->21 difference: an Object method called on an interface-typed
    receiver is emitted as InterfaceMethod I.toString (javac 9+) instead of Method java/lang/Object.toString (javac 8)."""
    eq, d = lib['compare_structure'](lib['structure'](a, work, 'c/' + name), lib['structure'](b, work, 'o/' + name))
    if eq or set(d) != {'calls'}: return eq, d
    obj = {'toString:()Ljava/lang/String;', 'hashCode:()I', 'equals:(Ljava/lang/Object;)Z'}
    co = [c for c in d['calls']['compiled_only'] if not (c.startswith('InterfaceMethod ') and c.split('.', 1)[1] in obj)]
    so = [c for c in d['calls']['shipped_only'] if not (c.startswith('Method java/lang/Object.') and c.split('.', 1)[1] in obj)]
    return (not co and not so), ({'calls': {'compiled_only': co, 'shipped_only': so}} if co or so else {'allowed_object_method_on_interface': d['calls']})


def main():
    lib = runpy.run_path(str(HERE / 'bytecode_compare.py'), run_name='lib')  # javac()/structure()/compare_structure()
    out = HERE / 'out'; out.mkdir(exist_ok=True)
    work = Path(tempfile.mkdtemp(prefix='fdsc-227-verify-'))
    rep = {}
    try:
        # 1. checksums
        jars = {}
        rep['checksums'] = {}
        for a, pin in PINS.items():
            f = OFFICIAL / f'{a}-2.2.7-fix-j8.jar'
            b = f.read_bytes(); jars[a] = b
            r = {algo: sha(b, algo) == (OFFICIAL / f'{f.name}.{algo}').read_text().strip() for algo in ('sha1', 'sha256', 'sha512', 'md5')}
            r['pinned'] = sha(b) == pin
            r['sha256'] = sha(b)
            rep['checksums'][a] = r
            assert all(v for k, v in r.items() if k != 'sha256'), (a, r)

        mdm = MDM.read_bytes(); assert sha(mdm) == MDM_SHA256
        packed = {}
        with zipfile.ZipFile(io.BytesIO(mdm)) as z:
            for n in z.namelist():
                if n.startswith('dependencies/') and n.endswith('.jar.packed'):
                    packed[n.split('/', 1)[1]] = z.read(n)
        for n, b in packed.items(): (work / n).write_bytes(b)

        # 2. lava-common / natives
        rep['unchanged_artifacts'] = {}
        for a in ('lava-common', 'lavaplayer-natives'):
            o, n = entries(packed[f'{a}-2.2.4-fix-j8.jar.packed']), entries(jars[a])
            same = o.keys() == n.keys() and all(o[k] == n[k] for k in o)
            rep['unchanged_artifacts'][a] = {'entries': len(o), 'all_entries_identical_to_2.2.4': same}
            assert same, a

        # 3. lavaplayer content vs 2.2.4 and vs tag source
        old, new = entries(packed['lavaplayer-2.2.4-fix-j8.jar.packed']), entries(jars['lavaplayer'])
        changed = sorted(k for k in old if k in new and old[k] != new[k])
        added = sorted(k for k in new if k not in old)
        removed = sorted(k for k in old if k not in new)
        untouched = [k for k in old if k in new and old[k] == new[k]]
        changed_sources = sorted(p[len(SRC):-5] for p in git('diff', '--name-only', BASE_TAG, TAG).split() if p.startswith(SRC) and p.endswith('.java'))
        need = sorted(set(changed_sources) | EXTRA_SOURCES)
        cls = [k for k in changed + added if k.endswith('.class')]
        unexplained = [k for k in cls if k[:-6].split('$', 1)[0] not in need]
        srcdir = work / 'src'
        for s in need:
            p = srcdir / (s + '.java'); p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text(git('show', f'{TAG_COMMIT}:{SRC}{s}.java'), encoding='utf-8')
        (work / 'lp227.jar').write_bytes(jars['lavaplayer'])
        cp = [work / 'lp227.jar'] + [work / n for n in packed if n not in ('lavaplayer-2.2.4-fix-j8.jar.packed', 'lavaplayer.jar.packed')] + [SLF4J]
        compiled = lib['javac']([srcdir / (s + '.java') for s in need], cp, work / 'classes-227', work)
        structural = {}
        for k in cls:
            if k not in compiled:
                structural[k] = {'equal': False, 'detail': 'not produced by compiling the tag sources'}; continue
            eq, d = compare(lib, compiled[k], new[k], work, k)
            structural[k] = {'equal': eq, 'detail': d}
        # every class compiled from the changed sources that is NOT in changed/added must be byte-identical to 2.2.4
        same_as_old = sorted(k for k in compiled if k not in cls)
        same_as_old_ok = all(k in new and k in old and new[k] == old[k] for k in same_as_old)
        control_eq, _ = lib['compare_structure'](lib['structure'](new['com/sedmelluq/discord/lavaplayer/source/soundcloud/DefaultSoundCloudFormatHandler.class'], work, 'x/n'),
                                                 lib['structure'](old['com/sedmelluq/discord/lavaplayer/source/soundcloud/DefaultSoundCloudFormatHandler.class'], work, 'x/o'))
        rep['lavaplayer'] = {
            'entries_2.2.4': len(old), 'entries_2.2.7': len(new), 'untouched_byte_identical': len(untouched),
            'changed': changed, 'added': added, 'removed': removed,
            'changed_source_files_between_tags': changed_sources, 'sources_compiled_from_tag_commit': need,
            'unexplained_changed_classes': unexplained, 'structural_vs_tag_source': structural,
            'other_compiled_classes_identical_to_2.2.4': same_as_old_ok, 'compiled_but_unchanged': same_as_old,
            'version_txt': new.get('com/sedmelluq/discord/lavaplayer/tools/version.txt', b'').decode(),
            'negative_control_2.2.7_vs_2.2.4_DefaultSoundCloudFormatHandler_equal': control_eq,
            'class_major_versions': sorted({int.from_bytes(new[k][6:8], 'big') for k in cls}),
        }
        lp_ok = (not removed and not unexplained and all(v['equal'] for v in structural.values()) and same_as_old_ok and not control_eq
                 and rep['lavaplayer']['version_txt'] == '2.2.7-fix-j8')

        # 4. tag signature + patch-id
        tag_obj = git('cat-file', 'tag', TAG)
        payload, sig = tag_obj.split('-----BEGIN PGP SIGNATURE-----', 1)
        (work / 'tag.payload').write_bytes(payload.encode('utf-8')); (work / 'tag.sig').write_bytes(('-----BEGIN PGP SIGNATURE-----' + sig).encode('utf-8'))
        home = work / 'gnupg'; home.mkdir(); os.chmod(home, 0o700)
        env = dict(os.environ, GNUPGHOME=msys(home))
        run([GPG, '--batch', '--quiet', '--import', msys(HERE / 'keys/HyCraftHD-github.gpg')], env=env)
        code, gout = run([GPG, '--batch', '--status-fd', '1', '--verify', msys(work / 'tag.sig'), msys(work / 'tag.payload')], env=env)
        rep_gpg_tail = [l for l in gout.splitlines() if l.startswith('[GNUPG:]')]
        valid = re.search(r'\[GNUPG:\] VALIDSIG (\w+)', gout)
        pid_pr = git('show', PR_COMMIT).encode()
        p1 = subprocess.run(['git', '-C', str(GIT_REPO), 'patch-id', '--stable'], input=pid_pr, capture_output=True).stdout.decode().split()[0]
        merge_parent = git('rev-parse', f'{TAG_COMMIT}^1').strip()
        diff = subprocess.run(['git', '-C', str(GIT_REPO), 'diff', merge_parent, TAG_COMMIT], capture_output=True).stdout
        p2 = subprocess.run(['git', '-C', str(GIT_REPO), 'patch-id', '--stable'], input=diff, capture_output=True).stdout.decode().split()[0]
        rep['tag'] = {'object': re.search(r'^object (\w+)', tag_obj, re.M).group(1), 'tagger': re.search(r'^tagger (.*)$', tag_obj, re.M).group(1),
                      'good_signature': '[GNUPG:] GOODSIG' in gout, 'valid_sig_fingerprint': valid.group(1) if valid else None,
                      'key_source': 'https://github.com/HyCraftHD.gpg (keys/HyCraftHD-github.gpg)',
                      'gpg_status': rep_gpg_tail, 'merge_first_parent': merge_parent, 'pr_patch_id': p1, 'merge_patch_id': p2,
                      'merge_equals_pr_202': p1 == p2}
        tag_ok = rep['tag']['object'] == TAG_COMMIT and rep['tag']['good_signature'] and rep['tag']['valid_sig_fingerprint'] == KEY_FPR and p1 == p2

        # 5. binary linkage
        compat_cls = work / 'compat-classes'; compat_cls.mkdir()
        code, log = run([JDK / 'javac.exe', '--release', '21', '-proc:none', '-cp', ';'.join(map(str, ASM)), '-d', compat_cls,
                         *sorted((HERE / 'compat/src').rglob('*.java'))])
        assert code == 0, log
        consumers = [work / n for n in ('lavaplayer.jar.packed', 'v2-1.18.2.jar.packed', 'common-1.18.2.jar.packed')]
        extra = [work / n for n in packed if n not in ('lavaplayer.jar.packed', 'v2-1.18.2.jar.packed', 'common-1.18.2.jar.packed', 'lavaplayer-2.2.4-fix-j8.jar.packed')]
        broken = work / 'lp227-without-SoundCloudAudioSourceManager.jar'
        with zipfile.ZipFile(io.BytesIO(jars['lavaplayer'])) as zi, zipfile.ZipFile(broken, 'w') as zo:
            for i in zi.infolist():
                if i.filename != 'com/sedmelluq/discord/lavaplayer/source/soundcloud/SoundCloudAudioSourceManager.class':
                    zo.writestr(i, zi.read(i))
        rep['compat'] = {}
        for name, newjar in (('2.2.4_vs_2.2.7', work / 'lp227.jar'), ('control_2.2.4_vs_2.2.4', work / 'lavaplayer-2.2.4-fix-j8.jar.packed'),
                             ('negative_control_missing_class', broken)):
            rj = work / f'compat-{name}.json'
            code, log = run([JDK / 'java.exe', '-cp', ';'.join(map(str, [compat_cls, *ASM])), 'fdcompat.ApiCompat', rj,
                             '--old', work / 'lavaplayer-2.2.4-fix-j8.jar.packed', '--new', newjar,
                             '--consumers', ','.join(map(str, consumers)), '--extra', ','.join(map(str, extra))])
            assert code == 0, log
            rep['compat'][name] = json.loads(rj.read_text('utf-8'))
            shutil.copyfile(rj, out / f'compat-{name}.json')
        c, c0, cn = rep['compat']['2.2.4_vs_2.2.7'], rep['compat']['control_2.2.4_vs_2.2.4'], rep['compat']['negative_control_missing_class']
        compat_ok = (c['status'] == 'COMPATIBLE' and not c['unresolved_in_new'] and not c['api_removed_or_narrowed']
                     and c0['status'] == 'COMPATIBLE' and not c0['unresolved_in_old'] and cn['status'] == 'INCOMPATIBLE')

        rep['verdict'] = {'checksums': True, 'lava_common_and_natives_identical': True, 'lavaplayer_delta_matches_tag_source': lp_ok,
                          'tag_signed_and_contains_pr_202': tag_ok, 'binary_compatible_with_mdm_adapter_and_youtube_source': compat_ok}
        rep['status'] = 'PASS' if all(rep['verdict'].values()) else 'FAIL'
        (out / 'verify-report.json').write_text(json.dumps(rep, ensure_ascii=False, indent=2) + '\n', encoding='utf-8', newline='\n')
        print(json.dumps({'status': rep['status'], 'verdict': rep['verdict'],
                          'lavaplayer': {k: rep['lavaplayer'][k] for k in ('entries_2.2.4', 'entries_2.2.7', 'untouched_byte_identical', 'unexplained_changed_classes', 'version_txt')},
                          'structural_all_equal': all(v['equal'] for v in structural.values()), 'structural_count': len(structural),
                          'compat': {k: {x: v[x] for x in ('status', 'references_checked', 'distinct_references', 'overrides_old', 'overrides_new')} | {'regressions': len(v['regressions']), 'api_removed': len(v['api_removed_or_narrowed'])} for k, v in rep['compat'].items()},
                          'tag': rep['tag']}, indent=1))
        raise SystemExit(0 if rep['status'] == 'PASS' else 1)
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == '__main__':
    main()

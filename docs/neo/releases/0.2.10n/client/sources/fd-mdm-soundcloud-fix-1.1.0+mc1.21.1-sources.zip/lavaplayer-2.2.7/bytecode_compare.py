"""Bytecode helpers shared by verify_official.py (copied from ../lavaplayer-patch/build_lavaplayer.py, which is
superseded): javac wrapper and the structural class comparison that tolerates only documented javac 8 -> 21
synthetic-code differences."""
import re, subprocess
from pathlib import Path

JDK = Path('C:/Users/falle/AppData/Roaming/PrismLauncher/instances/Fallens-Dream-1.21.1/runtime/java21/bin')


def run(argv, **kw):
    r = subprocess.run([str(a) for a in argv], capture_output=True, text=True, encoding='utf-8', errors='replace', **kw)
    return r.returncode, r.stdout + r.stderr


def javac(sources, classpath, out, work):
    out.mkdir(parents=True, exist_ok=True)
    empty = work / 'empty-sourcepath'; empty.mkdir(exist_ok=True)
    args = ['--release', '8', '-g', '-encoding', 'UTF-8', '-proc:none', '-implicit:none', '-nowarn', '-Xlint:-options',
            '-sourcepath', str(empty), '-cp', ';'.join(str(p) for p in classpath), '-d', str(out), *[str(s) for s in sources]]
    argfile = work / f'javac-{out.name}.args'
    argfile.write_text('\n'.join('"' + a.replace('\\', '/') + '"' for a in args), encoding='utf-8')
    code, log = run([JDK / 'javac.exe', '@' + str(argfile)])
    (work / f'javac-{out.name}.log').write_text(log, encoding='utf-8')
    assert code == 0, log[-4000:]
    return {p.relative_to(out).as_posix(): p.read_bytes() for p in sorted(out.rglob('*.class'))}


def javap_text(class_bytes, work, name, *flags):
    d = work / 'javap' / name.replace('/', '_'); d.mkdir(parents=True, exist_ok=True)
    f = d / 'X.class'; f.write_bytes(class_bytes)
    code, text = run([JDK / 'javap.exe', *flags, str(f)])
    assert code == 0, text
    return text


# The shipped JAR was compiled by javac 8 (Gradle toolchain 8); only javac 21 is available here (no JDK download).
# Known javac 8 -> 21 code generation differences, each of which only changes compiler-synthesised code:
#  - enum `$values()` helper (JDK-8241798, javac 15+);
#  - null check of a bound method reference: Object.getClass() (javac 8) vs Objects.requireNonNull (javac 9+);
#  - try-with-resources desugaring: javac 8 inlines close()/Throwable.addSuppressed twice, javac 11+ differently;
#  - extra checkcast of a generic argument (only adds `class` refs to types already used by the class).
KNOWN_ARTIFACT_REFS = {'Method java/util/Objects.requireNonNull:(Ljava/lang/Object;)Ljava/lang/Object;',
                       'Method java/lang/Object.getClass:()Ljava/lang/Class;',
                       'Method java/lang/Throwable.addSuppressed:(Ljava/lang/Throwable;)V'}


def structure(class_bytes, work, name):
    sig = javap_text(class_bytes, work, name + '.sig', '-p', '-s')
    lines = [l.strip() for l in sig.splitlines() if l.strip() and not l.startswith('Compiled from')]
    members, i = [], 0
    while i < len(lines):
        if lines[i].startswith('descriptor:'): i += 1; continue
        if ' $values()' in lines[i]: i += 2; continue  # synthetic helper + its descriptor line
        members.append(lines[i]); i += 1
    code = javap_text(class_bytes, work, name + '.code', '-c', '-p', '-constants')
    refs = [re.sub(r'#\d+:', '#:', m.group(1).strip()) for m in re.finditer(r'// ((?:Method|Field|InterfaceMethod|String|class|InvokeDynamic) .*)', code)]
    refs = [r for r in refs if not r.startswith('Method $values:')]
    return {'members': sorted(members),
            'strings': sorted(r for r in refs if r.startswith('String ')),
            'calls': sorted({r for r in refs if r.startswith(('Method ', 'InterfaceMethod ', 'Field ', 'InvokeDynamic ')) and r not in KNOWN_ARTIFACT_REFS}),
            'classes': sorted({r for r in refs if r.startswith('class ')})}


def compare_structure(a, b):
    """a = compiled from source here, b = shipped. Returns (equal, differences)."""
    diff = {}
    for k in ('members', 'strings', 'calls'):
        if a[k] != b[k]: diff[k] = {'compiled_only': sorted(set(a[k]) - set(b[k])), 'shipped_only': sorted(set(b[k]) - set(a[k]))}
    shipped_only = sorted(set(b['classes']) - set(a['classes']))
    compiled_only = sorted(set(a['classes']) - set(b['classes']))
    if shipped_only: diff['classes'] = {'shipped_only': shipped_only}
    # extra checkcast: allowed only for a type that the shipped class already names in a member/call descriptor
    shipped_text = ' '.join(b['members'] + b['calls'])
    bad = [c for c in compiled_only if 'L' + c[len('class '):] + ';' not in shipped_text]
    if bad: diff['classes_unexplained'] = bad
    return not diff, diff | ({'allowed_extra_checkcast': compiled_only} if compiled_only and not bad else {})



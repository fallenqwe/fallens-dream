package fd.mdmscfix;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HexFormat;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.Map;
import java.util.Set;
import java.util.TreeSet;

/**
 * Pure decision logic (no loader classes): may Music Disc Maker's bundled LavaPlayer 2.2.4-fix-j8 be swapped for 2.2.7-fix-j8?
 *
 * <p>The swap happens only when every pinned fact holds: MDM is exactly {@value #MDM_VERSION}, the set of bundled
 * {@code dependencies/*.jar.packed} files has exactly the expected names and sha256 values, and the replacement JAR
 * shipped inside this mod (official LavaPlayer 2.2.7-fix-j8) has its pinned name and sha256. Anything else is a {@link Mismatch} and the caller keeps the
 * original set untouched.
 */
public final class PackedGate {

    public static final String MDM_VERSION = "3.1.2";
    public static final String ORIGINAL_NAME = "lavaplayer-2.2.4-fix-j8.jar.packed";
    /**
     * The official, unmodified net.hycrafthd.lavaplayer:lavaplayer:2.2.7-fix-j8 jar (contains lavalink-devs/lavaplayer#202).
     * The name carries the first 8 hex digits of its sha256: MDM reuses an extraction folder by name+size only, so any
     * other content gets another name and therefore another folder (build.py enforces name == hash prefix).
     */
    public static final String REPLACEMENT_SHA256 = "9fad1837ab8d10f7e474e232adba8c6ecddb97dc7750a70550952c10aa7f6a50";
    public static final String REPLACEMENT_NAME = "lavaplayer-2.2.7-fix-j8-9fad1837.jar.packed";

    /** sha256 of every dependencies/*.jar.packed inside music_disc_maker-3.1.2+neoforge-1.21.1.jar. */
    public static final Map<String, String> EXPECTED = Map.ofEntries(
            Map.entry("annotations-24.0.0.jar.packed", "ff112f54ce874b8ae899cfd68f0315d96c9f406a338b8eca80c76d10e2e5a2f7"),
            Map.entry("base64-2.3.9.jar.packed", "f1a0e359eee29a5939c35e5fdedc574dd7e8ca065b056fc14b2b29e3ed3cd54d"),
            Map.entry("common-1.18.2.jar.packed", "39d69799576f35497ce4fc70c40f0b052b511dcc77c510f08e6e1fa0e3bd64e8"),
            Map.entry("commons-codec-1.11.jar.packed", "e599d5318e97aa48f42136a2927e6dfa4e8881dff0e6c8e3109ddbbff51d7b7d"),
            Map.entry("commons-io-2.13.0.jar.packed", "671eaa39688dac2ffaa4645b3c9980ae2d0ea2471e4ae6a5da199cd15ae23666"),
            Map.entry("httpclient-4.5.14.jar.packed", "c8bc7e1c51a6d4ce72f40d2ebbabf1c4b68bfe76e732104b04381b493478e9d6"),
            Map.entry("httpcore-4.4.16.jar.packed", "6c9b3dd142a09dc468e23ad39aad6f75a0f2b85125104469f026e52a474e464f"),
            Map.entry("jackson-annotations-2.15.2.jar.packed", "04e21f94dcfee4b078fa5a5f53047b785aaba69d19de392f616e7a7fe5d3882f"),
            Map.entry("jackson-core-2.15.2.jar.packed", "303c99e82b1faa91a0bae5d8fbeb56f7e2adf9b526a900dd723bf140d62bd4b4"),
            Map.entry("jackson-databind-2.15.2.jar.packed", "0eb2fdad6e40ab8832a78c9b22f58196dd970594e8d3d5a26ead87847c4f3a96"),
            Map.entry("jcl-over-slf4j-2.0.17.jar.packed", "affd06771589ebfe454bb11315a4f466ecaa135b95f3e7939534cf1d2fd7064c"),
            Map.entry("json-20240303.jar.packed", "3cf6cd6892e32e2b4c1c39e0f52f5248a2f5b37646fdfbb79a66b46b618414ed"),
            Map.entry("jsoup-1.16.1.jar.packed", "1f115726540ddf71958c14bc517ebfc49cf481e91cd917b0face84f01272e901"),
            Map.entry("lava-common-2.2.4-fix-j8.jar.packed", "c84888796b15a7abae879cd132874222f679dfef619269edf1bc6ddf03197647"),
            Map.entry("lavaplayer-2.2.4-fix-j8.jar.packed", "d9b935782d690f18af080ba43b9f418d9dd3f4e7b452dd8880452152849f36e1"),
            Map.entry("lavaplayer-natives-2.2.4-fix-j8.jar.packed", "4aae2e0c3c2d9cee59e8cb47cf2b3ba9ddb571ed6711ac4fe321f015a2a8a125"),
            Map.entry("lavaplayer.jar.packed", "0e7230a5eddec40fad53fe0b8606d68fac1af879011762a5684a0d2b6aad4500"),
            Map.entry("nanojson-1.7.jar.packed", "bdbbb5d3bede72a0d73f5ef34ed80cf22e61e5c4762e1b267fe37a45ecb0007b"),
            Map.entry("rhino-1.7.15.jar.packed", "2427fdcbc149ca0a25ccfbb7c71b01f39ad42708773a47816cd2342861766b63"),
            Map.entry("rhino-engine-1.7.15.jar.packed", "b7bbb6724812a8ba6c650cf4a1e655a24af4d73a321add5a64a54c2d5963ce00"),
            Map.entry("v2-1.18.2.jar.packed", "53aa51ac0aca44c2f6f0ffc839458a0f10c4d9eba16a45a39a352f5bbac9533c"));

    private PackedGate() {
    }

    /** A pinned fact does not hold; the message says which. */
    public static final class Mismatch extends Exception {
        private static final long serialVersionUID = 1L;

        public Mismatch(String message) {
            super(message, null, false, false);
        }
    }

    /**
     * @param packed      the set MDM is about to install (iteration order = class path order)
     * @param mdmVersion  the loaded Music Disc Maker version, or {@code null} when it is absent
     * @param replacement the replacement JAR inside this mod, or {@code null} when it cannot be located
     * @return a new set, same order, with only {@link #ORIGINAL_NAME} replaced by {@code replacement}
     */
    public static Set<Path> substitute(Set<Path> packed, String mdmVersion, Path replacement) throws Mismatch, IOException {
        if (!MDM_VERSION.equals(mdmVersion)) {
            throw new Mismatch("Music Disc Maker version is " + mdmVersion + ", this fix is only for " + MDM_VERSION);
        }
        if (packed == null || packed.isEmpty()) {
            throw new Mismatch("Music Disc Maker passed no bundled jars");
        }
        final Map<String, Path> byName = new LinkedHashMap<>();
        for (final Path path : packed) {
            final String name = fileName(path);
            if (byName.put(name, path) != null) {
                throw new Mismatch("bundled jar " + name + " is listed twice");
            }
        }
        if (!byName.keySet().equals(EXPECTED.keySet())) {
            final Set<String> missing = new TreeSet<>(EXPECTED.keySet());
            missing.removeAll(byName.keySet());
            final Set<String> extra = new TreeSet<>(byName.keySet());
            extra.removeAll(EXPECTED.keySet());
            throw new Mismatch("bundled jar set differs from Music Disc Maker 3.1.2: missing " + missing + ", unexpected " + extra);
        }
        for (final Map.Entry<String, String> expected : new java.util.TreeMap<>(EXPECTED).entrySet()) {
            final String actual = sha256(byName.get(expected.getKey()));
            if (!expected.getValue().equals(actual)) {
                throw new Mismatch("sha256 of bundled " + expected.getKey() + " is " + actual + ", expected " + expected.getValue());
            }
        }
        if (replacement == null || !Files.isRegularFile(replacement)) {
            throw new Mismatch("the replacement LavaPlayer jar is missing from this mod (" + replacement + ")");
        }
        if (!REPLACEMENT_NAME.equals(fileName(replacement))) {
            throw new Mismatch("the replacement LavaPlayer jar has an unexpected name: " + fileName(replacement));
        }
        final String actual = sha256(replacement);
        if (!REPLACEMENT_SHA256.equals(actual)) {
            throw new Mismatch("sha256 of the replacement LavaPlayer jar is " + actual + ", expected " + REPLACEMENT_SHA256);
        }
        final Set<Path> result = new LinkedHashSet<>();
        for (final Path path : packed) {
            result.add(ORIGINAL_NAME.equals(fileName(path)) ? replacement : path);
        }
        return result;
    }

    static String fileName(Path path) {
        final Path name = path == null ? null : path.getFileName();
        return name == null ? String.valueOf(path) : name.toString();
    }

    static String sha256(Path path) throws IOException {
        final MessageDigest digest;
        try {
            digest = MessageDigest.getInstance("SHA-256");
        } catch (final NoSuchAlgorithmException ex) {
            throw new IOException("SHA-256 is not available", ex);
        }
        final byte[] buffer = new byte[1 << 16];
        try (InputStream in = Files.newInputStream(path)) {
            for (int read; (read = in.read(buffer)) > 0; ) {
                digest.update(buffer, 0, read);
            }
        }
        return HexFormat.of().formatHex(digest.digest());
    }
}

package fd.mdmscfix;

import java.nio.file.Path;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.neoforged.fml.ModList;
import net.neoforged.neoforgespi.language.IModFileInfo;

/**
 * Loader-facing side of the fix. Called from {@code DependencyManagerMixin} with the set of bundled jars that Music Disc
 * Maker is about to unpack into its isolated LavaPlayer class loader. Never throws: on any mismatch or error it returns
 * the original set and logs a single WARN for the whole game session.
 */
public final class SoundCloudFix {

    public static final String MOD_ID = "fd_mdm_soundcloud_fix";
    public static final String MDM_ID = "music_disc_maker";
    public static final String RESOURCE = "fd_mdm_soundcloud_fix/" + PackedGate.REPLACEMENT_NAME;

    private static final Logger LOGGER = LoggerFactory.getLogger("FD MDM SoundCloud fix");
    private static final AtomicBoolean WARNED = new AtomicBoolean();
    private static volatile boolean disabled;

    private SoundCloudFix() {
    }

    public static Set<Path> onInstall(Set<Path> packed) {
        if (disabled) {
            return packed;
        }
        try {
            final Set<Path> result = PackedGate.substitute(packed, mdmVersion(), replacement());
            LOGGER.info("Music Disc Maker {}: using LavaPlayer {} (official 2.2.7-fix-j8 with lavalink-devs/lavaplayer#202, "
                    + "sha256 {}) instead of {} for SoundCloud AAC/HLS", PackedGate.MDM_VERSION, PackedGate.REPLACEMENT_NAME,
                    PackedGate.REPLACEMENT_SHA256, PackedGate.ORIGINAL_NAME);
            return result;
        } catch (final PackedGate.Mismatch mismatch) {
            warnOnce(mismatch.getMessage());
        } catch (final Throwable error) {
            warnOnce("unexpected " + error);
        }
        return packed;
    }

    /** Logs the single WARN of this session and turns the fix off. */
    static void warnOnce(String reason) {
        disabled = true;
        if (WARNED.compareAndSet(false, true)) {
            LOGGER.warn("SoundCloud fix for Music Disc Maker is inactive, the original LavaPlayer stays in use: {}", reason);
        }
    }

    static String mdmVersion() {
        return ModList.get().getModContainerById(MDM_ID)
                .map(container -> container.getModInfo().getVersion().toString())
                .orElse(null);
    }

    private static Path replacement() {
        final IModFileInfo self = ModList.get().getModFileById(MOD_ID);
        return self == null ? null : self.getFile().findResource(RESOURCE);
    }
}

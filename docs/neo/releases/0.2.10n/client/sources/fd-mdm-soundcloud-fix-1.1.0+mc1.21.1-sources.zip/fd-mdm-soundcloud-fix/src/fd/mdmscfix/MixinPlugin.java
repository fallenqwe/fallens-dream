package fd.mdmscfix;

import java.util.List;
import java.util.Set;

import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.fml.loading.moddiscovery.ModFileInfo;
import net.neoforged.neoforgespi.language.IModInfo;

/**
 * Registers {@code DependencyManagerMixin} only when the loading mod list contains Music Disc Maker of exactly the
 * supported version. With another version or without MDM no MDM bytecode is touched and Mixin does not even look up
 * the target class. Logs nothing: the single WARN comes from the mod entry point.
 */
public final class MixinPlugin implements IMixinConfigPlugin {

    @Override
    public void onLoad(String mixinPackage) {
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(String targetClassName, String mixinClassName) {
        return true;
    }

    @Override
    public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {
    }

    @Override
    public List<String> getMixins() {
        return supportedMdmPresent() ? List.of("DependencyManagerMixin") : null;
    }

    @Override
    public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }

    @Override
    public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
    }

    static boolean supportedMdmPresent() {
        try {
            final ModFileInfo file = FMLLoader.getLoadingModList().getModFileById(SoundCloudFix.MDM_ID);
            if (file == null) {
                return false;
            }
            for (final IModInfo mod : file.getMods()) {
                if (SoundCloudFix.MDM_ID.equals(mod.getModId())) {
                    return PackedGate.MDM_VERSION.equals(mod.getVersion().toString());
                }
            }
            return false;
        } catch (final Throwable error) {
            return false;
        }
    }
}

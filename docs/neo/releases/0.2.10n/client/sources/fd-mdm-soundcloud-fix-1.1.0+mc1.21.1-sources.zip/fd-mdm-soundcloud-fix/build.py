"""Builds fd-mdm-soundcloud-fix-1.1.0+mc1.21.1.jar (NeoForge 1.21.1) and its sources ZIP. No network, no Gradle.

Compile classpath: read-only Prism library JARs of NeoForge 21.1.264 (FML loader 4.0.45, sponge-mixin, slf4j,
maven-artifact). The bundled LavaPlayer is the official, unmodified lavaplayer-2.2.7-fix-j8.jar from
../lavaplayer-2.2.7/official (checked by ../lavaplayer-2.2.7/verify_official.py). Before packing it (STORED) as
fd_mdm_soundcloud_fix/<PackedGate.REPLACEMENT_NAME> the build checks: sha256 == PackedGate.REPLACEMENT_SHA256 ==
the repository's .sha256 file, and REPLACEMENT_NAME == lavaplayer-2.2.7-fix-j8-<first 8 hex of sha256>.jar.packed
(MDM reuses extractions by name+size, so the name must change whenever the content does).
Output timestamps are fixed, so the JAR is reproducible.

Usage: python -I build.py
"""
import hashlib, json, re, shutil, subprocess, sys, tempfile, zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
JDK = Path('C:/Users/falle/AppData/Roaming/PrismLauncher/instances/Fallens-Dream-1.21.1/runtime/java21/bin')
LIB = Path('C:/Users/falle/AppData/Roaming/PrismLauncher/libraries')
CLASSPATH = [LIB / 'net/neoforged/fancymodloader/loader/4.0.45/loader-4.0.45.jar',
             LIB / 'net/fabricmc/sponge-mixin/0.16.4+mixin.0.8.7/sponge-mixin-0.16.4+mixin.0.8.7.jar',
             LIB / 'org/slf4j/slf4j-api/2.0.9/slf4j-api-2.0.9.jar',
             LIB / 'org/apache/maven/maven-artifact/3.8.5/maven-artifact-3.8.5.jar',
             LIB / 'cpw/mods/securejarhandler/3.0.8/securejarhandler-3.0.8.jar',
             LIB / 'cpw/mods/modlauncher/11.0.5/modlauncher-11.0.5.jar',
             LIB / 'net/neoforged/bus/8.0.5/bus-8.0.5.jar',
             LIB / 'net/neoforged/mergetool/2.0.0/mergetool-2.0.0-api.jar',
             LIB / 'org/ow2/asm/asm-tree/9.10.1/asm-tree-9.10.1.jar',
             LIB / 'org/ow2/asm/asm/9.10.1/asm-9.10.1.jar']
LAVAPLAYER = HERE.parent / 'lavaplayer-2.2.7/official/lavaplayer-2.2.7-fix-j8.jar'
VERSION = '1.1.0'
JAR = f'fd-mdm-soundcloud-fix-{VERSION}+mc1.21.1.jar'
DT = (2026, 10, 29, 0, 0, 0)
MANIFEST = (f'Manifest-Version: 1.0\r\nAutomatic-Module-Name: fd_mdm_soundcloud_fix\r\n'
            f'Implementation-Title: FD Music Disc Maker SoundCloud fix\r\nImplementation-Version: {VERSION}\r\n'
            f'Implementation-Vendor: Fallen\'s Dream\r\n\r\n').encode('ascii')


def sha(b): return hashlib.sha256(b).hexdigest()


def main():
    src = sorted((HERE / 'src').rglob('*.java'))
    gate = (HERE / 'src/fd/mdmscfix/PackedGate.java').read_text('utf-8')
    pinned = re.search(r'REPLACEMENT_SHA256 = "([0-9a-f]{64})"', gate).group(1)
    name = re.search(r'REPLACEMENT_NAME = "([^"]+)"', gate).group(1)
    lavaplayer = LAVAPLAYER.read_bytes()
    assert sha(lavaplayer) == pinned, f'LavaPlayer {sha(lavaplayer)} != pinned {pinned}'
    assert sha(lavaplayer) == Path(str(LAVAPLAYER) + '.sha256').read_text().strip(), 'differs from the repository checksum'
    assert name == f'lavaplayer-2.2.7-fix-j8-{pinned[:8]}.jar.packed', f'REPLACEMENT_NAME {name} must carry the sha256 prefix {pinned[:8]}'
    payload = 'fd_mdm_soundcloud_fix/' + name
    for p in CLASSPATH: assert p.is_file(), p
    out = HERE / 'out'
    if out.exists(): shutil.rmtree(out)
    out.mkdir()
    work = Path(tempfile.mkdtemp(prefix='fdsc-mod-build-'))
    try:
        classes = work / 'classes'; classes.mkdir()
        empty = work / 'empty'; empty.mkdir()
        args = ['--release', '21', '-encoding', 'UTF-8', '-proc:none', '-Xlint:all', '-Xlint:-processing',
                '-sourcepath', str(empty), '-cp', ';'.join(str(p) for p in CLASSPATH), '-d', str(classes), *map(str, src)]
        argfile = work / 'javac.args'
        argfile.write_text('\n'.join('"' + a.replace('\\', '/') + '"' for a in args), encoding='utf-8')
        r = subprocess.run([str(JDK / 'javac.exe'), '@' + str(argfile)], capture_output=True, text=True, encoding='utf-8', errors='replace')
        (out / 'compile.log').write_text(r.stdout + r.stderr, encoding='utf-8', newline='\n')
        assert r.returncode == 0, r.stdout + r.stderr

        entries = [('META-INF/MANIFEST.MF', MANIFEST, zipfile.ZIP_DEFLATED)]
        for p in sorted((HERE / 'resources').rglob('*')):
            if p.is_file(): entries.append((p.relative_to(HERE / 'resources').as_posix(), p.read_bytes(), zipfile.ZIP_DEFLATED))
        for p in sorted(classes.rglob('*.class')):
            entries.append((p.relative_to(classes).as_posix(), p.read_bytes(), zipfile.ZIP_DEFLATED))
        entries += [('META-INF/LICENSE', (HERE / 'LICENSE').read_bytes(), zipfile.ZIP_DEFLATED),
                    ('META-INF/NOTICE', (HERE / 'NOTICE').read_bytes(), zipfile.ZIP_DEFLATED),
                    ('META-INF/licenses/LavaPlayer-LICENSE-Apache-2.0.txt', (HERE / 'LavaPlayer-LICENSE-Apache-2.0.txt').read_bytes(), zipfile.ZIP_DEFLATED),
                    (payload, lavaplayer, zipfile.ZIP_STORED)]
        jar = out / JAR
        with zipfile.ZipFile(jar, 'w') as z:
            for name, data, method in entries:
                info = zipfile.ZipInfo(name, DT); info.compress_type = method; info.create_system = 0
                info.external_attr = 0o644 << 16
                z.writestr(info, data)
        sources = out / f'fd-mdm-soundcloud-fix-{VERSION}+mc1.21.1-sources.zip'
        with zipfile.ZipFile(sources, 'w', zipfile.ZIP_DEFLATED) as z:
            # The mod sources plus the provenance check of the bundled official LavaPlayer (script, compat tool,
            # signing key, checksum files and reports; the downloaded jars themselves are left out).
            for base, prefix in ((HERE, 'fd-mdm-soundcloud-fix/'), (HERE.parent / 'lavaplayer-2.2.7', 'lavaplayer-2.2.7/')):
                for p in sorted(base.rglob('*')):
                    rel = p.relative_to(base).as_posix()
                    # The mod's own out/ holds build outputs, including this ZIP while it is being written.
                    own_output = base == HERE and rel.startswith('out/')
                    if p.is_file() and not own_output and not rel.startswith(('out/classes', '__pycache__/')) and not rel.endswith('.jar') and '/__pycache__/' not in rel:
                        info = zipfile.ZipInfo(prefix + rel, DT); info.compress_type = zipfile.ZIP_DEFLATED
                        z.writestr(info, p.read_bytes())
        with zipfile.ZipFile(jar) as z:
            assert z.testzip() is None
            assert z.read(payload) == lavaplayer
            assert [n for n in z.namelist() if n.endswith('.jar.packed')] == [payload]
        result = {'jar': str(jar), 'jar_sha256': sha(jar.read_bytes()), 'jar_size': jar.stat().st_size,
                  'sources_zip': str(sources), 'sources_sha256': sha(sources.read_bytes()),
                  'bundled_lavaplayer': payload, 'bundled_lavaplayer_sha256': pinned, 'entries': [e[0] for e in entries],
                  'javac': subprocess.run([str(JDK / 'javac.exe'), '-version'], capture_output=True, text=True).stdout.strip() or 'javac 21'}
        (out / 'build-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
        print(json.dumps({k: result[k] for k in ('jar', 'jar_sha256', 'jar_size', 'sources_sha256')}, indent=1))
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == '__main__':
    main()

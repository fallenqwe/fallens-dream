package fd.mdmscfix;

import net.neoforged.fml.common.Mod;

/**
 * Mod entry point. The work is done by {@code DependencyManagerMixin}; here we only report early when Music Disc Maker
 * is absent or has another version, because then the mixin target may never run and the fix would stay silent.
 */
@Mod(SoundCloudFix.MOD_ID)
public final class FdMdmSoundCloudFix {

    public FdMdmSoundCloudFix() {
        try {
            final String version = SoundCloudFix.mdmVersion();
            if (version == null) {
                SoundCloudFix.warnOnce("Music Disc Maker is not installed");
            } else if (!PackedGate.MDM_VERSION.equals(version)) {
                SoundCloudFix.warnOnce("Music Disc Maker version is " + version + ", this fix is only for " + PackedGate.MDM_VERSION);
            }
        } catch (final Throwable error) {
            SoundCloudFix.warnOnce("unexpected " + error);
        }
    }
}

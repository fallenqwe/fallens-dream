package fd.mdmscfix.mixin;

import java.nio.file.Path;
import java.util.Set;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

import fd.mdmscfix.SoundCloudFix;

/**
 * Target: Music Disc Maker 3.1.2, {@code com.kuronami.musicdiscmaker.depend.DependencyManager}
 * {@code private static void install(String searchedIn, Set<Path> packed) throws IOException}.
 * It receives every bundled {@code dependencies/*.jar.packed}, unpacks them and adds them to the isolated
 * {@code DependencyClassLoader}. Replacing one element of {@code packed} at HEAD is the only change; MDM's own extraction,
 * fingerprint, marker and class loader code run unchanged.
 *
 * <p>Registered only by {@code fd.mdmscfix.MixinPlugin} when the loading mod list has MDM exactly 3.1.2. In addition
 * {@code @Pseudo} and {@code require = 0}: if the method were ever missing, nothing is injected and nothing fails.
 */
@Pseudo
@Mixin(targets = "com.kuronami.musicdiscmaker.depend.DependencyManager", remap = false)
public abstract class DependencyManagerMixin {

    @ModifyVariable(method = "install(Ljava/lang/String;Ljava/util/Set;)V", at = @At("HEAD"), argsOnly = true,
            require = 0, remap = false)
    private static Set<Path> fdMdmScFix$substituteLavaPlayer(Set<Path> packed) {
        return SoundCloudFix.onInstall(packed);
    }
}

package fd.ntglammo;

import java.util.List;
import java.util.Set;

import org.objectweb.asm.tree.ClassNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

import net.neoforged.fml.loading.FMLLoader;
import net.neoforged.fml.loading.moddiscovery.ModFileInfo;
import net.neoforged.neoforgespi.language.IModInfo;

/**
 * Registers {@code NtglNbtUtilsMixin} only when the loading mod list contains NTGL of exactly the checked version.
 * Without NTGL or with another version no NTGL bytecode is touched and Mixin does not even look up the target class.
 * Uses only inlined constants of {@link Target}; logs nothing (the single INFO/WARN comes from the mod entry point).
 */
public final class MixinPlugin implements IMixinConfigPlugin {

    @Override
    public void onLoad(final String mixinPackage) {
    }

    @Override
    public String getRefMapperConfig() {
        return null;
    }

    @Override
    public boolean shouldApplyMixin(final String targetClassName, final String mixinClassName) {
        return true;
    }

    @Override
    public void acceptTargets(final Set<String> myTargets, final Set<String> otherTargets) {
    }

    @Override
    public List<String> getMixins() {
        return Target.NTGL_VERSION.equals(ntglVersion()) ? List.of("NtglNbtUtilsMixin") : null;
    }

    @Override
    public void preApply(final String targetClassName, final ClassNode targetClass, final String mixinClassName, final IMixinInfo mixinInfo) {
    }

    @Override
    public void postApply(final String targetClassName, final ClassNode targetClass, final String mixinClassName, final IMixinInfo mixinInfo) {
    }

    /** NTGL version from the loading mod list, or null when NTGL is absent or the list is unavailable. */
    static String ntglVersion() {
        try {
            final ModFileInfo file = FMLLoader.getLoadingModList().getModFileById(Target.NTGL_ID);
            if (file == null) {
                return null;
            }
            for (final IModInfo mod : file.getMods()) {
                if (Target.NTGL_ID.equals(mod.getModId())) {
                    return mod.getVersion().toString();
                }
            }
            return null;
        } catch (final Throwable error) {
            return null;
        }
    }
}

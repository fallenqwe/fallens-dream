"""Builds fd-ntgl-ammo-order-fix-1.0.0+mc1.21.1.jar (NeoForge 1.21.1) and its sources ZIP. No network, no Gradle.

Compile classpath (read-only, not bundled): Prism library JARs of NeoForge 21.1.264 (FML loader 4.0.45, sponge-mixin,
slf4j, maven-artifact, ASM) and the Mojang-named Minecraft 1.21.1 server JAR of the isolated test server
(only net.minecraft.nbt.CompoundTag is referenced). Output timestamps are fixed, so the JAR is reproducible.

Usage: python -I build.py
"""
import hashlib, json, shutil, subprocess, tempfile, zipfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
WS = next(p for p in HERE.parents if (p / 'AGENTS.md').is_file())
JDK = Path('C:/Users/falle/AppData/Roaming/PrismLauncher/instances/Fallens-Dream-1.21.1/runtime/java21/bin')
LIB = Path('C:/Users/falle/AppData/Roaming/PrismLauncher/libraries')
MC = WS / 'work/soundcloud-fix-2026-10-29/test-env/server/libraries/net/minecraft/server/1.21.1-20240808.144430/server-1.21.1-20240808.144430-srg.jar'
CLASSPATH = [LIB / 'net/neoforged/fancymodloader/loader/4.0.45/loader-4.0.45.jar',
             LIB / 'net/fabricmc/sponge-mixin/0.16.4+mixin.0.8.7/sponge-mixin-0.16.4+mixin.0.8.7.jar',
             LIB / 'org/slf4j/slf4j-api/2.0.9/slf4j-api-2.0.9.jar',
             LIB / 'org/apache/maven/maven-artifact/3.8.5/maven-artifact-3.8.5.jar',
             LIB / 'cpw/mods/securejarhandler/3.0.8/securejarhandler-3.0.8.jar',
             LIB / 'cpw/mods/modlauncher/11.0.5/modlauncher-11.0.5.jar',
             LIB / 'net/neoforged/bus/8.0.5/bus-8.0.5.jar',
             LIB / 'net/neoforged/mergetool/2.0.0/mergetool-2.0.0-api.jar',
             LIB / 'org/ow2/asm/asm-tree/9.10.1/asm-tree-9.10.1.jar',
             LIB / 'org/ow2/asm/asm/9.10.1/asm-9.10.1.jar',
             MC]
VERSION = '1.0.0'
NAME = 'fd-ntgl-ammo-order-fix'
JAR = f'{NAME}-{VERSION}+mc1.21.1.jar'
DT = (2026, 10, 30, 0, 0, 0)
MANIFEST = (f'Manifest-Version: 1.0\r\nAutomatic-Module-Name: fd_ntgl_ammo_order_fix\r\n'
            f'Implementation-Title: FD NTGL ammo order fix\r\nImplementation-Version: {VERSION}\r\n'
            f'Implementation-Vendor: Fallen\'s Dream\r\n\r\n').encode('ascii')


def sha(b): return hashlib.sha256(b).hexdigest()


def zinfo(name):
    info = zipfile.ZipInfo(name, DT); info.compress_type = zipfile.ZIP_DEFLATED; info.create_system = 0
    info.external_attr = 0o644 << 16
    return info


def main():
    for p in CLASSPATH: assert p.is_file(), p
    src = sorted((HERE / 'src').rglob('*.java'))
    out = HERE / 'out'
    if out.exists(): shutil.rmtree(out)
    out.mkdir()
    work = Path(tempfile.mkdtemp(prefix='fd-ntgl-ammo-build-'))
    try:
        classes = work / 'classes'; classes.mkdir()
        empty = work / 'empty'; empty.mkdir()
        args = ['--release', '21', '-encoding', 'UTF-8', '-proc:none', '-Xlint:all', '-Xlint:-processing',
                '-sourcepath', str(empty), '-cp', ';'.join(str(p) for p in CLASSPATH), '-d', str(classes), *map(str, src)]
        argfile = work / 'javac.args'
        argfile.write_text('\n'.join('"' + a.replace('\\', '/') + '"' for a in args), encoding='utf-8')
        r = subprocess.run([str(JDK / 'javac.exe'), '@' + str(argfile)], capture_output=True, text=True, encoding='utf-8', errors='replace')
        (out / 'compile.log').write_text(r.stdout + r.stderr, encoding='utf-8', newline='\n')
        assert r.returncode == 0, r.stdout + r.stderr

        entries = [('META-INF/MANIFEST.MF', MANIFEST)]
        for p in sorted((HERE / 'resources').rglob('*')):
            if p.is_file(): entries.append((p.relative_to(HERE / 'resources').as_posix(), p.read_bytes()))
        for p in sorted(classes.rglob('*.class')):
            entries.append((p.relative_to(classes).as_posix(), p.read_bytes()))
        entries.append(('META-INF/LICENSE', (HERE / 'LICENSE').read_bytes()))
        jar = out / JAR
        with zipfile.ZipFile(jar, 'w') as z:
            for name, data in entries: z.writestr(zinfo(name), data)
        sources = out / f'{NAME}-{VERSION}+mc1.21.1-sources.zip'
        # Only the mod itself (src, resources, build.py, LICENSE); the TEST-ONLY probes in ../tests are not shipped.
        source_files = [HERE / 'build.py', HERE / 'LICENSE'] + [p for d in ('src', 'resources') for p in (HERE / d).rglob('*') if p.is_file()]
        with zipfile.ZipFile(sources, 'w') as z:
            for p in sorted(source_files, key=lambda p: p.relative_to(HERE).as_posix()):
                z.writestr(zinfo(f'{NAME}/' + p.relative_to(HERE).as_posix()), p.read_bytes())
        with zipfile.ZipFile(jar) as z:
            assert z.testzip() is None
            names = z.namelist()
            assert 'fd/ntglammo/mixin/NtglNbtUtilsMixin.class' in names and 'META-INF/neoforge.mods.toml' in names
        result = {'jar': str(jar), 'jar_sha256': sha(jar.read_bytes()), 'jar_size': jar.stat().st_size,
                  'sources_zip': str(sources), 'sources_sha256': sha(sources.read_bytes()), 'entries': [e[0] for e in entries],
                  'compile_classpath': [str(p) for p in CLASSPATH],
                  'javac': (subprocess.run([str(JDK / 'javac.exe'), '-version'], capture_output=True, text=True).stdout.strip() or 'javac 21')}
        (out / 'build-result.json').write_text(json.dumps(result, indent=2) + '\n', encoding='utf-8', newline='\n')
        print(json.dumps({k: result[k] for k in ('jar', 'jar_sha256', 'jar_size', 'sources_sha256')}, indent=1))
    finally:
        shutil.rmtree(work, ignore_errors=True)


if __name__ == '__main__':
    main()

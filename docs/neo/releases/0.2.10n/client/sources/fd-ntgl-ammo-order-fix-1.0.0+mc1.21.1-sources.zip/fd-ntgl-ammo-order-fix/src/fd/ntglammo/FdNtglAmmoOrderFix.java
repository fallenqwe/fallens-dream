package fd.ntglammo;

import java.lang.reflect.Method;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import net.neoforged.fml.common.Mod;

/**
 * Mod entry point. The work is done by {@code NtglNbtUtilsMixin}. Here we only report once per JVM whether it is
 * active: one INFO when the redirect is merged into NTGL 3.2.0, otherwise one WARN (NTGL absent, another version, or
 * the target call not found) and nothing is changed.
 */
@Mod(Target.MOD_ID)
public final class FdNtglAmmoOrderFix {
    private static final Logger LOG = LoggerFactory.getLogger(Target.LOGGER);

    public FdNtglAmmoOrderFix() {
        try {
            final String version = MixinPlugin.ntglVersion();
            if (version == null) {
                LOG.warn("NTGL is not installed; nothing to fix, NTGL code untouched");
            } else if (!Target.NTGL_VERSION.equals(version)) {
                LOG.warn("NTGL version is {}, this fix was checked only against {}; NTGL code untouched", version, Target.NTGL_VERSION);
            } else if (!handlerMerged()) {
                LOG.warn("NTGL {}: target call CompoundTag.getAllKeys() in NbtUtils.deserializeSet not found; NTGL code untouched", version);
            } else {
                LOG.info("NTGL {}: NbtUtils.deserializeSet reads keys in index order (weapon ammo / fire-mode lists keep the server order)", version);
            }
        } catch (final Throwable error) {
            LOG.warn("check failed: {}", error.toString());
        }
    }

    private static boolean handlerMerged() throws ClassNotFoundException {
        final Class<?> utils = Class.forName(Target.NBT_UTILS, false, FdNtglAmmoOrderFix.class.getClassLoader());
        for (final Method method : utils.getDeclaredMethods()) {
            if (method.getName().contains(Target.HANDLER_MARK)) {
                return true;
            }
        }
        return false;
    }
}

package fd.ntglammo.mixin;

import java.util.Set;

import net.minecraft.nbt.CompoundTag;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

import fd.ntglammo.IndexOrder;

/**
 * Target: NTGL 3.2.0, {@code com.nukateam.ntgl.common.util.util.NbtUtils}
 * {@code public static <R> LinkedHashSet<R> deserializeSet(CompoundTag tag, Function<String, R> f)}:
 * <pre>
 *   result = new LinkedHashSet();
 *   for (String key : tag.getAllKeys())            // the only call that is redirected
 *       if (tag.contains(key, 8)) result.add(f.apply(tag.getString(key)));
 * </pre>
 * The redirect only changes the iteration order of {@code getAllKeys()} (see {@link IndexOrder}); NTGL's loop,
 * type check and conversion stay as they are.
 *
 * <p>Registered only by {@code fd.ntglammo.MixinPlugin} when the loading mod list has NTGL exactly 3.2.0.
 * {@code require = 0}: if the call were ever missing, nothing is injected and the mod logs one WARN.
 */
@Mixin(targets = "com.nukateam.ntgl.common.util.util.NbtUtils", remap = false)
public abstract class NtglNbtUtilsMixin {

    @Redirect(method = "deserializeSet(Lnet/minecraft/nbt/CompoundTag;Ljava/util/function/Function;)Ljava/util/LinkedHashSet;",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/nbt/CompoundTag;getAllKeys()Ljava/util/Set;", remap = false),
            require = 0, allow = 1, remap = false)
    private static Set<String> fdNtglAmmo$keysInIndexOrder(final CompoundTag tag) {
        return IndexOrder.keys(tag.getAllKeys());
    }
}

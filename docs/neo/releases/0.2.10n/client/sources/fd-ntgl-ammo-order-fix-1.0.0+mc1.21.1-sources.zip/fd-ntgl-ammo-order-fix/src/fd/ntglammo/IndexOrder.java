package fd.ntglammo;

import java.util.Arrays;
import java.util.Collections;
import java.util.LinkedHashSet;
import java.util.Set;

/**
 * NTGL writes an ordered set into NBT as keys "0", "1", ... "n-1" ({@code NbtUtils.serializeSet}) and reads it back by
 * iterating {@code CompoundTag.getAllKeys()} ({@code NbtUtils.deserializeSet}). That relies on the iteration order of
 * the map inside {@code CompoundTag}. Vanilla's {@code HashMap} happens to keep "0".."9" in order; Lithium
 * ({@code mixin.alloc.nbt}) swaps it for fastutil's {@code Object2ObjectOpenHashMap}, which returns "1" before "0".
 * On a client the weapon configs arrive as NBT, so their ammo / fire-mode lists come out reversed there, while the
 * dedicated server keeps the JSON order. This puts the keys back into index order.
 *
 * <p>Only the exact key set {"0".."n-1"} (what {@code serializeSet} produces) is reordered. Anything else, and any
 * error, returns the original key set unchanged.
 */
public final class IndexOrder {

    private IndexOrder() {
    }

    public static Set<String> keys(final Set<String> keys) {
        try {
            if (keys == null) {
                return keys;
            }
            final int size = keys.size();
            if (size < 2) {
                return keys;
            }
            final String[] byIndex = new String[size];
            for (final String key : keys) {
                final int index = index(key);
                if (index < 0 || index >= size || byIndex[index] != null) {
                    return keys;
                }
                byIndex[index] = key;
            }
            return Collections.unmodifiableSet(new LinkedHashSet<>(Arrays.asList(byIndex)));
        } catch (final RuntimeException error) {
            return keys;
        }
    }

    /** Canonical non-negative decimal ("0", "7", "12"; not "", "-1", "01", "+1", "1a"), else -1. */
    static int index(final String key) {
        if (key == null || key.isEmpty() || key.length() > 9) {
            return -1;
        }
        if (key.length() > 1 && key.charAt(0) == '0') {
            return -1;
        }
        int value = 0;
        for (int i = 0; i < key.length(); i++) {
            final char c = key.charAt(i);
            if (c < '0' || c > '9') {
                return -1;
            }
            value = value * 10 + (c - '0');
        }
        return value;
    }
}

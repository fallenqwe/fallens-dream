package fd.ntglammo;

/**
 * Compile-time constants only (javac inlines them), so {@code MixinPlugin} can use them without loading this class.
 */
public final class Target {
    public static final String MOD_ID = "fd_ntgl_ammo_order_fix";
    public static final String LOGGER = "FD NTGL ammo order fix";

    /** NukaTeam's Gun Lib, the only version whose bytecode was checked. */
    public static final String NTGL_ID = "ntgl";
    public static final String NTGL_VERSION = "3.2.0";

    /** {@code public static <R> LinkedHashSet<R> deserializeSet(CompoundTag, Function<String, R>)} */
    public static final String NBT_UTILS = "com.nukateam.ntgl.common.util.util.NbtUtils";
    public static final String HANDLER_MARK = "fdNtglAmmo$";

    private Target() {
    }
}

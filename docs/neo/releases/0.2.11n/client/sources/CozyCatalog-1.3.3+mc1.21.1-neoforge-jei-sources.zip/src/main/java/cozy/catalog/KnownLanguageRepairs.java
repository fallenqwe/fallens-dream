package cozy.catalog;

import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.HexFormat;
import java.util.List;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;

/** Narrow compatibility repair; never bundles or mutates the upstream language asset. */
public final class KnownLanguageRepairs {
    private static final String NAMESPACE = "carved_wood";
    private static final String PATH = "lang/uk_ua.json";
    private static final String KNOWN_SHA256 = "d984929216427e0b8f59fe83d9a0445c781b46ac41f36dad15731df772c87064";
    private static final int MAX_BYTES = 256 * 1024;

    private KnownLanguageRepairs() {}

    public static List<Resource> getStack(ResourceManager resources, ResourceLocation id) {
        return apply(id, resources.getResourceStack(id));
    }

    /** Preserve stack order, resource source/metadata, and all non-targeted language paths. */
    public static List<Resource> apply(ResourceLocation id, List<Resource> original) {
        if (!NAMESPACE.equals(id.getNamespace()) || !PATH.equals(id.getPath())) return original;
        List<Resource> result = new ArrayList<>(original.size());
        for (Resource resource : original) {
            result.add(new Resource(resource.source(), () -> open(resource), resource::metadata));
        }
        return result;
    }

    private static InputStream open(Resource resource) throws IOException {
        BufferedInputStream stream = new BufferedInputStream(resource.open());
        try {
            stream.mark(MAX_BYTES + 1);
            byte[] bytes = stream.readNBytes(MAX_BYTES + 1);
            if (bytes.length > MAX_BYTES) {
                stream.reset();
                return stream;
            }
            stream.close();
            return new ByteArrayInputStream(repairKnownBytes(bytes));
        } catch (IOException | RuntimeException error) {
            try { stream.close(); } catch (IOException closeError) { error.addSuppressed(closeError); }
            throw error;
        }
    }

    /** Exact input hash makes this an inert no-op for fixed upstream or player overrides. */
    static byte[] repairKnownBytes(byte[] original) throws IOException {
        final String digest;
        try { digest = HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(original)); }
        catch (NoSuchAlgorithmException error) { throw new AssertionError(error); }
        if (!KNOWN_SHA256.equals(digest)) return original;
        int end = original.length - 1;
        while (end >= 0 && whitespace(original[end])) end--;
        int comma = end - 1;
        while (comma >= 0 && whitespace(original[comma])) comma--;
        if (end < 0 || original[end] != '}' || comma < 0 || original[comma] != ',') {
            throw new IOException("Known Carved Wood language asset no longer has the expected final comma");
        }
        byte[] repaired = new byte[original.length - 1];
        System.arraycopy(original, 0, repaired, 0, comma);
        System.arraycopy(original, comma + 1, repaired, comma, original.length - comma - 1);
        return repaired;
    }

    private static boolean whitespace(byte value) {
        return value == ' ' || value == '\n' || value == '\r' || value == '\t';
    }
}

package cozy.catalog;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.MessageDigest;
import java.util.*;
import java.util.zip.*;

/** Runs the production helper, real unchanged patcher and approved official sources without Minecraft. */
public final class ShaderBootstrapChecks {
    private static Path fixtures, base;
    private static int downloads, checks;
    private static final List<String> passed = new ArrayList<>();
    private static void check(boolean condition, String label) {
        if (!condition) throw new AssertionError(label); checks++;
    }
    private static void passed(String label) { passed.add(label); System.out.println("PASS " + label); }
    private static Path path(ShaderBootstrap.Input input) { return base.resolve(input.path()); }
    private static void offline(ShaderBootstrap.Input input, Path dest) throws IOException {
        downloads++;
        Files.copy(fixtures.resolve(Path.of(input.path()).getFileName()), dest);
    }
    private static String hash(Path path) throws Exception {
        return HexFormat.of().formatHex(MessageDigest.getInstance("SHA-256").digest(Files.readAllBytes(path)));
    }
    private static Map<String,String> snapshot(Path dir) throws Exception {
        Map<String,String> result = new TreeMap<>();
        try (var files = Files.walk(dir)) {
            for (Path p : files.filter(Files::isRegularFile).toList()) result.put(dir.relativize(p).toString(),hash(p));
        }
        return result;
    }
    private static void cleaned() throws IOException {
        try (var files = Files.list(base.resolve("config/fallens-shaders"))) {
            check(files.noneMatch(p -> p.getFileName().toString().startsWith(".bootstrap-")), "temporary state leaked");
        }
    }
    private static void visible() throws IOException {
        try (var files = Files.list(base.resolve("shaderpacks"))) {
            check(files.filter(p -> p.toString().endsWith(".zip")).count()==5, "visible shader count differs from five");
        }
    }
    private static long backups() throws IOException {
        Path backup = base.resolve("config/fallens-shaders/backups");
        if (!Files.exists(backup)) return 0;
        try (var files = Files.list(backup)) { return files.count(); }
    }
    private static void saved(byte[] bytes) throws IOException {
        try (var files = Files.list(base.resolve("config/fallens-shaders/backups"))) {
            boolean match = false;
            for (Path file : files.toList()) {
                check(file.toString().endsWith(".preserved"), "backup extension exposed to Iris");
                if (Arrays.equals(Files.readAllBytes(file), bytes)) match = true;
            }
            check(match, "corrupt original bytes not preserved");
        }
    }
    private static void expectFailure(ShaderBootstrap.Downloader downloader) throws Exception {
        boolean rejected=false;
        try { ShaderBootstrap.ensure(base, downloader); } catch (IOException expected) { rejected=true; }
        check(rejected, "failure path accepted"); cleaned();
    }
    public static void main(String[] args) throws Exception {
        fixtures=Path.of(args[0]); base=Path.of(args[1]); Files.createDirectories(base.resolve("config"));
        Path iris=base.resolve("config/iris.properties"), preference=base.resolve("shaderpacks/ComplementaryUnbound_r5.9.3.zip.txt");
        Files.createDirectories(preference.getParent());
        Files.writeString(iris,"shaderPack=ComplementaryUnbound_r5.9.3.zip\nenableShaders=true\n",StandardCharsets.UTF_8);
        Files.writeString(preference,"profile=MEDIUM\nSHADOW_QUALITY=0.75\n",StandardCharsets.UTF_8);
        byte[] irisBefore=Files.readAllBytes(iris), preferenceBefore=Files.readAllBytes(preference);
        downloads=0; ShaderBootstrap.ensure(base, ShaderBootstrapChecks::offline);
        check(downloads==6, "first generation did not verify/obtain all six inputs"); visible(); cleaned();
        for (var input:ShaderBootstrap.INPUTS) check(hash(path(input)).equals(input.sha256()),"source pin mismatch");
        passed("six official inputs and two actual vendor-derived outputs");

        Map<String,String> before=snapshot(base); downloads=0;
        ShaderBootstrap.ensure(base,(i,p)->{throw new AssertionError("network on valid repeat");});
        check(before.equals(snapshot(base)),"valid repeat changed bytes"); cleaned();
        passed("repeat preserves every existing byte, no download");

        Path bsl=base.resolve("shaderpacks/BSL_v10.1 + Clrwl_1.0.5.zip");
        Path bliss=base.resolve("shaderpacks/Bliss_v2.1.2_(Chocapic13_Shaders_edit) + Clrwl_1.0.5.zip");
        String oldBsl=hash(bsl),oldBliss=hash(bliss);
        Files.delete(path(ShaderBootstrap.INPUTS.get(3))); downloads=0;
        ShaderBootstrap.ensure(base,ShaderBootstrapChecks::offline);
        check(downloads==1 && oldBsl.equals(hash(bsl)) && oldBliss.equals(hash(bliss)),"missing original repair changed valid outputs");
        cleaned(); passed("missing source repaired independently; generated bytes preserved");

        byte[] brokenSource="CORRUPT_SOURCE_BYTES".getBytes(StandardCharsets.UTF_8);
        Files.write(path(ShaderBootstrap.INPUTS.get(4)),brokenSource); long count=backups(); downloads=0;
        ShaderBootstrap.ensure(base,ShaderBootstrapChecks::offline);
        check(downloads==1 && backups()==count+1,"corrupt source not repaired/backed up"); saved(brokenSource);
        check(oldBsl.equals(hash(bsl)) && oldBliss.equals(hash(bliss)),"source repair regenerated valid output");
        cleaned(); passed("corrupt source preserved outside shaderpacks and repaired");

        byte[] brokenOutput="CORRUPT_OUTPUT_BYTES".getBytes(StandardCharsets.UTF_8); Files.write(bsl,brokenOutput); downloads=0;
        ShaderBootstrap.ensure(base,(i,p)->{throw new AssertionError("generation downloaded valid input");});
        check(oldBliss.equals(hash(bliss)),"valid peer regenerated"); saved(brokenOutput); visible(); cleaned();
        passed("corrupt output regenerated through actual vendor; valid peer bytes preserved");

        // Accept a byte-different ZIP with exactly the approved payload entries.
        Path repack=base.resolve("repacked.zip");
        try (ZipFile source=new ZipFile(bsl.toFile()); ZipOutputStream target=new ZipOutputStream(Files.newOutputStream(repack))) {
            target.setComment("pre-existing locally generated output");
            for(var e=source.entries();e.hasMoreElements();) {
                ZipEntry entry=e.nextElement(); target.putNextEntry(new ZipEntry(entry.getName()));
                try(InputStream in=source.getInputStream(entry)){in.transferTo(target);} target.closeEntry();
            }
        }
        Files.move(repack,bsl,StandardCopyOption.REPLACE_EXISTING); String repacked=hash(bsl);
        ShaderBootstrap.ensure(base,(i,p)->{throw new AssertionError("repacked valid output downloaded input");});
        check(repacked.equals(hash(bsl)),"valid alternate outer ZIP hash replaced");
        passed("approved payload ZIP accepted despite different outer hash");

        Path photon=path(ShaderBootstrap.INPUTS.get(2)); Files.delete(photon); count=backups();
        expectFailure((i,p)->Files.write(p,new byte[(int)i.size()]));
        check(!Files.exists(photon) && count==backups(),"wrong hash committed or backed up good state");
        check(repacked.equals(hash(bsl)) && oldBliss.equals(hash(bliss)),"bad download changed outputs");
        passed("same-size wrong-hash download rejected and cleaned");

        expectFailure((i,p)->{Files.writeString(p,"PARTIAL");throw new IOException("injected transfer failure");});
        check(!Files.exists(photon),"partial transfer committed"); passed("transfer exception cleans private partial files");
        ShaderBootstrap.ensure(base,ShaderBootstrapChecks::offline);

        // CRC failure with a structurally valid ZIP must also trigger regeneration.
        try(ZipOutputStream zip=new ZipOutputStream(Files.newOutputStream(bsl))) {
            byte[] content="ABCDEF".getBytes(StandardCharsets.UTF_8); CRC32 crc=new CRC32();crc.update(content);
            ZipEntry entry=new ZipEntry("shaders/broken.txt");entry.setMethod(ZipEntry.STORED);entry.setSize(content.length);entry.setCrc(crc.getValue());
            zip.putNextEntry(entry);zip.write(content);zip.closeEntry();
        }
        byte[] bytes=Files.readAllBytes(bsl); int data=30+(bytes[26]&255)+((bytes[27]&255)<<8)+(bytes[28]&255)+((bytes[29]&255)<<8);
        bytes[data+2]^=0x25; Files.write(bsl,bytes);
        ShaderBootstrap.ensure(base,(i,p)->{throw new AssertionError("CRC repair downloaded input");});
        saved(bytes); cleaned(); visible(); passed("damaged ZIP payload rejected and regenerated");

        // Traversal-shaped output is never extracted or accepted.
        try(ZipOutputStream zip=new ZipOutputStream(Files.newOutputStream(bsl))){zip.putNextEntry(new ZipEntry("../escape"));zip.write(1);zip.closeEntry();}
        ShaderBootstrap.ensure(base,(i,p)->{throw new AssertionError("traversal repair downloaded input");});
        check(!Files.exists(base.resolve("escape")),"traversal escaped"); cleaned(); passed("traversal output rejected without extraction");

        check(Arrays.equals(irisBefore,Files.readAllBytes(iris)) && Arrays.equals(preferenceBefore,Files.readAllBytes(preference)),"preferences altered");
        passed("Iris selection and Unbound MEDIUM preferences untouched");
        Files.writeString(Path.of(args[2]),"{\"status\":\"PASS\",\"assertions\":"+checks+",\"scenarios\":"+passed.size()+",\"minecraft_or_gui_started\":false}\n");
    }
}

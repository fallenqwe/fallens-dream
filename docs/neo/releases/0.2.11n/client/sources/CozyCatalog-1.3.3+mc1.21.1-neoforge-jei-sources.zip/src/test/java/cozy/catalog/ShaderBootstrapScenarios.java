package cozy.catalog;

import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;

/**
 * Isolated 1.3.3 scenarios for the Iris boundary, without Minecraft, Iris or network. A Python driver prepares the
 * directories (junctions, unavailable temp, aged leftovers) and checks file hashes and the log around one call.
 *
 * Usage: ShaderBootstrapScenarios SCENARIO FIXTURES GAME_DIR REPORT_JSON
 *   prepare      offline generation of a complete delivered profile (fixture inputs, real vendor patcher)
 *   hook         one production hook call with the pinned HTTPS downloader (network made unavailable by the driver)
 *   repeat       three hook calls: full verification, cached repeat, full verification after forgetting the cache
 *   repair       one hook call with the offline fixture downloader (repairs missing/corrupt inputs)
 *   backoff      three production hook calls: network attempt, paused retry, attempt after forgetting the pause
 *   iris-hook    Iris hook detector on class files in GAME_DIR, then the one-time WARN when the hook is missing
 *   age          test setup only: GAME_DIR is a file of "hoursAgo&lt;TAB&gt;path" lines; sets the creation, access and
 *                modification times of each path itself (NOFOLLOW_LINKS, so a junction's own times)
 */
public final class ShaderBootstrapScenarios {
    private ShaderBootstrapScenarios() {}

    private static void offline(Path fixtures, ShaderBootstrap.Input input, Path dest) throws java.io.IOException {
        Files.copy(fixtures.resolve(Path.of(input.path()).getFileName()), dest);
    }

    public static void main(String[] args) throws Exception {
        String scenario = args[0];
        Path fixtures = Path.of(args[1]), game = Path.of(args[2]), report = Path.of(args[3]);
        Map<String, Object> result = new LinkedHashMap<>();
        result.put("scenario", scenario);
        Throwable escaped = null;
        try {
            switch (scenario) {
                case "prepare" -> {
                    Files.createDirectories(game);
                    ShaderBootstrap.ensure(game, (input, dest) -> offline(fixtures, input, dest));
                    result.put("prepared", true);
                }
                case "hook" -> {
                    int before = ShaderBootstrap.fullVerifications();
                    long started = System.nanoTime();
                    boolean ok = ShaderBootstrapHook.run(() -> game);
                    result.put("hook_returned", ok);
                    result.put("millis", (System.nanoTime() - started) / 1e6);
                    result.put("full_verifications", ShaderBootstrap.fullVerifications() - before);
                }
                case "repair" -> {
                    boolean ok = ShaderBootstrapHook.run(() -> game, (input, dest) -> offline(fixtures, input, dest));
                    result.put("hook_returned", ok);
                }
                case "repeat" -> {
                    List<Object> calls = new ArrayList<>();
                    for (int i = 0; i < 3; i++) {
                        if (i == 2) ShaderBootstrap.forgetVerified();
                        int before = ShaderBootstrap.fullVerifications();
                        long started = System.nanoTime();
                        boolean ok = ShaderBootstrapHook.run(() -> game, (input, dest) -> { throw new AssertionError("download on a valid profile"); });
                        Map<String, Object> call = new LinkedHashMap<>();
                        call.put("hook_returned", ok);
                        call.put("millis", (System.nanoTime() - started) / 1e6);
                        call.put("full_verifications", ShaderBootstrap.fullVerifications() - before);
                        calls.add(call);
                    }
                    result.put("calls", calls);
                }
                case "backoff" -> {
                    // Production downloader three times: network attempt, paused retry, attempt after the pause ends.
                    List<Object> calls = new ArrayList<>();
                    for (int i = 0; i < 3; i++) {
                        if (i == 2) ShaderBootstrap.forgetNetworkFailure();
                        long started = System.nanoTime();
                        boolean ok = ShaderBootstrapHook.run(() -> game);
                        Map<String, Object> call = new LinkedHashMap<>();
                        call.put("hook_returned", ok);
                        call.put("millis", (System.nanoTime() - started) / 1e6);
                        calls.add(call);
                        System.out.println("BACKOFF_CALL_DONE " + i);
                    }
                    result.put("calls", calls);
                }
                case "iris-hook" -> {
                    // GAME_DIR holds iris-original.class (unchanged Iris) and optionally iris-transformed.class (exported by Mixin).
                    for (String name : List.of("iris-original.class", "iris-transformed.class")) {
                        Path file = game.resolve(name);
                        if (!Files.isRegularFile(file)) continue;
                        var node = new org.objectweb.asm.tree.ClassNode();
                        new org.objectweb.asm.ClassReader(Files.readAllBytes(file)).accept(node, 0);
                        result.put("detector_" + name, CozyMixinPlugin.hasBootstrapCall(node));
                    }
                    result.put("state_initial", ShaderBootstrapHook.irisHookState());
                    ShaderBootstrapHook.recordIrisHook(true);
                    result.put("warn_when_applied", ShaderBootstrapHook.warnIfHookMissing("test"));
                    ShaderBootstrapHook.recordIrisHook(false);
                    result.put("warn_when_missing", ShaderBootstrapHook.warnIfHookMissing("test"));
                    result.put("warn_second_time", ShaderBootstrapHook.warnIfHookMissing("test"));
                }
                case "age" -> {
                    long now = System.currentTimeMillis(); int count = 0;
                    for (String line : Files.readAllLines(game, StandardCharsets.UTF_8)) {
                        if (line.isBlank()) continue;
                        String[] parts = line.split("\t", 2);
                        var time = java.nio.file.attribute.FileTime.fromMillis(now - (long) (Double.parseDouble(parts[0]) * 3_600_000L));
                        Files.getFileAttributeView(Path.of(parts[1]), java.nio.file.attribute.BasicFileAttributeView.class, LinkOption.NOFOLLOW_LINKS)
                            .setTimes(time, time, time);
                        count++;
                    }
                    result.put("aged", count);
                }
                default -> throw new IllegalArgumentException("unknown scenario " + scenario);
            }
        } catch (Throwable t) {
            escaped = t;
        }
        result.put("exception_escaped", escaped == null ? null : ShaderBootstrapHook.describe(escaped));
        result.put("java_io_tmpdir", System.getProperty("java.io.tmpdir"));
        Files.writeString(report, json(result) + "\n", StandardCharsets.UTF_8);
        System.out.println("SCENARIO_DONE " + scenario);
        if (escaped != null) escaped.printStackTrace();
    }

    private static String json(Object value) {
        if (value == null) return "null";
        if (value instanceof Boolean || value instanceof Number) return value.toString();
        if (value instanceof Map<?, ?> map) {
            StringJoiner out = new StringJoiner(",", "{", "}");
            map.forEach((k, v) -> out.add(json(String.valueOf(k)) + ":" + json(v)));
            return out.toString();
        }
        if (value instanceof List<?> list) {
            StringJoiner out = new StringJoiner(",", "[", "]");
            list.forEach(v -> out.add(json(v)));
            return out.toString();
        }
        StringBuilder text = new StringBuilder("\"");
        for (char c : value.toString().toCharArray()) {
            if (c == '"' || c == '\\') text.append('\\').append(c);
            else if (c < 0x20) text.append(String.format("\\u%04x", (int) c));
            else text.append(c);
        }
        return text.append('"').toString();
    }
}

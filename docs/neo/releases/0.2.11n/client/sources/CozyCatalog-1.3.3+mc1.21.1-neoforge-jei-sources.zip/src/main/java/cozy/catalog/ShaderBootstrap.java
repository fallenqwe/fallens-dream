package cozy.catalog;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.nio.file.attribute.FileTime;
import java.security.*;
import java.util.*;
import java.util.zip.*;
import javax.net.ssl.HttpsURLConnection;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/** Pure file delivery, independent of Minecraft. No preferences or modified packs are embedded. */
public final class ShaderBootstrap {
    private ShaderBootstrap() {}
    public record Input(String path, long size, String sha256, String url) {}
    @FunctionalInterface public interface Downloader { void download(Input input, Path destination) throws IOException; }
    public static final List<Input> INPUTS = List.of(
        new Input("shaderpacks/ComplementaryReimagined_r5.9.3.zip", 553397L, "fed6c879e732cf7fc7bc6570ebb1def43235aa7e96f62859fbdbdbfa0b484b38", "https://cdn.modrinth.com/data/HVnmMxH1/versions/Bqen1mJX/ComplementaryReimagined_r5.9.3.zip"),
        new Input("shaderpacks/ComplementaryUnbound_r5.9.3.zip", 553400L, "98ac741dee294d2a3c82d153349148c3bb7fb688c30eb3b49c3b9ac37e968c5a", "https://cdn.modrinth.com/data/R6NEzAwj/versions/B1kyfoUZ/ComplementaryUnbound_r5.9.3.zip"),
        new Input("shaderpacks/photon_v1.4.zip", 3857333L, "da0929b38f5fd99befaaa8cd141cbf60e1fad05b92d916d0eeeee7c79f86c0fd", "https://cdn.modrinth.com/data/lLqFfGNs/versions/BnGklH5y/photon_v1.4.zip"),
        new Input("config/fallens-shaders/input/BSL_v10.1.zip", 1124960L, "cc61c6a25d087f1b3ef55a1bceb1cca93f97da06b28883e929c3306b25ff0dc5", "https://cdn.modrinth.com/data/Q1vvjJYV/versions/3WGx0wKu/BSL_v10.1.zip"),
        new Input("config/fallens-shaders/input/Bliss_v2.1.2_(Chocapic13_Shaders_edit).zip", 1791406L, "f41db92acc585fe9ffe0cc124d6ecaea27cef9ded91129ebc2a8e60226947b2c", "https://cdn.modrinth.com/data/ZvMtQlho/versions/kC2Y8q1P/Bliss_v2.1.2_%28Chocapic13_Shaders_edit%29.zip"),
        new Input("config/fallens-shaders/input/colorwheel_patcher-neoforge-1.0.5+mc1.21.1.jar", 210569L, "2285a5154739d2e9889d979e3bdf54104b56d7966dac8d43367305e5aaedcce8", "https://cdn.modrinth.com/data/KPsw5jDu/versions/dQqV3sci/colorwheel_patcher-neoforge-1.0.5%2Bmc1.21.1.jar")
    );
    private record Output(String name, String manifest) {}
    private static final List<Output> OUTPUTS = List.of(
        new Output("BSL_v10.1 + Clrwl_1.0.5.zip", "/cozy/shaders/bsl.entries"),
        new Output("Bliss_v2.1.2_(Chocapic13_Shaders_edit) + Clrwl_1.0.5.zip", "/cozy/shaders/bliss.entries"));
    private static final long MAX_ENTRY = 32L * 1024 * 1024, MAX_EXPANDED = 128L * 1024 * 1024;
    private static final int MAX_ENTRIES = 4096;
    private static final Logger LOG = LoggerFactory.getLogger("CozyCatalog/ShaderBootstrap");
    /** Newest preserved backups kept in config/fallens-shaders/backups; older *.preserved files are removed. */
    static final int KEEP_BACKUPS = 10;
    /** A .bootstrap-* work directory untouched for this long belongs to an interrupted earlier run. */
    static final long ORPHAN_AGE_MILLIS = 24L * 60 * 60 * 1000;
    /** Files written this recently are not trusted by size/mtime alone (coarse mtime resolution). */
    static final long RACY_MILLIS = 3000L;
    private static final int MAX_DELETE_DEPTH = 32;
    /** After a failed pinned HTTPS download, no further network attempt in this process for this long. */
    static final long NETWORK_RETRY_MILLIS = 10L * 60 * 1000;
    // Guarded by the class lock (download runs inside the synchronized ensure).
    private static long networkFailedAtNanos;
    private static String networkFailure;

    /** Size, modification time and file key of one controlled file after a full verification. */
    private record Stamp(String path, long size, FileTime modified, Object key) {}
    // Guarded by the class lock (ensure is synchronized). Process-local; nothing is persisted.
    private static Path verifiedRoot;
    private static List<Stamp> verifiedStamps;
    private static int fullVerifications;

    public static void ensure(Path gameDirectory) throws IOException { ensure(gameDirectory, ShaderBootstrap::download); }

    /** Offline fixture seam exercises the actual production file logic with pinned inputs. */
    public static synchronized void ensure(Path gameDirectory, Downloader downloader) throws IOException {
        Path root = gameDirectory.toAbsolutePath().normalize();
        safe(root);
        if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Missing game directory");
        // Same files, sizes and mtimes as after the last full verification in this process: skip rehashing.
        if (root.equals(verifiedRoot) && verifiedStamps != null && verifiedStamps.equals(stamps(root))) return;
        verifiedRoot = null; verifiedStamps = null; fullVerifications++;
        deliver(root, downloader);
        try {
            List<Stamp> verified = stamps(root);
            if (verified != null && !racy(verified)) { verifiedRoot = root; verifiedStamps = verified; }
        } catch (IOException notCached) { /* the next call verifies fully again */ }
    }

    /** Test seam: forget the process-local verification cache. */
    static synchronized void forgetVerified() { verifiedRoot = null; verifiedStamps = null; }
    /** Test seam: number of full (hashing) verifications in this process. */
    static synchronized int fullVerifications() { return fullVerifications; }
    /** Test seam: end the network retry pause as if NETWORK_RETRY_MILLIS had passed. */
    static synchronized void forgetNetworkFailure() { networkFailure = null; }

    private static void deliver(Path root, Downloader downloader) throws IOException {
        Path state = path(root, "config/fallens-shaders");
        directories(state); directories(path(root, "shaderpacks")); directories(path(root, "config/fallens-shaders/input"));
        for (Input input : INPUTS) regularOrAbsent(path(root, input.path));
        for (Output output : OUTPUTS) regularOrAbsent(path(root, "shaderpacks/" + output.name));
        housekeeping(root, state);
        Path work = Files.createTempDirectory(state, ".bootstrap-");
        try {
            for (Input input : INPUTS) {
                Path dest = path(root, input.path);
                if (validInput(dest, input)) continue;
                Path fresh = work.resolve("input-" + INPUTS.indexOf(input));
                downloader.download(input, fresh);
                if (!validInput(fresh, input)) throw new IOException("Pinned shader input rejected: " + input.path);
                commit(fresh, dest, state);
            }
            boolean needsBuild = false;
            for (Output output : OUTPUTS) if (!validOutput(path(root, "shaderpacks/" + output.name), output)) needsBuild = true;
            if (!needsBuild) return; // Preserve exact bytes of already valid installed ZIPs.
            Path privatePacks = work.resolve("packs"); Files.createDirectory(privatePacks);
            for (Input input : INPUTS) if (input.path.endsWith("BSL_v10.1.zip") || input.path.contains("/Bliss_v2.1.2_"))
                Files.copy(path(root, input.path), privatePacks.resolve(Path.of(input.path).getFileName()));
            invokeVendor(path(root, INPUTS.get(5).path), privatePacks, work.resolve("empty-user-patches.zip"));
            // The vendor logs and swallows its own failures (for example an unusable java.io.tmpdir).
            for (Output output : OUTPUTS) if (!Files.isRegularFile(privatePacks.resolve(output.name), LinkOption.NOFOLLOW_LINKS))
                throw new IOException("Pinned Colorwheel Patcher produced no " + output.name + "; see its colorwheel_patcher log lines above"
                        + " (it unpacks into java.io.tmpdir=" + System.getProperty("java.io.tmpdir") + ")");
            correctBsl(privatePacks.resolve(OUTPUTS.get(0).name), work.resolve("corrected-bsl.zip"));
            // Verify both generated payloads before exposing either to Iris.
            for (Output output : OUTPUTS) if (!validOutput(privatePacks.resolve(output.name), output))
                throw new IOException("Generated shader differs from approved entries: " + output.name);
            for (Output output : OUTPUTS) {
                Path dest = path(root, "shaderpacks/" + output.name);
                if (!validOutput(dest, output)) commit(privatePacks.resolve(output.name), dest, state);
            }
        } finally { deletePrivateTree(work); }
    }

    /** Controlled files after delivery, or null when any is absent or not a regular file. Directories pass safe(). */
    private static List<Stamp> stamps(Path root) throws IOException {
        path(root, "shaderpacks"); path(root, "config/fallens-shaders/input");
        List<String> relative = new ArrayList<>();
        for (Input input : INPUTS) relative.add(input.path);
        for (Output output : OUTPUTS) relative.add("shaderpacks/" + output.name);
        List<Stamp> result = new ArrayList<>();
        for (String name : relative) {
            BasicFileAttributes attributes;
            try { attributes = Files.readAttributes(root.resolve(name).normalize(), BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS); }
            catch (NoSuchFileException absent) { return null; }
            if (!attributes.isRegularFile()) return null;
            result.add(new Stamp(name, attributes.size(), attributes.lastModifiedTime(), attributes.fileKey()));
        }
        return result;
    }
    private static boolean racy(List<Stamp> stamps) {
        long recent = System.currentTimeMillis() - RACY_MILLIS;
        for (Stamp stamp : stamps) if (stamp.modified().toMillis() > recent) return true;
        return false;
    }

    /** Best effort: clean leftovers of interrupted runs and bound the backup folder. Never fails delivery. */
    private static void housekeeping(Path root, Path state) {
        try { removeOrphans(state); }
        catch (IOException | RuntimeException error) { LOG.warn("Could not scan {} for abandoned bootstrap work directories: {}", state, error.toString()); }
        try {
            Path backup = path(root, "config/fallens-shaders/backups");
            if (Files.isDirectory(backup, LinkOption.NOFOLLOW_LINKS)) pruneBackups(backup, null);
        } catch (IOException | RuntimeException error) { LOG.warn("Could not prune shader bootstrap backups: {}", error.toString()); }
    }
    private static void removeOrphans(Path state) throws IOException {
        long cutoff = System.currentTimeMillis() - ORPHAN_AGE_MILLIS;
        List<Path> candidates = new ArrayList<>();
        try (DirectoryStream<Path> children = Files.newDirectoryStream(state, ".bootstrap-*")) { children.forEach(candidates::add); }
        for (Path child : candidates) {
            BasicFileAttributes attributes = Files.readAttributes(child, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
            // Only plain directories as created by createTempDirectory; links/junctions are left alone.
            if (!attributes.isDirectory() || attributes.isSymbolicLink() || attributes.isOther()) continue;
            if (Math.max(attributes.lastModifiedTime().toMillis(), attributes.creationTime().toMillis()) > cutoff) continue;
            try { deleteTree(child, 0); LOG.info("Removed abandoned shader bootstrap work directory {}", child); }
            catch (IOException | RuntimeException error) { LOG.warn("Could not remove abandoned shader bootstrap work directory {}: {}", child, error.toString()); }
        }
    }
    private record Backup(Path path, long time) {}
    /** Keeps the KEEP_BACKUPS newest *.preserved files; a just created copy is always kept and counts as one of them. */
    private static void pruneBackups(Path backup, Path keep) throws IOException {
        List<Backup> backups = new ArrayList<>();
        String kept = keep == null ? null : keep.getFileName().toString();
        try (DirectoryStream<Path> files = Files.newDirectoryStream(backup, "*.preserved")) {
            for (Path file : files) {
                if (file.getFileName().toString().equals(kept)) continue; // a clock set back must not make it look oldest
                BasicFileAttributes attributes = Files.readAttributes(file, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS);
                if (attributes.isRegularFile())
                    backups.add(new Backup(file, Math.max(attributes.lastModifiedTime().toMillis(), attributes.creationTime().toMillis())));
            }
        }
        int room = kept == null ? KEEP_BACKUPS : KEEP_BACKUPS - 1;
        if (backups.size() <= room) return;
        backups.sort(Comparator.comparingLong(Backup::time).reversed().thenComparing(b -> b.path().getFileName().toString()));
        for (Backup old : backups.subList(room, backups.size())) {
            try { Files.delete(old.path()); }
            catch (IOException error) { LOG.warn("Could not remove old shader bootstrap backup {}: {}", old.path(), error.toString()); }
        }
    }

    private static Path path(Path root, String relative) throws IOException {
        Path result = root.resolve(relative).normalize();
        if (!result.startsWith(root) || result.equals(root)) throw new IOException("Escaping controlled path");
        safe(result); return result;
    }
    private static void safe(Path path) throws IOException {
        Path current = path.toAbsolutePath().getRoot();
        for (Path part : path.toAbsolutePath()) {
            current = current.resolve(part);
            if (Files.isSymbolicLink(current) || Files.exists(current, LinkOption.NOFOLLOW_LINKS)
                    && !current.toRealPath().equals(current.toAbsolutePath().normalize()))
                throw new IOException("Refusing linked path: " + current);
        }
    }
    private static void regularOrAbsent(Path p) throws IOException {
        safe(p);
        if (Files.exists(p, LinkOption.NOFOLLOW_LINKS) && !Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS))
            throw new IOException("Controlled destination is not a regular file: " + p);
    }
    private static void directories(Path p) throws IOException { safe(p); Files.createDirectories(p); safe(p); }
    private static MessageDigest sha() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }
    private static String hash(InputStream in, long limit) throws IOException {
        MessageDigest md = sha(); byte[] buf = new byte[16384]; long total = 0;
        for (int count; (count = in.read(buf)) != -1;) {
            total += count; if (total > limit) throw new IOException("Shader input exceeds bound");
            md.update(buf, 0, count);
        }
        return HexFormat.of().formatHex(md.digest());
    }
    private static boolean validInput(Path p, Input input) throws IOException {
        regularOrAbsent(p);
        if (!Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS) || Files.size(p) != input.size) return false;
        try (InputStream in = Files.newInputStream(p)) { if (!hash(in, input.size).equals(input.sha256)) return false; }
        try { payloads(p); return true; } catch (ZipException badZip) { return false; }
    }
    private static Map<String, String> payloads(Path p) throws IOException {
        Map<String, String> result = new TreeMap<>(); Set<String> all = new HashSet<>(); long total = 0;
        try (ZipFile zip = new ZipFile(p.toFile())) {
            for (var entries = zip.entries(); entries.hasMoreElements();) {
                ZipEntry entry = entries.nextElement(); String name = entry.getName();
                String clean = entry.isDirectory() && name.endsWith("/") ? name.substring(0, name.length()-1) : name;
                if (name.indexOf('\\') >= 0 || clean.startsWith("/") || clean.contains(":")
                        || Arrays.asList(clean.split("/", -1)).stream().anyMatch(s -> s.equals("..") || s.equals(".") || s.isEmpty()))
                    throw new ZipException("Unsafe shader entry: " + name);
                if (!all.add(name) || all.size() > MAX_ENTRIES) throw new ZipException("Duplicate/excessive shader entries");
                if (entry.isDirectory()) continue;
                long size = entry.getSize(); total += size;
                if (size < 0 || size > MAX_ENTRY || total > MAX_EXPANDED) throw new ZipException("Expanded shader ZIP exceeds bound");
                CRC32 crc = new CRC32(); MessageDigest md = sha(); long actual = 0;
                try (InputStream in = zip.getInputStream(entry)) {
                    byte[] buf = new byte[16384]; for (int n; (n = in.read(buf)) != -1;) {
                        actual += n; if (actual > size || actual > MAX_ENTRY) throw new ZipException("Invalid shader entry size");
                        crc.update(buf, 0, n); md.update(buf, 0, n);
                    }
                }
                if (actual != size || crc.getValue() != entry.getCrc()) throw new ZipException("Shader entry CRC mismatch");
                result.put(name, HexFormat.of().formatHex(md.digest()));
            }
        }
        return result;
    }
    private static boolean validOutput(Path p, Output output) throws IOException {
        regularOrAbsent(p); if (!Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS)) return false;
        Map<String, String> expected = new TreeMap<>();
        try (InputStream in = ShaderBootstrap.class.getResourceAsStream(output.manifest)) {
            if (in == null) throw new IOException("Missing approved shader entry manifest");
            for (String line : new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\n")) {
                if (line.isBlank()) continue;
                if (line.length() < 67 || !line.substring(64,66).equals("  ")) throw new IOException("Invalid entry manifest");
                expected.put(line.substring(66), line.substring(0,64));
            }
        }
        try { return !expected.isEmpty() && payloads(p).equals(expected); }
        catch (ZipException badZip) { return false; }
    }
    /** Pinned HTTPS download with a process-local pause after a failure, so reloads do not block on the network again. */
    private static void download(Input input, Path destination) throws IOException {
        if (networkFailure != null) {
            long elapsed = (System.nanoTime() - networkFailedAtNanos) / 1_000_000L;
            if (elapsed < NETWORK_RETRY_MILLIS)
                throw new IOException("Shader download not attempted: the network failed " + elapsed / 1000 + " s ago (" + networkFailure
                        + "); next attempt in this game session after " + (NETWORK_RETRY_MILLIS - elapsed + 999) / 1000 + " s or after a restart");
            networkFailure = null;
        }
        try { fetch(input, destination); }
        catch (IOException failure) { networkFailedAtNanos = System.nanoTime(); networkFailure = failure.toString(); throw failure; }
    }
    private static void fetch(Input input, Path destination) throws IOException {
        URI uri = URI.create(input.url);
        if (!uri.getScheme().equals("https") || !uri.getHost().equals("cdn.modrinth.com") || uri.getUserInfo() != null)
            throw new IOException("Shader URL is not official pinned HTTPS");
        HttpsURLConnection connection = (HttpsURLConnection) uri.toURL().openConnection();
        connection.setInstanceFollowRedirects(false); connection.setConnectTimeout(15000); connection.setReadTimeout(20000);
        connection.setRequestProperty("User-Agent", "FallensDream-ShaderBootstrap/1.3.3");
        long deadline = System.nanoTime() + 120_000_000_000L;
        try {
            if (connection.getResponseCode() != 200) throw new IOException("Shader download HTTP " + connection.getResponseCode());
            long length = connection.getContentLengthLong();
            if (length != -1 && length != input.size) throw new IOException("Shader download size differs from pin");
            try (InputStream in = connection.getInputStream(); OutputStream out = Files.newOutputStream(destination, StandardOpenOption.CREATE_NEW)) {
                byte[] buf = new byte[16384]; long total = 0;
                for (int n; (n = in.read(buf)) != -1;) {
                    total += n;
                    if (total > input.size || System.nanoTime() > deadline) throw new IOException("Shader download exceeds bound");
                    out.write(buf, 0, n);
                }
                if (total != input.size) throw new IOException("Shader download incomplete");
            }
        } finally { connection.disconnect(); }
    }
    private static void commit(Path fresh, Path dest, Path state) throws IOException {
        regularOrAbsent(dest); safe(fresh);
        if (Files.exists(dest, LinkOption.NOFOLLOW_LINKS)) {
            Path backup = state.resolve("backups"); directories(backup);
            // Opaque extension keeps preserved corrupt ZIPs out of Iris's visible pack list.
            Path preserved = backup.resolve(UUID.randomUUID() + ".preserved");
            Files.copy(dest, preserved);
            // Copies may keep the source mtime; the backup time orders pruning.
            try { Files.setLastModifiedTime(preserved, FileTime.fromMillis(System.currentTimeMillis())); }
            catch (IOException ignored) { /* ordering hint only */ }
            try { pruneBackups(backup, preserved); }
            catch (IOException | RuntimeException error) { LOG.warn("Could not prune shader bootstrap backups: {}", error.toString()); }
        }
        Files.move(fresh, dest, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
    }
    private static void invokeVendor(Path tool, Path packs, Path emptyZip) throws IOException {
        try {
            try (ZipOutputStream ignored = new ZipOutputStream(Files.newOutputStream(emptyZip, StandardOpenOption.CREATE_NEW))) {}
            try (FileSystem fs = FileSystems.newFileSystem(emptyZip, Map.of()); VendorLoader loader = new VendorLoader(tool)) {
                Path root = fs.getPath("/");
                if (root.resolve("/config.json").getFileSystem() != fs || Files.exists(root.resolve("/config.json")))
                    throw new IOException("Vendor user config is not isolated");
                Class<?> patcher = Class.forName("dev.djefrey.colorwheel_patcher.ClrwlPatcher", true, loader);
                Class<?> version = Class.forName("dev.djefrey.colorwheel_patcher.Version", true, loader);
                if (!Path.of(patcher.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath().equals(tool.toRealPath()))
                    throw new IOException("Unexpected vendor patcher source");
                Object value = version.getConstructor(int.class, int.class, int.class).newInstance(1,0,5);
                patcher.getMethod("init", version, Path.class, Path.class).invoke(null, value, packs, root);
            }
        } catch (ReflectiveOperationException | URISyntaxException exception) { throw new IOException("Pinned shader patcher failed", exception); }
    }
    private static final class VendorLoader extends URLClassLoader {
        VendorLoader(Path tool) throws IOException { super(new URL[]{tool.toUri().toURL()}, ShaderBootstrap.class.getClassLoader()); }
        @Override protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
            if (!name.startsWith("dev.djefrey.colorwheel_patcher.")) return super.loadClass(name, resolve);
            synchronized (getClassLoadingLock(name)) {
                Class<?> value = findLoadedClass(name); if (value == null) value = findClass(name);
                if (resolve) resolveClass(value); return value;
            }
        }
        private static boolean own(String name) {
            return name.equals("config.json") || name.startsWith("patches/") || name.startsWith("dev/djefrey/colorwheel_patcher/");
        }
        @Override public URL getResource(String name) { return own(name) ? findResource(name) : super.getResource(name); }
        @Override public Enumeration<URL> getResources(String name) throws IOException { return own(name) ? findResources(name) : super.getResources(name); }
    }
    private static void correctBsl(Path file, Path corrected) throws IOException {
        String before = "oit.gbuffers.colortex8.format = RGBA86", after = "oit.gbuffers.colortex8.format = RGBA8";
        boolean replaced = false;
        try (ZipFile zip = new ZipFile(file.toFile()); ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(corrected, StandardOpenOption.CREATE_NEW))) {
            for (var entries = zip.entries(); entries.hasMoreElements();) {
                ZipEntry entry = entries.nextElement(); byte[] data;
                try (InputStream in = zip.getInputStream(entry)) { data = in.readAllBytes(); }
                if (entry.getName().equals("shaders/colorwheel.properties")) {
                    String text = new String(data, StandardCharsets.UTF_8);
                    if (text.indexOf(before) < 0 || text.indexOf(before) != text.lastIndexOf(before)) throw new IOException("Unexpected vendor BSL correction target");
                    data = text.replace(before, after).getBytes(StandardCharsets.UTF_8); replaced = true;
                }
                ZipEntry target = new ZipEntry(entry.getName()); target.setTime(0); out.putNextEntry(target); out.write(data); out.closeEntry();
            }
        }
        if (!replaced) throw new IOException("Missing vendor BSL correction target");
        Files.move(corrected, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
    }
    private static void deletePrivateTree(Path dir) {
        // dir is newly created and private to this invocation. A failed cleanup must not mask the delivery
        // result; a leftover is removed by a later run once it is older than ORPHAN_AGE_MILLIS.
        try { deleteTree(dir, 0); }
        catch (IOException | RuntimeException error) { LOG.warn("Could not remove shader bootstrap work directory {}; a later start removes it: {}", dir, error.toString()); }
    }
    /** Deletes a tree without entering symbolic links or Windows junctions; a link itself is removed, never its target. */
    private static void deleteTree(Path path, int depth) throws IOException {
        if (depth > MAX_DELETE_DEPTH) throw new IOException("Work directory nesting exceeds bound: " + path);
        BasicFileAttributes attributes;
        try { attributes = Files.readAttributes(path, BasicFileAttributes.class, LinkOption.NOFOLLOW_LINKS); }
        catch (NoSuchFileException gone) { return; }
        if (attributes.isDirectory() && !attributes.isSymbolicLink() && !attributes.isOther()) {
            List<Path> children = new ArrayList<>();
            try (DirectoryStream<Path> entries = Files.newDirectoryStream(path)) { entries.forEach(children::add); }
            for (Path child : children) deleteTree(child, depth + 1);
        }
        Files.deleteIfExists(path);
    }
}

package cozy.catalog;

import java.nio.file.Path;
import java.util.function.Supplier;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Iris boundary of {@link ShaderBootstrap}. A delivery failure is written to the log and never thrown into Iris or
 * Minecraft. Iris then continues with the shader packs that are already installed; when the selected ZIP is absent,
 * Iris itself falls back to normal rendering without shaders. Only VM-level errors are rethrown.
 */
public final class ShaderBootstrapHook {
    static final Logger LOG = LoggerFactory.getLogger("CozyCatalog/ShaderBootstrap");
    private ShaderBootstrapHook() {}

    // Iris hook state recorded by CozyMixinPlugin.postApply: 0 Iris class not transformed yet, 1 call present, 2 call absent.
    private static volatile int irisHook;
    private static final java.util.concurrent.atomic.AtomicBoolean HOOK_WARNED = new java.util.concurrent.atomic.AtomicBoolean();

    static void recordIrisHook(boolean applied) { irisHook = applied ? 1 : 2; }
    static int irisHookState() { return irisHook; }

    /** Client load complete: one WARN when Iris is installed but its loadShaderpack() does not call the bootstrap. */
    public static void checkIrisHook() {
        try {
            var iris = net.neoforged.fml.loading.LoadingModList.get().getMods().stream().filter(mod -> mod.getModId().equals("iris")).findFirst();
            if (iris.isEmpty()) return;
            if (irisHook == 0) {
                // Normally Iris is already loaded and transformed at this point; loading without initialising records it.
                try { Class.forName("net.irisshaders.iris.Iris", false, ShaderBootstrapHook.class.getClassLoader()); }
                catch (ClassNotFoundException | LinkageError absent) { /* reported as missing below */ }
            }
            warnIfHookMissing(String.valueOf(iris.get().getVersion()));
        } catch (VirtualMachineError fatal) {
            throw fatal;
        } catch (Throwable error) {
            try { LOG.warn("Could not check whether the Fallen's Dream shader bootstrap is hooked into Iris: {}", describe(error)); }
            catch (VirtualMachineError fatal) { throw fatal; } catch (Throwable ignored) { }
        }
    }

    /** At most one WARN per process; false when the hook is applied or the warning was already written. */
    static boolean warnIfHookMissing(String irisVersion) {
        if (irisHook == 1 || !HOOK_WARNED.compareAndSet(false, true)) return false;
        LOG.warn("Fallen's Dream shader bootstrap is inactive: Iris {} does not reach the CozyCatalog hook in "
                + "Iris.loadShaderpack(). Shader packs are not checked, repaired or generated (BSL/Bliss + Clrwl); "
                + "update CozyCatalog for this Iris build.", irisVersion);
        return true;
    }

    @FunctionalInterface private interface Delivery { void deliver(Path gameDirectory) throws Exception; }

    /** Called by the Iris mixin with the FML game directory. */
    public static boolean beforeIrisLoadsPack() {
        return guard(() -> net.neoforged.fml.loading.FMLPaths.GAMEDIR.get(), ShaderBootstrap::ensure);
    }

    /** The same guard with an explicit game directory and the pinned HTTPS downloader. */
    public static boolean run(Supplier<Path> gameDirectory) { return guard(gameDirectory, ShaderBootstrap::ensure); }

    /** The same guard with an explicit game directory and downloader (offline fixtures). */
    public static boolean run(Supplier<Path> gameDirectory, ShaderBootstrap.Downloader downloader) {
        return guard(gameDirectory, root -> ShaderBootstrap.ensure(root, downloader));
    }

    private static boolean guard(Supplier<Path> gameDirectory, Delivery delivery) {
        long started = System.nanoTime();
        try {
            delivery.deliver(gameDirectory.get());
            return true;
        } catch (VirtualMachineError fatal) {
            throw fatal;
        } catch (Throwable error) {
            report(error, (System.nanoTime() - started) / 1_000_000L);
            return false;
        }
    }

    private static void report(Throwable error, long millis) {
        try {
            LOG.error("Fallen's Dream shader bootstrap failed after {} ms: {}. The game continues: Iris uses the shader packs "
                    + "already present in shaderpacks and renders without shaders if the selected pack is missing. "
                    + "Fix the cause, then reload shaders (R) or restart to retry.", millis, describe(error), error);
        } catch (VirtualMachineError fatal) {
            throw fatal;
        } catch (Throwable ignored) {
            // Logging must not break Iris either.
        }
    }

    /** Cause chain without trusting arbitrary toString implementations. */
    static String describe(Throwable error) {
        StringBuilder text = new StringBuilder();
        int depth = 0;
        for (Throwable cause = error; cause != null && depth < 8; cause = cause.getCause(), depth++) {
            if (depth > 0) text.append(" <- ");
            text.append(cause.getClass().getName());
            String message;
            try { message = cause.getMessage(); } catch (RuntimeException unreadable) { message = "<message unavailable>"; }
            if (message != null && !message.isBlank()) text.append(": ").append(message);
            if (cause.getCause() == cause) break;
        }
        return text.toString();
    }
}

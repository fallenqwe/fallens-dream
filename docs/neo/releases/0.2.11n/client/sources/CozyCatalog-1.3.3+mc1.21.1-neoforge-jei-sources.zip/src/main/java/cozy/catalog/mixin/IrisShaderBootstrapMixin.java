package cozy.catalog.mixin;

import cozy.catalog.ShaderBootstrapHook;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Right before Iris opens the selected pack, including reloads. In Iris 1.8.14 loadShaderpack() reaches this call
 * only after IrisConfig.areShadersEnabled() and a selected pack name, so nothing runs while shaders are disabled;
 * enabling them in the menu reloads Iris and reaches this point. Failures are logged by the hook, never thrown.
 * require = 0: a changed Iris build skips the bootstrap instead of failing the client at class load.
 */
@Pseudo
@Mixin(targets = "net.irisshaders.iris.Iris", remap = false)
public abstract class IrisShaderBootstrapMixin {
    @Inject(method = "loadShaderpack()V",
            at = @At(value = "INVOKE", target = "Lnet/irisshaders/iris/Iris;loadExternalShaderpack(Ljava/lang/String;)Z", remap = false),
            require = 0, expect = 1, remap = false)
    private static void cozy$prepareShaders(CallbackInfo ci) {
        ShaderBootstrapHook.beforeIrisLoadsPack();
    }
}

package cozy.catalog.mixin;

import cozy.catalog.KnownLanguageRepairs;
import java.util.List;
import net.minecraft.client.resources.language.ClientLanguage;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;

/** 1.21.1: repair one known source asset immediately before vanilla parses its stack. */
@Mixin(value = ClientLanguage.class, remap = false)
public abstract class LanguageStackMixin {
    @Redirect(method = "loadFrom(Lnet/minecraft/server/packs/resources/ResourceManager;Ljava/util/List;Z)Lnet/minecraft/client/resources/language/ClientLanguage;",
            at = @At(value = "INVOKE", target = "Lnet/minecraft/server/packs/resources/ResourceManager;getResourceStack(Lnet/minecraft/resources/ResourceLocation;)Ljava/util/List;"),
            require = 1, allow = 1, remap = false)
    private static List<Resource> cozyCatalog$knownLanguage(ResourceManager resources, ResourceLocation id) {
        return KnownLanguageRepairs.getStack(resources, id);
    }
}

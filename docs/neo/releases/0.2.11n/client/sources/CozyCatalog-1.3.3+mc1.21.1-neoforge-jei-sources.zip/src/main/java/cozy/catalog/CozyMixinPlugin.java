package cozy.catalog;

import java.util.List;
import java.util.Set;
import org.objectweb.asm.tree.AbstractInsnNode;
import org.objectweb.asm.tree.ClassNode;
import org.objectweb.asm.tree.MethodInsnNode;
import org.objectweb.asm.tree.MethodNode;
import org.spongepowered.asm.mixin.extensibility.IMixinConfigPlugin;
import org.spongepowered.asm.mixin.extensibility.IMixinInfo;

/**
 * Applies every mixin of cozy-catalog.mixins.json unchanged. After the optional Iris mixin is applied it inspects
 * the transformed loadShaderpack() for the actual call to our handler. With require = 0 Mixin keeps the merged
 * handler method even when the injection point is gone, so the call instruction is the reliable signal.
 */
public final class CozyMixinPlugin implements IMixinConfigPlugin {
    private static final String IRIS_MIXIN = "cozy.catalog.mixin.IrisShaderBootstrapMixin";

    @Override public void onLoad(String mixinPackage) {}
    @Override public String getRefMapperConfig() { return null; }
    @Override public boolean shouldApplyMixin(String targetClassName, String mixinClassName) { return true; }
    @Override public void acceptTargets(Set<String> myTargets, Set<String> otherTargets) {}
    @Override public List<String> getMixins() { return null; }
    @Override public void preApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {}

    @Override public void postApply(String targetClassName, ClassNode targetClass, String mixinClassName, IMixinInfo mixinInfo) {
        if (!IRIS_MIXIN.equals(mixinClassName)) return;
        try { ShaderBootstrapHook.recordIrisHook(hasBootstrapCall(targetClass)); }
        catch (VirtualMachineError fatal) { throw fatal; }
        catch (Throwable unexpected) { ShaderBootstrapHook.recordIrisHook(false); }
    }

    /** True when loadShaderpack()V of the given class calls a merged cozy$prepareShaders handler of that class. */
    public static boolean hasBootstrapCall(ClassNode target) {
        for (MethodNode method : target.methods) {
            if (!method.name.equals("loadShaderpack") || !method.desc.equals("()V") || method.instructions == null) continue;
            for (AbstractInsnNode instruction : method.instructions)
                if (instruction instanceof MethodInsnNode call && call.owner.equals(target.name) && call.name.endsWith("cozy$prepareShaders")
                        && call.desc.equals("(Lorg/spongepowered/asm/mixin/injection/callback/CallbackInfo;)V")) return true;
        }
        return false;
    }
}

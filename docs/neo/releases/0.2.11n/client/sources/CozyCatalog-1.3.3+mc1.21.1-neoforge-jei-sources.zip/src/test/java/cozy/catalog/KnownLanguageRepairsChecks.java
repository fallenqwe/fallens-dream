package cozy.catalog;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import java.io.ByteArrayInputStream;
import java.io.InputStreamReader;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Proxy;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.SharedConstants;
import net.minecraft.client.resources.language.ClientLanguage;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackLocationInfo;
import net.minecraft.server.packs.PackResources;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.PathPackResources;
import net.minecraft.server.packs.repository.PackSource;
import net.minecraft.server.packs.resources.MultiPackResourceManager;
import net.minecraft.server.packs.resources.Resource;
import net.minecraft.server.packs.resources.ResourceManager;
import net.minecraft.util.GsonHelper;

/** Reads the official dependency fixture supplied by the reviewer; does not bundle it. */
public final class KnownLanguageRepairsChecks {
    private static final Gson GSON = new Gson();
    private static int checks;
    private static void require(boolean value, String message) { checks++; if (!value) throw new AssertionError(message); }
    private static JsonObject parse(byte[] bytes) {
        return GsonHelper.fromJson(GSON, new InputStreamReader(new ByteArrayInputStream(bytes), StandardCharsets.UTF_8), JsonObject.class, false);
    }
    private static PackResources pack(String id, Path root) {
        return new PathPackResources(new PackLocationInfo(id, Component.literal(id), PackSource.DEFAULT, Optional.empty()), root);
    }
    private static Map<String,String> load(ResourceManager original, boolean repair) throws Exception {
        ResourceManager resources = repair ? (ResourceManager) Proxy.newProxyInstance(ResourceManager.class.getClassLoader(),
                new Class<?>[]{ResourceManager.class}, (proxy, method, args) -> {
                    if (method.getName().equals("getResourceStack")) return KnownLanguageRepairs.getStack(original, (ResourceLocation) args[0]);
                    try { return method.invoke(original, args); }
                    catch (InvocationTargetException error) { throw error.getCause(); }
                }) : original;
        ClientLanguage language = ClientLanguage.loadFrom(resources, List.of("uk_ua"), false);
        var field = ClientLanguage.class.getDeclaredField("storage"); field.setAccessible(true);
        @SuppressWarnings("unchecked") Map<String,String> result = (Map<String,String>)field.get(language);
        return Map.copyOf(result);
    }
    public static void main(String[] args) throws Exception {
        Path official = Path.of(args[0]), fixture = Path.of(args[1]), output = Path.of(args[2]);
        byte[] original = Files.readAllBytes(official);
        boolean red = false;
        try { parse(original); } catch (RuntimeException expected) { red = true; }
        require(red, "Original official UK fixture must reproduce native Gson failure");
        byte[] repaired = KnownLanguageRepairs.repairKnownBytes(original);
        require(repaired.length == original.length - 1, "Exactly one final comma removed");
        JsonObject expected = parse(repaired);
        require(expected.size() > 250, "Official translations retained");
        require(Arrays.equals(Files.readAllBytes(official), original), "Official on-disk dependency stays unchanged");
        byte[] custom = "{\"block.carved_wood.marker\":\"Player override\"}".getBytes(StandardCharsets.UTF_8);
        require(KnownLanguageRepairs.repairKnownBytes(custom) == custom, "Unknown user bytes returned unchanged");
        byte[] modified = original.clone(); modified[modified.length - 1] = ' ';
        require(KnownLanguageRepairs.repairKnownBytes(modified) == modified, "Different input hash is not patched");
        Path lower = fixture.resolve("lower"), higher = fixture.resolve("higher");
        for (Path root : List.of(lower, higher)) Files.createDirectories(root.resolve("assets/carved_wood/lang"));
        Files.write(lower.resolve("assets/carved_wood/lang/uk_ua.json"), original);
        Files.write(higher.resolve("assets/carved_wood/lang/uk_ua.json"), custom);
        SharedConstants.tryDetectVersion();
        try (MultiPackResourceManager manager = new MultiPackResourceManager(PackType.CLIENT_RESOURCES,
                List.of(pack("official-fixture", lower), pack("player-override", higher)))) {
            ResourceLocation id = ResourceLocation.fromNamespaceAndPath("carved_wood", "lang/uk_ua.json");
            List<Resource> stack = manager.getResourceStack(id);
            require(stack.size() == 2, "Native stack has both source resources");
            for (String[] lookalike : List.of(new String[]{"carved_wood", "lang/ru_ru.json"},
                    new String[]{"carved_wood_extra", "lang/uk_ua.json"}, new String[]{"carved_wood", "other/lang/uk_ua.json"})) {
                require(KnownLanguageRepairs.apply(ResourceLocation.fromNamespaceAndPath(lookalike[0], lookalike[1]), stack) == stack,
                        "Non-target location identity preserved");
            }
            List<Resource> fixedStack = KnownLanguageRepairs.apply(id, stack);
            require(fixedStack.size() == stack.size(), "Stack length preserved");
            for (int index = 0; index < stack.size(); index++) {
                require(fixedStack.get(index).source() == stack.get(index).source(), "Pack source identity preserved");
                require(fixedStack.get(index).metadata() == stack.get(index).metadata(), "Resource metadata preserved");
            }
            try (var stream = fixedStack.get(1).open()) { require(Arrays.equals(stream.readAllBytes(), custom), "Player override bytes preserved"); }
            Map<String,String> baseline = load(manager, false), green = load(manager, true);
            require(!baseline.containsKey("block.carved_wood.marker"), "RED reproduces namespace stack abort before override");
            require("Player override".equals(green.get("block.carved_wood.marker")), "Native language GREEN retains later player override");
            int preserved = 0;
            for (var entry : expected.entrySet()) {
                require(entry.getValue().getAsString().equals(green.get(entry.getKey())), "Native UK translation: " + entry.getKey());
                preserved++;
            }
            byte[] large = new byte[300 * 1024]; Arrays.fill(large, (byte)' ');
            Resource largeResource = new Resource(stack.getFirst().source(), () -> new ByteArrayInputStream(large));
            try (var stream = KnownLanguageRepairs.apply(id, List.of(largeResource)).getFirst().open()) {
                require(Arrays.equals(large, stream.readAllBytes()), "Oversized custom source returned completely unchanged");
            }
            Map<String,Object> report = Map.of("status", "PASS", "checks", checks, "official_keys_preserved", preserved,
                    "red_original_parse_failure", red, "native_stack_abort_reproduced", true, "native_language_green", true,
                    "original_fixture_unchanged", true, "player_overrides_preserved", true, "game_or_gui_started", false);
            Files.writeString(output, new GsonBuilder().setPrettyPrinting().create().toJson(report) + "\n", StandardCharsets.UTF_8);
            System.out.println("PASS KnownLanguageRepairs: " + checks + " checks, " + preserved + " UK keys");
        }
    }
}

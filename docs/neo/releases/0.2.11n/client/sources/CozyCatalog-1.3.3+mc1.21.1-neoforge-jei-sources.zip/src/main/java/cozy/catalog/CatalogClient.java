package cozy.catalog;

import java.text.Collator;
import java.util.*;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.runtime.IJeiRuntime;
import mezz.jei.gui.overlay.IIngredientGridSource;
import mezz.jei.gui.overlay.elements.IElement;
import net.minecraft.core.component.DataComponents;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.packs.PackType;
import net.minecraft.server.packs.repository.Pack;
import net.minecraft.server.packs.repository.PackSource;
import net.minecraft.world.item.*;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;
import net.neoforged.neoforge.event.AddPackFindersEvent;
import org.jetbrains.annotations.Nullable;
import static cozy.catalog.CatalogModel.*;

/** Presentation only: no ingredient visibility, recipes, item mutations, or world data. */
@Mod(value = CatalogClient.MOD_ID, dist = Dist.CLIENT)
public final class CatalogClient {
    public static final String MOD_ID = "cozy_catalog";
    private static volatile Selection selected = DEFAULT;
    private static @Nullable IJeiRuntime runtime;
    private static @Nullable CategoryGridSource source;
    public CatalogClient(IEventBus modBus) {
        modBus.addListener(CatalogClient::addPacks);
        // Shader delivery only: one WARN if the optional Iris hook did not apply (require = 0).
        modBus.addListener(net.neoforged.bus.api.EventPriority.NORMAL, false, net.neoforged.fml.event.lifecycle.FMLLoadCompleteEvent.class,
                event -> ShaderBootstrapHook.checkIrisHook());
        CatalogOverlay.install();
    }
    /** Required client pack reuses NeoForge's native lifecycle and leaves player options untouched. */
    private static void addPacks(AddPackFindersEvent event) {
        if (event.getPackType() != PackType.CLIENT_RESOURCES) return;
        event.addPackFinders(ResourceLocation.fromNamespaceAndPath(MOD_ID, "resourcepacks/readable_russian"),
                PackType.CLIENT_RESOURCES, Component.literal("Fallen's Dream: русский перевод"),
                PackSource.BUILT_IN, true, Pack.Position.TOP);
    }
    public static @Nullable IJeiRuntime runtime() { return runtime; }
    static void runtimeAvailable(IJeiRuntime available) { runtime = available; refresh(); }
    static void runtimeUnavailable() { runtime = null; source = null; }
    public static Selection selection() { return selected; }
    public static void select(Category category) {
        selected = new Selection(Objects.requireNonNull(category), "all", selected.sort()); refresh();
    }
    public static void selectSub(String subcategory) {
        if (subcategories(selected.category()).stream().noneMatch(value -> value.id().equals(subcategory))) return;
        selected = new Selection(selected.category(), subcategory, selected.sort()); refresh();
    }
    public static void toggleSort() {
        Sort next = Sort.values()[(selected.sort().ordinal() + 1) % Sort.values().length];
        selected = new Selection(selected.category(), selected.subcategory(), next); refresh();
    }
    public static void reset(boolean clearSearch) {
        selected = DEFAULT;
        IJeiRuntime current = runtime;
        if (clearSearch && current != null) current.getIngredientFilter().setFilterText("");
        refresh();
    }
    public static void refresh() { CategoryGridSource current = source; if (current != null) current.refresh(); }
    public static int filteredCount() { CategoryGridSource current = source; return current == null ? 0 : current.getElements().size(); }

    /** Only OverlayHelper's first source is wrapped; its history argument is kept native. */
    public static IIngredientGridSource wrap(IIngredientGridSource nativeSource) {
        CategoryGridSource wrapped = new CategoryGridSource(nativeSource, CatalogClient::filterAndOrder);
        source = wrapped; return wrapped;
    }
    /** Minecraft 1.21.1 equivalents of the established component-based facts. */
    static Facts facts(String id, ItemStack item) {
        boolean consumable = item.getUseAnimation() == UseAnim.DRINK || item.getUseAnimation() == UseAnim.EAT;
        boolean food = item.has(DataComponents.FOOD) || id.startsWith("rusticdelight:") && consumable;
        var value = item.getItem();
        boolean gear = Equipable.get(item) != null || value instanceof SwordItem || value instanceof DiggerItem
                || value instanceof TridentItem || value instanceof MaceItem;
        return new Facts(id, value instanceof BlockItem, food, item.has(DataComponents.TOOL), gear);
    }
    private static List<IElement<?>> filterAndOrder(List<IElement<?>> entries) {
        Selection snapshot = selected;
        if (snapshot.equals(DEFAULT)) return entries;
        List<IElement<?>> result = new ArrayList<>(entries.size());
        Map<IElement<?>, String> ids = new IdentityHashMap<>(), names = new IdentityHashMap<>();
        for (IElement<?> element : entries) {
            ITypedIngredient<?> typed = element.getTypedIngredient();
            Object value = typed.getIngredient();
            String id, name;
            if (value instanceof ItemStack item) {
                id = BuiltInRegistries.ITEM.getKey(item.getItem()).toString();
                if (!matches(facts(id, item), snapshot)) continue;
                name = item.getHoverName().getString();
            } else {
                // Old policy: custom/fluid ingredients are retained in All and Materials / all.
                if (snapshot.category() != Category.ALL
                        && !(snapshot.category() == Category.MATERIALS && snapshot.subcategory().equals("all"))) continue;
                String[] display = customDisplay(typed); id = display[0]; name = display[1];
            }
            result.add(element);
            if (snapshot.sort() != Sort.NATIVE) { ids.put(element, id); names.put(element, name); }
        }
        if (snapshot.sort() == Sort.NATIVE) return result;
        Collator collator = Collator.getInstance(Locale.forLanguageTag("ru")); collator.setStrength(Collator.PRIMARY);
        Comparator<IElement<?>> order = (left, right) -> {
            int comparison = collator.compare(names.get(left), names.get(right));
            return comparison != 0 ? comparison : ids.get(left).compareTo(ids.get(right));
        };
        if (snapshot.sort() == Sort.MOD)
            order = Comparator.<IElement<?>, String>comparing(element -> namespace(ids.get(element))).thenComparing(order);
        // Stable sorting retains native order among component/NBT variants of one item.
        result.sort(order); return result;
    }
    private static String namespace(String id) { int colon = id.indexOf(':'); return colon < 0 ? id : id.substring(0, colon); }
    private static <T> String[] customDisplay(ITypedIngredient<T> typed) {
        IJeiRuntime current = runtime;
        if (current != null) {
            var helper = current.getIngredientManager().getIngredientHelper(typed.getType());
            T ingredient = typed.getIngredient();
            return new String[] { helper.getResourceLocation(ingredient).toString(), helper.getDisplayName(ingredient) };
        }
        String fallback = String.valueOf(typed.getIngredient()); return new String[] { fallback, fallback };
    }
}

"""Download the pinned compile-only dependency from its official distribution."""
from pathlib import Path
import hashlib, urllib.request

TARGET=Path(__file__).resolve().parents[1]/'deps/jei-1.21.1-neoforge-19.32.0.359.jar'
URL='https://cdn.modrinth.com/data/u6dRKJwZ/versions/MAi4uKUF/jei-1.21.1-neoforge-19.32.0.359.jar'
SHA512='aa23b087254cdfae27405928c710ce632856827fa521ac0cdc9127ca40fff02a95dd8c119cdf77d7912e7ad4d317d4f14f13fa1a0e13a38135ae39be4b42c9bd'

def main():
    if TARGET.exists():
        assert hashlib.sha512(TARGET.read_bytes()).hexdigest()==SHA512, 'Existing dependency differs; inspect it before replacing'
        print('JEI compile dependency already matches pin');return
    with urllib.request.urlopen(urllib.request.Request(URL,headers={'User-Agent':'CozyCatalog-build-dependency'}),timeout=60) as response:
        raw=response.read(8*1024*1024+1)
    assert len(raw)<=8*1024*1024 and hashlib.sha512(raw).hexdigest()==SHA512, 'Dependency hash mismatch'
    TARGET.parent.mkdir(parents=True,exist_ok=True);TARGET.write_bytes(raw)
    print('Downloaded and verified '+TARGET.name)
if __name__=='__main__':main()

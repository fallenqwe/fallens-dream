# Shader delivery 1.3.3

The optional Iris mixin calls the pure-file helper inside
`net.irisshaders.iris.Iris.loadShaderpack()V`, right before its call to
`loadExternalShaderpack(String)`, that is before Iris opens its selected ZIP.
In Iris 1.8.14 this call is reached only after `IrisConfig.areShadersEnabled()`
and a selected pack name, so nothing runs while shaders are disabled. Enabling
shaders in the menu or with the toggle key reloads Iris and reaches it. The
injection uses `require = 0`: a changed Iris build skips the bootstrap instead
of failing the client while Iris loads. So that this is not silent, the mixin
config plugin `CozyMixinPlugin` inspects the transformed `loadShaderpack()` for
the actual call to the handler (the merged handler method alone proves nothing:
Mixin keeps it even when the injection point is missing). On
`FMLLoadCompleteEvent`, if Iris is installed and the call is absent or the Iris
class was never transformed, one WARN states that shader delivery is inactive.
The mod remains client only. No world, registry, packet, item, or GUI behavior is
added by this hook.

Six official source archives are pinned by fixed HTTPS URL, byte size and SHA256.
All six are verified independently of the older launcher, including when both
derived shader ZIPs already exist. Downloading rejects redirects, oversized,
truncated, or wrong-hash responses and verifies all ZIP entries and CRCs.

The three ordinary packs live directly in `shaderpacks`. Original BSL and Bliss,
and the unchanged Colorwheel Patcher 1.0.5 JAR, live in
`config/fallens-shaders/input`. When a derived output is absent or invalid, the
real vendor `ClrwlPatcher.init` operates only on private temporary source copies.
Its classes and bundled `config.json` / `patches/**` resources are loaded from
the pinned JAR, independent of other installed copies. Normal support libraries
remain inherited from the game classloader.

The vendor user-patch path uses the root of a private empty JDK ZIP filesystem.
This contains its absolute `/config.json` resolution without reading a global
drive root and requires no changes to the original vendor JAR. BSL receives the
single local `RGBA86` to `RGBA8` line correction. Both output ZIPs are validated
against frozen SHA256 manifests of every entry payload before any replacement.
The outer ZIP hash is deliberately not pinned because timestamps, order and
compression can differ. Existing correct outputs retain their exact bytes.

Controlled paths refuse symlinks and paths resolving outside their lexical
location. ZIP traversal and duplicate entries are rejected. New files replace
destinations with an atomic move on the same filesystem. Before replacing an
invalid regular file, its bytes are copied into `config/fallens-shaders/backups`
with an opaque `.preserved` extension, outside Iris's pack list. Temporary trees
are cleaned on successful or failed generation/download.

Since 1.3.3 a failure never leaves the hook (`ShaderBootstrapHook`): every
`Throwable` except a `VirtualMachineError` is logged once at ERROR level by
`CozyCatalog/ShaderBootstrap` with its cause chain. Nothing unverified is moved
into place; Iris then continues with the packs already present in `shaderpacks`
and, when the selected ZIP is absent, falls back to normal rendering itself.

After a complete verification the size and modification time of the six
inputs and two outputs are remembered in memory for this game process (the file
key too, where the platform provides one; on Windows it is null). Later reloads
skip rehashing while all eight stamps are unchanged. A different size or mtime,
an absent file or a non-regular file (for example a link) triggers the full
verification again. A replacement with the same size that keeps the old mtime
(copies made by Explorer, robocopy or `Files.copy` keep it, as does in-place
damage that does not touch the mtime) is not noticed in the running game; the
first verification after the next game start is full and repairs it. Files
written less than three seconds before a verification are not cached, which
covers mtime granularity down to 2 s. Nothing is persisted.

A failed pinned HTTPS download (connection, timeout, HTTP status or size)
pauses network access of the bootstrap for 10 minutes in this game process.
During the pause a reload needing a download fails at once with a log line
naming the original failure and the remaining time, instead of blocking the
render thread on the network again. A restart, or the next reload after the
pause, tries again. Offline repairs that need no download are unaffected.

The vendor patcher unpacks into `java.io.tmpdir` with
`Files.createTempDirectory`, whose base the JDK fixes at startup; it cannot be
redirected without changing the vendor code. Our own work directories
`config/fallens-shaders/.bootstrap-*` that are plain directories untouched for
more than 24 hours are removed at the next full verification (links and
junctions are never followed). Only the 10 newest `*.preserved` files are kept
in `config/fallens-shaders/backups`; other files there are left alone. A copy
made by the current replacement is always kept and counts as one of the ten, even
when older copies carry later timestamps (a clock that was set back).
Housekeeping failures are logged as warnings and never fail delivery.

The helper never writes `iris.properties`, per-pack `.zip.txt` options, or any
other player preference. It does not delete arbitrary user shader packs.
Exactly five ZIPs are visible for a clean delivered profile: three originals and
two local derived outputs. Additional user-installed packs remain untouched.

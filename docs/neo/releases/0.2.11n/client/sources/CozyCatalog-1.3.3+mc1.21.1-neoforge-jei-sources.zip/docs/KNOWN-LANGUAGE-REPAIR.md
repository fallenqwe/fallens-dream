# Exact compatibility repair

Carved Wood's official 1.9.8-B NeoForge release is an external dependency.
Its `assets/carved_wood/lang/uk_ua.json` contains one trailing comma rejected by
Minecraft 1.21.1's native Gson loader. A failure of the lower resource also
prevents later language overrides in that namespace from loading.

`KnownLanguageRepairs` removes only that final comma at load time, when both
the resource location and SHA256 match the tested original. It preserves pack
stack order, source, metadata and all other bytes. A corrected upstream file
or a player override with a different hash passes through untouched. The
original dependency on disk is never modified. Source reads are bounded.

No Carved Wood language text, assets or modified archive is distributed here.
Maker's Mods License permits integration as a dependency obtained from the
official sources and prohibits redistribution of modified copies. The repair
is original compatibility code; its inputs come from the separately downloaded
unmodified official dependency.

Official project: https://modrinth.com/project/WuwijfrW

Official license: https://github.com/IIAmMaker/Carved-wood/blob/master/LICENSE.txt

This is a pinned fix for Minecraft1.21.1 and Carved Wood1.9.8-B, not a general
lenient JSON parser or a global language-error suppression.

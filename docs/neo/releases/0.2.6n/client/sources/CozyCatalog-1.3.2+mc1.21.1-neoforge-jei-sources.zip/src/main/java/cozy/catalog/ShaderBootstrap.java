package cozy.catalog;

import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.security.*;
import java.util.*;
import java.util.zip.*;
import javax.net.ssl.HttpsURLConnection;

/** Pure file delivery, independent of Minecraft. No preferences or modified packs are embedded. */
public final class ShaderBootstrap {
    private ShaderBootstrap() {}
    public record Input(String path, long size, String sha256, String url) {}
    @FunctionalInterface public interface Downloader { void download(Input input, Path destination) throws IOException; }
    public static final List<Input> INPUTS = List.of(
        new Input("shaderpacks/ComplementaryReimagined_r5.9.3.zip", 553397L, "fed6c879e732cf7fc7bc6570ebb1def43235aa7e96f62859fbdbdbfa0b484b38", "https://cdn.modrinth.com/data/HVnmMxH1/versions/Bqen1mJX/ComplementaryReimagined_r5.9.3.zip"),
        new Input("shaderpacks/ComplementaryUnbound_r5.9.3.zip", 553400L, "98ac741dee294d2a3c82d153349148c3bb7fb688c30eb3b49c3b9ac37e968c5a", "https://cdn.modrinth.com/data/R6NEzAwj/versions/B1kyfoUZ/ComplementaryUnbound_r5.9.3.zip"),
        new Input("shaderpacks/photon_v1.4.zip", 3857333L, "da0929b38f5fd99befaaa8cd141cbf60e1fad05b92d916d0eeeee7c79f86c0fd", "https://cdn.modrinth.com/data/lLqFfGNs/versions/BnGklH5y/photon_v1.4.zip"),
        new Input("config/fallens-shaders/input/BSL_v10.1.zip", 1124960L, "cc61c6a25d087f1b3ef55a1bceb1cca93f97da06b28883e929c3306b25ff0dc5", "https://cdn.modrinth.com/data/Q1vvjJYV/versions/3WGx0wKu/BSL_v10.1.zip"),
        new Input("config/fallens-shaders/input/Bliss_v2.1.2_(Chocapic13_Shaders_edit).zip", 1791406L, "f41db92acc585fe9ffe0cc124d6ecaea27cef9ded91129ebc2a8e60226947b2c", "https://cdn.modrinth.com/data/ZvMtQlho/versions/kC2Y8q1P/Bliss_v2.1.2_%28Chocapic13_Shaders_edit%29.zip"),
        new Input("config/fallens-shaders/input/colorwheel_patcher-neoforge-1.0.5+mc1.21.1.jar", 210569L, "2285a5154739d2e9889d979e3bdf54104b56d7966dac8d43367305e5aaedcce8", "https://cdn.modrinth.com/data/KPsw5jDu/versions/dQqV3sci/colorwheel_patcher-neoforge-1.0.5%2Bmc1.21.1.jar")
    );
    private record Output(String name, String manifest) {}
    private static final List<Output> OUTPUTS = List.of(
        new Output("BSL_v10.1 + Clrwl_1.0.5.zip", "/cozy/shaders/bsl.entries"),
        new Output("Bliss_v2.1.2_(Chocapic13_Shaders_edit) + Clrwl_1.0.5.zip", "/cozy/shaders/bliss.entries"));
    private static final long MAX_ENTRY = 32L * 1024 * 1024, MAX_EXPANDED = 128L * 1024 * 1024;
    private static final int MAX_ENTRIES = 4096;

    public static void ensure(Path gameDirectory) throws IOException { ensure(gameDirectory, ShaderBootstrap::download); }

    /** Offline fixture seam exercises the actual production file logic with pinned inputs. */
    public static synchronized void ensure(Path gameDirectory, Downloader downloader) throws IOException {
        Path root = gameDirectory.toAbsolutePath().normalize();
        safe(root);
        if (!Files.isDirectory(root, LinkOption.NOFOLLOW_LINKS)) throw new IOException("Missing game directory");
        Path state = path(root, "config/fallens-shaders");
        directories(state); directories(path(root, "shaderpacks")); directories(path(root, "config/fallens-shaders/input"));
        for (Input input : INPUTS) regularOrAbsent(path(root, input.path));
        for (Output output : OUTPUTS) regularOrAbsent(path(root, "shaderpacks/" + output.name));
        Path work = Files.createTempDirectory(state, ".bootstrap-");
        try {
            for (Input input : INPUTS) {
                Path dest = path(root, input.path);
                if (validInput(dest, input)) continue;
                Path fresh = work.resolve("input-" + INPUTS.indexOf(input));
                downloader.download(input, fresh);
                if (!validInput(fresh, input)) throw new IOException("Pinned shader input rejected: " + input.path);
                commit(fresh, dest, state);
            }
            boolean needsBuild = false;
            for (Output output : OUTPUTS) if (!validOutput(path(root, "shaderpacks/" + output.name), output)) needsBuild = true;
            if (!needsBuild) return; // Preserve exact bytes of already valid installed ZIPs.
            Path privatePacks = work.resolve("packs"); Files.createDirectory(privatePacks);
            for (Input input : INPUTS) if (input.path.endsWith("BSL_v10.1.zip") || input.path.contains("/Bliss_v2.1.2_"))
                Files.copy(path(root, input.path), privatePacks.resolve(Path.of(input.path).getFileName()));
            invokeVendor(path(root, INPUTS.get(5).path), privatePacks, work.resolve("empty-user-patches.zip"));
            correctBsl(privatePacks.resolve(OUTPUTS.get(0).name), work.resolve("corrected-bsl.zip"));
            // Verify both generated payloads before exposing either to Iris.
            for (Output output : OUTPUTS) if (!validOutput(privatePacks.resolve(output.name), output))
                throw new IOException("Generated shader differs from approved entries: " + output.name);
            for (Output output : OUTPUTS) {
                Path dest = path(root, "shaderpacks/" + output.name);
                if (!validOutput(dest, output)) commit(privatePacks.resolve(output.name), dest, state);
            }
        } finally { deletePrivateTree(work); }
    }

    private static Path path(Path root, String relative) throws IOException {
        Path result = root.resolve(relative).normalize();
        if (!result.startsWith(root) || result.equals(root)) throw new IOException("Escaping controlled path");
        safe(result); return result;
    }
    private static void safe(Path path) throws IOException {
        Path current = path.toAbsolutePath().getRoot();
        for (Path part : path.toAbsolutePath()) {
            current = current.resolve(part);
            if (Files.isSymbolicLink(current) || Files.exists(current, LinkOption.NOFOLLOW_LINKS)
                    && !current.toRealPath().equals(current.toAbsolutePath().normalize()))
                throw new IOException("Refusing linked path: " + current);
        }
    }
    private static void regularOrAbsent(Path p) throws IOException {
        safe(p);
        if (Files.exists(p, LinkOption.NOFOLLOW_LINKS) && !Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS))
            throw new IOException("Controlled destination is not a regular file: " + p);
    }
    private static void directories(Path p) throws IOException { safe(p); Files.createDirectories(p); safe(p); }
    private static MessageDigest sha() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException impossible) { throw new AssertionError(impossible); }
    }
    private static String hash(InputStream in, long limit) throws IOException {
        MessageDigest md = sha(); byte[] buf = new byte[16384]; long total = 0;
        for (int count; (count = in.read(buf)) != -1;) {
            total += count; if (total > limit) throw new IOException("Shader input exceeds bound");
            md.update(buf, 0, count);
        }
        return HexFormat.of().formatHex(md.digest());
    }
    private static boolean validInput(Path p, Input input) throws IOException {
        regularOrAbsent(p);
        if (!Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS) || Files.size(p) != input.size) return false;
        try (InputStream in = Files.newInputStream(p)) { if (!hash(in, input.size).equals(input.sha256)) return false; }
        try { payloads(p); return true; } catch (ZipException badZip) { return false; }
    }
    private static Map<String, String> payloads(Path p) throws IOException {
        Map<String, String> result = new TreeMap<>(); Set<String> all = new HashSet<>(); long total = 0;
        try (ZipFile zip = new ZipFile(p.toFile())) {
            for (var entries = zip.entries(); entries.hasMoreElements();) {
                ZipEntry entry = entries.nextElement(); String name = entry.getName();
                String clean = entry.isDirectory() && name.endsWith("/") ? name.substring(0, name.length()-1) : name;
                if (name.indexOf('\\') >= 0 || clean.startsWith("/") || clean.contains(":")
                        || Arrays.asList(clean.split("/", -1)).stream().anyMatch(s -> s.equals("..") || s.equals(".") || s.isEmpty()))
                    throw new ZipException("Unsafe shader entry: " + name);
                if (!all.add(name) || all.size() > MAX_ENTRIES) throw new ZipException("Duplicate/excessive shader entries");
                if (entry.isDirectory()) continue;
                long size = entry.getSize(); total += size;
                if (size < 0 || size > MAX_ENTRY || total > MAX_EXPANDED) throw new ZipException("Expanded shader ZIP exceeds bound");
                CRC32 crc = new CRC32(); MessageDigest md = sha(); long actual = 0;
                try (InputStream in = zip.getInputStream(entry)) {
                    byte[] buf = new byte[16384]; for (int n; (n = in.read(buf)) != -1;) {
                        actual += n; if (actual > size || actual > MAX_ENTRY) throw new ZipException("Invalid shader entry size");
                        crc.update(buf, 0, n); md.update(buf, 0, n);
                    }
                }
                if (actual != size || crc.getValue() != entry.getCrc()) throw new ZipException("Shader entry CRC mismatch");
                result.put(name, HexFormat.of().formatHex(md.digest()));
            }
        }
        return result;
    }
    private static boolean validOutput(Path p, Output output) throws IOException {
        regularOrAbsent(p); if (!Files.isRegularFile(p, LinkOption.NOFOLLOW_LINKS)) return false;
        Map<String, String> expected = new TreeMap<>();
        try (InputStream in = ShaderBootstrap.class.getResourceAsStream(output.manifest)) {
            if (in == null) throw new IOException("Missing approved shader entry manifest");
            for (String line : new String(in.readAllBytes(), StandardCharsets.UTF_8).split("\n")) {
                if (line.isBlank()) continue;
                if (line.length() < 67 || !line.substring(64,66).equals("  ")) throw new IOException("Invalid entry manifest");
                expected.put(line.substring(66), line.substring(0,64));
            }
        }
        try { return !expected.isEmpty() && payloads(p).equals(expected); }
        catch (ZipException badZip) { return false; }
    }
    private static void download(Input input, Path destination) throws IOException {
        URI uri = URI.create(input.url);
        if (!uri.getScheme().equals("https") || !uri.getHost().equals("cdn.modrinth.com") || uri.getUserInfo() != null)
            throw new IOException("Shader URL is not official pinned HTTPS");
        HttpsURLConnection connection = (HttpsURLConnection) uri.toURL().openConnection();
        connection.setInstanceFollowRedirects(false); connection.setConnectTimeout(15000); connection.setReadTimeout(20000);
        connection.setRequestProperty("User-Agent", "FallensDream-ShaderBootstrap/1.3.2");
        long deadline = System.nanoTime() + 120_000_000_000L;
        try {
            if (connection.getResponseCode() != 200) throw new IOException("Shader download HTTP " + connection.getResponseCode());
            long length = connection.getContentLengthLong();
            if (length != -1 && length != input.size) throw new IOException("Shader download size differs from pin");
            try (InputStream in = connection.getInputStream(); OutputStream out = Files.newOutputStream(destination, StandardOpenOption.CREATE_NEW)) {
                byte[] buf = new byte[16384]; long total = 0;
                for (int n; (n = in.read(buf)) != -1;) {
                    total += n;
                    if (total > input.size || System.nanoTime() > deadline) throw new IOException("Shader download exceeds bound");
                    out.write(buf, 0, n);
                }
                if (total != input.size) throw new IOException("Shader download incomplete");
            }
        } finally { connection.disconnect(); }
    }
    private static void commit(Path fresh, Path dest, Path state) throws IOException {
        regularOrAbsent(dest); safe(fresh);
        if (Files.exists(dest, LinkOption.NOFOLLOW_LINKS)) {
            Path backup = state.resolve("backups"); directories(backup);
            // Opaque extension keeps preserved corrupt ZIPs out of Iris's visible pack list.
            Files.copy(dest, backup.resolve(UUID.randomUUID() + ".preserved"));
        }
        Files.move(fresh, dest, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
    }
    private static void invokeVendor(Path tool, Path packs, Path emptyZip) throws IOException {
        try {
            try (ZipOutputStream ignored = new ZipOutputStream(Files.newOutputStream(emptyZip, StandardOpenOption.CREATE_NEW))) {}
            try (FileSystem fs = FileSystems.newFileSystem(emptyZip, Map.of()); VendorLoader loader = new VendorLoader(tool)) {
                Path root = fs.getPath("/");
                if (root.resolve("/config.json").getFileSystem() != fs || Files.exists(root.resolve("/config.json")))
                    throw new IOException("Vendor user config is not isolated");
                Class<?> patcher = Class.forName("dev.djefrey.colorwheel_patcher.ClrwlPatcher", true, loader);
                Class<?> version = Class.forName("dev.djefrey.colorwheel_patcher.Version", true, loader);
                if (!Path.of(patcher.getProtectionDomain().getCodeSource().getLocation().toURI()).toRealPath().equals(tool.toRealPath()))
                    throw new IOException("Unexpected vendor patcher source");
                Object value = version.getConstructor(int.class, int.class, int.class).newInstance(1,0,5);
                patcher.getMethod("init", version, Path.class, Path.class).invoke(null, value, packs, root);
            }
        } catch (ReflectiveOperationException | URISyntaxException exception) { throw new IOException("Pinned shader patcher failed", exception); }
    }
    private static final class VendorLoader extends URLClassLoader {
        VendorLoader(Path tool) throws IOException { super(new URL[]{tool.toUri().toURL()}, ShaderBootstrap.class.getClassLoader()); }
        @Override protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
            if (!name.startsWith("dev.djefrey.colorwheel_patcher.")) return super.loadClass(name, resolve);
            synchronized (getClassLoadingLock(name)) {
                Class<?> value = findLoadedClass(name); if (value == null) value = findClass(name);
                if (resolve) resolveClass(value); return value;
            }
        }
        private static boolean own(String name) {
            return name.equals("config.json") || name.startsWith("patches/") || name.startsWith("dev/djefrey/colorwheel_patcher/");
        }
        @Override public URL getResource(String name) { return own(name) ? findResource(name) : super.getResource(name); }
        @Override public Enumeration<URL> getResources(String name) throws IOException { return own(name) ? findResources(name) : super.getResources(name); }
    }
    private static void correctBsl(Path file, Path corrected) throws IOException {
        String before = "oit.gbuffers.colortex8.format = RGBA86", after = "oit.gbuffers.colortex8.format = RGBA8";
        boolean replaced = false;
        try (ZipFile zip = new ZipFile(file.toFile()); ZipOutputStream out = new ZipOutputStream(Files.newOutputStream(corrected, StandardOpenOption.CREATE_NEW))) {
            for (var entries = zip.entries(); entries.hasMoreElements();) {
                ZipEntry entry = entries.nextElement(); byte[] data;
                try (InputStream in = zip.getInputStream(entry)) { data = in.readAllBytes(); }
                if (entry.getName().equals("shaders/colorwheel.properties")) {
                    String text = new String(data, StandardCharsets.UTF_8);
                    if (text.indexOf(before) < 0 || text.indexOf(before) != text.lastIndexOf(before)) throw new IOException("Unexpected vendor BSL correction target");
                    data = text.replace(before, after).getBytes(StandardCharsets.UTF_8); replaced = true;
                }
                ZipEntry target = new ZipEntry(entry.getName()); target.setTime(0); out.putNextEntry(target); out.write(data); out.closeEntry();
            }
        }
        if (!replaced) throw new IOException("Missing vendor BSL correction target");
        Files.move(corrected, file, StandardCopyOption.ATOMIC_MOVE, StandardCopyOption.REPLACE_EXISTING);
    }
    private static void deletePrivateTree(Path dir) throws IOException {
        // walk does not follow links; dir is newly created and private to this invocation.
        try (var files = Files.walk(dir)) {
            for (Path p : files.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(p);
        }
    }
}

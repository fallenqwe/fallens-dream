package cozy.catalog.mixin;

import cozy.catalog.ShaderBootstrap;
import java.io.IOException;
import net.neoforged.fml.loading.FMLPaths;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Pseudo;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Before Iris opens the selected ZIP, including reloads. */
@Pseudo
@Mixin(targets = "net.irisshaders.iris.Iris", remap = false)
public abstract class IrisShaderBootstrapMixin {
    @Inject(method = "loadShaderpack()V", at = @At("HEAD"), remap = false)
    private static void cozy$prepareShaders(CallbackInfo ci) {
        try { ShaderBootstrap.ensure(FMLPaths.GAMEDIR.get()); }
        catch (IOException error) { throw new IllegalStateException("Fallen's Dream: shader delivery failed safely", error); }
    }
}

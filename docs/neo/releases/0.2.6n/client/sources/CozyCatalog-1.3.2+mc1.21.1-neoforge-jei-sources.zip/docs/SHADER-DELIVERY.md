# Shader delivery 1.3.2

The optional Iris mixin calls the pure-file helper at the head of
`net.irisshaders.iris.Iris.loadShaderpack()V`, before Iris opens its selected ZIP.
The mod remains client only. No world, registry, packet, item, or GUI behavior is
added by this hook.

Six official source archives are pinned by fixed HTTPS URL, byte size and SHA256.
All six are verified independently of the older launcher, including when both
derived shader ZIPs already exist. Downloading rejects redirects, oversized,
truncated, or wrong-hash responses and verifies all ZIP entries and CRCs.

The three ordinary packs live directly in `shaderpacks`. Original BSL and Bliss,
and the unchanged Colorwheel Patcher 1.0.5 JAR, live in
`config/fallens-shaders/input`. When a derived output is absent or invalid, the
real vendor `ClrwlPatcher.init` operates only on private temporary source copies.
Its classes and bundled `config.json` / `patches/**` resources are loaded from
the pinned JAR, independent of other installed copies. Normal support libraries
remain inherited from the game classloader.

The vendor user-patch path uses the root of a private empty JDK ZIP filesystem.
This contains its absolute `/config.json` resolution without reading a global
drive root and requires no changes to the original vendor JAR. BSL receives the
single local `RGBA86` to `RGBA8` line correction. Both output ZIPs are validated
against frozen SHA256 manifests of every entry payload before any replacement.
The outer ZIP hash is deliberately not pinned because timestamps, order and
compression can differ. Existing correct outputs retain their exact bytes.

Controlled paths refuse symlinks and paths resolving outside their lexical
location. ZIP traversal and duplicate entries are rejected. New files replace
destinations with an atomic move on the same filesystem. Before replacing an
invalid regular file, its bytes are copied into `config/fallens-shaders/backups`
with an opaque `.preserved` extension, outside Iris's pack list. Temporary trees
are cleaned on successful or failed generation/download. If input delivery or
approved output validation fails, the mixin fails the shader load with a clear
exception rather than letting Iris open unverified bytes.

The helper never writes `iris.properties`, per-pack `.zip.txt` options, or any
other player preference. It does not delete arbitrary user shader packs.
Exactly five ZIPs are visible for a clean delivered profile: three originals and
two local derived outputs. Additional user-installed packs remain untouched.

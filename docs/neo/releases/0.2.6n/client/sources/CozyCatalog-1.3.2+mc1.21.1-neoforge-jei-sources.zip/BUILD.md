# Build

Requires Java21 and Gradle8.14.3. NeoForge and plugin dependencies are downloaded
from their configured official Maven repositories. The exact JEI compile dependency
is downloaded separately from its original Modrinth CDN, not redistributed here.

1. Run `python tools/fetch_jei.py` (Python3 standard library only).
2. Run `gradle --no-daemon check jar` with Java21 selected.

JEI is pinned because the category adapter intentionally targets the tested
19.32.0.359 internal API. Do not silently update its dependency or Minecraft.

The new narrow language checks read an external official Carved Wood fixture;
the fixture is not included in this source distribution. The standard `check`
tasks cover category/layout/native geometry. Compatibility regression evidence
for the release additionally runs the real transformed ClientLanguage before
Minecraft Main, with the unmodified dependency supplied at test time.

Version 1.3.2 also includes `cozy.catalog.ShaderBootstrapChecks`, a pure-file
integration fixture. Supply a directory containing the six exact official input
filenames pinned in `ShaderBootstrap.INPUTS`, an empty fixture game directory,
and a JSON report path. Run it with the built own JAR, test classes, Gson 2.10.1,
Guava 32.1.2-jre, and an SLF4J 2.0.9 logging provider on the classpath. Do not put
the vendor patcher on the parent classpath: the helper loads the pinned JAR from
the fixture's hidden input directory itself. Minecraft, Iris, and NeoForge are
not required on this test's runtime classpath and no game client is launched.

The fixture exercises generation with the real unchanged vendor entrypoint,
valid-repeat byte preservation, missing/corrupt input repair, corrupt output
repair, alternate ZIP container hashes with identical approved entry payloads,
wrong input hash, interrupted download cleanup, damaged CRC, traversal rejection,
and preference preservation. External shader fixtures are not redistributed in
the source archive. Their official URLs, sizes and SHA256 pins are in the helper.

# Сборка Cozy Catalog JEI

Лицензия исходников: MIT, см. LICENSE.txt. Этот архив содержит только собственный
код, ресурсы, тесты и настройки сборки. Зависимости и чужие JAR не включены.

Нужны JDK 21, Python 3.11+ и Gradle 8.14.3. Установите JAVA_HOME на JDK 21,
проверьте `java -version` и `gradle --version`. Gradle Wrapper в архив не включён.
Официальные источники: https://adoptium.net/temurin/releases/?version=21 и
https://gradle.org/releases/ . Версии Minecraft 1.21.1, NeoForge 21.1.264,
ModDevGradle 2.0.148 и JEI 19.32.0.359 закреплены в build configuration.

Из распакованного каталога выполните:

```text
python fetchdeps.py
gradle --no-daemon --console=plain clean build
```

fetchdeps.py скачивает JEI по закреплённому URL и проверяет SHA512. Первый Gradle
запуск скачивает NeoForge/Minecraft/tooling и зависимости из настроенных Maven
репозиториев. Затем доступна повторная сборка `gradle --offline clean build`.
Результат — build/libs/CozyCatalog-*.jar. Проверки CatalogChecks, LayoutChecks и
CategorySourceChecks входят в check; Minecraft и GUI не запускаются.
Mixin-аудит поставки выполняется отдельно локальной инфраструктурой проекта и
не включён в этот минимальный архив. Сборка не доказывает поведение интерфейса
в игре; ввод, рендер и пользовательская приёмка требуют отдельного плейтеста.

"""Download only the exact JEI compile dependency into this source project's deps/ directory."""
from pathlib import Path
import hashlib, urllib.request
ROOT = Path(__file__).resolve().parent
URL = 'https://cdn.modrinth.com/data/u6dRKJwZ/versions/MAi4uKUF/jei-1.21.1-neoforge-19.32.0.359.jar'
SHA512 = 'aa23b087254cdfae27405928c710ce632856827fa521ac0cdc9127ca40fff02a95dd8c119cdf77d7912e7ad4d317d4f14f13fa1a0e13a38135ae39be4b42c9bd'
DEST = ROOT / 'deps/jei-1.21.1-neoforge-19.32.0.359.jar'
if DEST.exists():
    assert hashlib.sha512(DEST.read_bytes()).hexdigest() == SHA512, 'Existing JEI dependency is corrupt; inspect it before replacing'
else:
    with urllib.request.urlopen(URL, timeout=120) as response: raw = response.read(64 * 1024 * 1024)
    assert hashlib.sha512(raw).hexdigest() == SHA512, 'JEI SHA512 mismatch; dependency not written'
    DEST.parent.mkdir(exist_ok=True)
    DEST.write_bytes(raw)
print('Exact JEI compile dependency verified:', DEST.name)

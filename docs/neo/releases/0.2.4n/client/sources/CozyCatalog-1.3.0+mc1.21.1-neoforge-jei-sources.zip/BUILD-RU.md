# Сборка Cozy Catalog JEI

Лицензия кода и собственных переводов: MIT, см. LICENSE.txt.
Общие подписи тегов включают адаптированные Apache-2.0 переводы; лицензия
и атрибуция находятся внутри resourcepacks/readable_russian/. Этот архив содержит только собственный
код, ресурсы, тесты и настройки сборки. Зависимости и чужие JAR не включены.

Нужны JDK 21, Python 3.11+ и Gradle 8.14.3. Установите JAVA_HOME на JDK 21,
проверьте `java -version` и `gradle --version`. Gradle Wrapper в архив не включён.
Официальные источники: https://adoptium.net/temurin/releases/?version=21 и
https://gradle.org/releases/ . Версии Minecraft 1.21.1, NeoForge 21.1.264,
ModDevGradle 2.0.148 и JEI 19.32.0.359 закреплены в build configuration.

Из распакованного каталога выполните:

```text
python fetchdeps.py
gradle --no-daemon --console=plain clean build
```

fetchdeps.py скачивает JEI по закреплённому URL и проверяет SHA512. Первый Gradle
запуск скачивает NeoForge/Minecraft/tooling и зависимости из настроенных Maven
репозиториев. Затем доступна повторная сборка `gradle --offline clean build`.
Результат — build/libs/CozyCatalog-*.jar. Проверки CatalogChecks, LayoutChecks,
CategorySourceChecks и NativeGeometryChecks входят в check; Minecraft и GUI не
запускаются. В исходники включён встроенный русский набор ресурсов с его
метаданными и лицензионными документами. Проверка регистрации resource pack
выполняется отдельно; сборка не доказывает выбор активного языка в игре.
Mixin-аудит поставки выполняется отдельно локальной инфраструктурой проекта и
не включён в этот минимальный архив. Сборка не доказывает поведение интерфейса
в игре; ввод, рендер и пользовательская приёмка требуют отдельного плейтеста.

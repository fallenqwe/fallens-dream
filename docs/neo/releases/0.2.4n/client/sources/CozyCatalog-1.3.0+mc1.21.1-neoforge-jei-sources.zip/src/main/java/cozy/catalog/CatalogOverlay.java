package cozy.catalog;

import com.mojang.blaze3d.platform.InputConstants;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.WeakHashMap;
import cozy.catalog.CatalogLayout.Rect;
import mezz.jei.api.runtime.IJeiRuntime;
import mezz.jei.common.Internal;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.network.chat.Component;
import net.neoforged.bus.api.EventPriority;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.ScreenEvent;
import net.neoforged.neoforge.common.NeoForge;
import org.lwjgl.glfw.GLFW;

/** Client screen adapter. It owns no entries, recipes, inventory or persistent game data. */
public final class CatalogOverlay {
    // Weak keys: a Screen dropped without a Closing event (e.g. replaced during a crash report) is not retained.
    private static final Map<Screen, Session> SESSIONS = new WeakHashMap<>();
    /** Draw status and modal content after JEI's overlay, with explicit layers for its tooltips. */
    private static final float STATUS_Z = 300F;
    private static final float POPUP_Z = 500F;
    private static boolean installed;

    private CatalogOverlay() {}

    /**
     * JEI receives screen input at NORMAL priority. Modal handlers run at HIGHEST, before JEI and
     * the container. Drawing runs at LOWEST in Render.Post, after JEI's overlay.
     */
    public static void install() {
        if (installed) return;
        installed = true;
        var bus = NeoForge.EVENT_BUS;
        bus.addListener(EventPriority.NORMAL, false, ScreenEvent.Init.Post.class, event -> {
            Screen screen = event.getScreen();
            Session session = new Session(screen);
            SESSIONS.put(screen, session); // init/resize replaces the previous session of this Screen
            event.addListener(session.catalog);
            event.addListener(session.sort);
            event.addListener(session.reset);
            session.layout();
        });
        bus.addListener(EventPriority.NORMAL, false, ScreenEvent.Render.Pre.class, event -> {
            Session session = SESSIONS.get(event.getScreen());
            if (session != null) session.layout();
        });
        bus.addListener(EventPriority.LOWEST, false, ScreenEvent.Render.Post.class, event -> {
            Session session = SESSIONS.get(event.getScreen());
            if (session != null) session.render(event.getGuiGraphics(), event.getMouseX(), event.getMouseY());
        });
        bus.addListener(EventPriority.NORMAL, false, ClientTickEvent.Post.class, event -> {
            Screen screen = Minecraft.getInstance().screen;
            Session session = screen == null ? null : SESSIONS.get(screen);
            if (session != null) session.layout();
        });
        bus.addListener(EventPriority.NORMAL, false, ScreenEvent.Closing.class, event -> SESSIONS.remove(event.getScreen()));
        bus.addListener(EventPriority.HIGHEST, false, ScreenEvent.MouseButtonPressed.Pre.class, event -> {
            Session session = SESSIONS.get(event.getScreen());
            if (session != null && !session.click(event.getMouseX(), event.getMouseY(), event.getButton()))
                event.setCanceled(true);
        });
        bus.addListener(EventPriority.HIGHEST, false, ScreenEvent.MouseButtonReleased.Pre.class, event -> {
            Session session = SESSIONS.get(event.getScreen());
            if (session != null && !session.release()) event.setCanceled(true);
        });
        bus.addListener(EventPriority.HIGHEST, false, ScreenEvent.MouseDragged.Pre.class, event -> {
            Session session = SESSIONS.get(event.getScreen());
            if (session != null && (session.open || session.consumedPress)) event.setCanceled(true);
        });
        bus.addListener(EventPriority.HIGHEST, false, ScreenEvent.MouseScrolled.Pre.class, event -> {
            Session session = SESSIONS.get(event.getScreen());
            if (session != null && !session.scroll(event.getMouseX(), event.getMouseY(), event.getScrollDeltaY()))
                event.setCanceled(true);
        });
        bus.addListener(EventPriority.HIGHEST, false, ScreenEvent.KeyPressed.Pre.class, event -> {
            Session session = SESSIONS.get(event.getScreen());
            if (session != null && !session.key(event.getKeyCode())) event.setCanceled(true);
        });
        bus.addListener(EventPriority.HIGHEST, false, ScreenEvent.KeyReleased.Pre.class, event -> {
            Session session = SESSIONS.get(event.getScreen());
            if (session != null && !session.keyRelease(event.getKeyCode())) event.setCanceled(true);
        });
        bus.addListener(EventPriority.HIGHEST, false, ScreenEvent.CharacterTyped.Pre.class, event -> {
            Session session = SESSIONS.get(event.getScreen());
            if (session != null && session.open) event.setCanceled(true);
        });
    }

    /** Pure geometry lookup: JEI invokes global providers during its own layout; never reload it here. */
    public static Collection<Rect2i> exclusions() {
        Screen screen = Minecraft.getInstance().screen;
        Session session = SESSIONS.get(screen);
        if (session == null) return List.of();
        CatalogLayout.Controls geometry = controls(screen);
        if (!geometry.visible()) return List.of();
        Rect bar = geometry.bar();
        if (session.open) {
            Rect popup = CatalogLayout.popup(bar, screen.width, screen.height, session.options().size()).bounds();
            return List.of(nativeRect(bar), nativeRect(popup));
        }
        return List.of(nativeRect(bar));
    }

    private static Rect2i nativeRect(Rect rect) {
        return new Rect2i(rect.x(), rect.y(), rect.width(), rect.height());
    }

    private static CatalogLayout.Controls controls(Screen screen) {
        IJeiRuntime runtime = Minecraft.getInstance().player == null ? null : CatalogClient.runtime();
        if (runtime == null) return CatalogLayout.controls(0, 0, 0, 0, false);
        // Exact JEI 19.32 native toggle condition, intentionally independent of ingredient-grid hasRoom.
        // isListDisplayed() includes hasRoom, so querying it here would let our own popup hide itself.
        boolean enabled = Internal.getClientToggleState().isOverlayEnabled()
                || Internal.getKeyMappings().getToggleOverlay().isUnbound();
        return runtime.getScreenHelper().getGuiProperties(screen)
                .map(gui -> CatalogLayout.controls(screen.width, screen.height, gui.guiRight(),
                        gui.screenWidth() - gui.guiRight(), enabled))
                .orElseGet(() -> CatalogLayout.controls(0, 0, 0, 0, false));
    }

    private record Option(String text, boolean selected, Runnable choose, Runnable expand) {
        boolean children() { return expand != null; }
    }

    private static final class Session {
        private static final int ROW = CatalogLayout.ROW;
        private static final int POPUP_HEADER = CatalogLayout.POPUP_HEADER;
        private static final int POPUP_FOOTER = CatalogLayout.POPUP_FOOTER;
        private final Screen screen;
        private final Button catalog;
        private final Button sort;
        private final Button reset;
        private Rect bar = Rect.EMPTY;
        private Rect popup = Rect.EMPTY;
        private boolean visible;
        private boolean open;
        private boolean subView;
        private boolean consumedPress;
        private int consumedKey = -1;
        private int scroll;
        private int cursor;
        private int visibleRows = 1;
        private long emptyCheckedAt;
        private boolean empty;

        private Session(Screen screen) {
            this.screen = screen;
            catalog = Button.builder(Component.literal("Каталог: Всё"), button -> toggle())
                    .bounds(0, 0, 100, 18).build();
            sort = Button.builder(Component.literal("Игра"), button -> CatalogClient.toggleSort())
                    .bounds(0, 0, 44, 18).build();
            reset = Button.builder(Component.literal("Сброс"), button -> CatalogClient.reset(false))
                    .bounds(0, 0, 44, 18)
                    .tooltip(Tooltip.create(Component.literal(
                            "Сбросить категорию и сортировку, сохранив поиск.\n"
                                    + "Shift + щелчок: очистить также строку поиска."))).build();
            catalog.visible = sort.visible = reset.visible = false;
        }

        private void layout() {
            Minecraft minecraft = Minecraft.getInstance();
            CatalogLayout.Controls geometry = controls(screen);
            visible = geometry.visible();
            if (!visible) {
                catalog.visible = sort.visible = reset.visible = false;
                open = false;
                bar = popup = Rect.EMPTY;
                return;
            }
            IJeiRuntime runtime = CatalogClient.runtime();
            int mainWidth = geometry.category().width();
            int sortWidth = geometry.sort().width();
            place(catalog, geometry.category());
            place(sort, geometry.sort());
            place(reset, geometry.reset());
            bar = geometry.bar();
            catalog.visible = sort.visible = reset.visible = true;

            CatalogModel.Selection selection = CatalogClient.selection();
            String category = selection.category().label();
            String sub = CatalogModel.subcategories(selection.category()).stream()
                    .filter(value -> value.id().equals(selection.subcategory()) && !value.id().equals("all"))
                    .map(CatalogModel.Subcategory::label).findFirst().orElse("");
            String title = "Каталог: " + category + (sub.isEmpty() ? "" : " / " + sub);
            Font font = minecraft.font;
            catalog.setMessage(Component.literal(shorten(font, title, mainWidth - 8)));
            catalog.setTooltip(open ? null : Tooltip.create(Component.literal(title
                    + "\nКатегория сочетается со строкой поиска JEI."
                    + "\nМеню: стрелки, Enter, Esc; колесо — прокрутка.")));
            String sortTitle = switch (selection.sort()) {
                case NAME -> "А–Я";
                case MOD -> "Мод";
                case NATIVE -> "Порядок игры";
            };
            sort.setMessage(Component.literal(shorten(font, sortTitle, sortWidth - 8)));
            sort.setTooltip(open ? null : Tooltip.create(Component.literal("Сортировка: " + sortTitle
                    + "\nПереключить: порядок игры → А–Я → мод.")));
            reset.active = selection.category() != CatalogModel.Category.ALL
                    || !selection.subcategory().equals("all") || selection.sort() != CatalogModel.Sort.NATIVE
                    || !runtime.getIngredientFilter().getFilterText().isEmpty();
            reset.setTooltip(open ? null : Tooltip.create(Component.literal(
                    "Сбросить категорию и сортировку, сохранив поиск.\n"
                            + "Shift + щелчок: очистить также строку поиска.")));

            if (open) popupGeometry();
        }

        private static void place(Button button, Rect rect) {
            button.setX(rect.x());
            button.setY(rect.y());
            button.setWidth(Math.max(1, rect.width()));
            button.setHeight(rect.height());
        }

        private List<Option> options() {
            List<Option> options = new ArrayList<>();
            CatalogModel.Selection selection = CatalogClient.selection();
            if (subView) {
                options.add(new Option("Назад к категориям", false, () -> {
                    subView = false;
                    cursor = scroll = 0;
                    popupGeometry();
                }, null));
                for (CatalogModel.Subcategory sub : CatalogModel.subcategories(selection.category())) {
                    options.add(new Option(sub.label(), sub.id().equals(selection.subcategory()), () -> {
                        CatalogClient.selectSub(sub.id());
                        close();
                    }, null));
                }
            } else {
                for (CatalogModel.Category category : CatalogModel.Category.values()) {
                    boolean hasChildren = CatalogModel.subcategories(category).size() > 1;
                    options.add(new Option(category.label(), category == selection.category(), () -> {
                        CatalogClient.select(category);
                        close();
                    }, hasChildren ? () -> {
                            CatalogClient.select(category);
                            subView = true;
                            cursor = 1;
                            scroll = 0;
                            popupGeometry();
                    } : null));
                }
            }
            return options;
        }

        private void popupGeometry() {
            int count = options().size();
            CatalogLayout.Popup geometry = CatalogLayout.popup(bar, screen.width, screen.height, count);
            visibleRows = geometry.visibleRows();
            popup = geometry.bounds();
            scroll = clamp(scroll, 0, Math.max(0, count - visibleRows));
            cursor = clamp(cursor, 0, Math.max(0, count - 1));
        }

        private void toggle() {
            if (!visible) return;
            if (open) {
                close();
                return;
            }
            open = true;
            subView = false;
            cursor = CatalogClient.selection().category().ordinal();
            scroll = 0;
            // JEI's public API has no search blur operation. All modal keys/chars are consumed above.
            popupGeometry();
            ensureCursorVisible();
        }

        private void close() {
            if (!open) return;
            open = false;
        }

        private void ensureCursorVisible() {
            if (cursor < scroll) scroll = cursor;
            if (cursor >= scroll + visibleRows) scroll = cursor - visibleRows + 1;
        }

        private boolean click(double mouseX, double mouseY, int button) {
            if (!visible) return true;
            if (open && popup.contains(mouseX, mouseY)) {
                consumedPress = true;
                if (button == InputConstants.MOUSE_BUTTON_LEFT) {
                    int row = (int) mouseY - popup.y() - POPUP_HEADER;
                    if (row >= 0 && row < visibleRows * ROW) {
                        int index = scroll + row / ROW;
                        List<Option> choices = options();
                        if (index < choices.size()) {
                            Option choice = choices.get(index);
                            if (choice.children() && mouseX >= popup.x() + popup.width() - 25)
                                choice.expand().run();
                            else choice.choose().run();
                        }
                    }
                }
                return false;
            }
            if (bar.contains(mouseX, mouseY)) {
                consumedPress = true;
                if (button == InputConstants.MOUSE_BUTTON_LEFT) {
                    if (catalog.isMouseOver(mouseX, mouseY)) toggle();
                    else if (sort.isMouseOver(mouseX, mouseY)) CatalogClient.toggleSort();
                    else if (reset.isMouseOver(mouseX, mouseY) && reset.active) {
                        CatalogClient.reset(Screen.hasShiftDown());
                        close();
                    }
                }
                // Opening and closing presses never reach JEI's item actions or the inventory.
                return false;
            }
            if (!open) return true;
            consumedPress = true;
            if (button != InputConstants.MOUSE_BUTTON_LEFT) return false;
            close(); // Dismissal never clicks the inventory/recipe beneath the menu.
            return false;
        }

        private boolean release() {
            if (consumedPress) {
                consumedPress = false;
                return false;
            }
            return !open;
        }

        private boolean scroll(double mouseX, double mouseY, double amount) {
            if (!visible || !open) return true;
            if (popup.contains(mouseX, mouseY)) {
                int direction = amount > 0 ? -1 : amount < 0 ? 1 : 0;
                scroll = clamp(scroll + direction, 0, Math.max(0, options().size() - visibleRows));
            }
            return false;
        }

        /** Native GLFW keys, consumed before JEI's focused search and ingredient shortcuts. */
        private boolean key(int keyCode) {
            if (!visible || !open) return true;
            consumedKey = keyCode;
            List<Option> choices = options();
            boolean up = keyCode == GLFW.GLFW_KEY_UP, down = keyCode == GLFW.GLFW_KEY_DOWN, tab = keyCode == GLFW.GLFW_KEY_TAB;
            if (keyCode == GLFW.GLFW_KEY_ESCAPE) {
                close();
            } else if (up || down || tab) {
                int direction = up || (tab && Screen.hasShiftDown()) ? -1 : 1;
                cursor = Math.floorMod(cursor + direction, choices.size());
                ensureCursorVisible();
            } else if (keyCode == GLFW.GLFW_KEY_ENTER || keyCode == GLFW.GLFW_KEY_KP_ENTER) {
                choices.get(cursor).choose().run();
            } else if (keyCode == GLFW.GLFW_KEY_RIGHT && choices.get(cursor).children()) {
                choices.get(cursor).expand().run();
            } else if (keyCode == GLFW.GLFW_KEY_LEFT && subView) {
                subView = false;
                cursor = CatalogClient.selection().category().ordinal();
                scroll = 0;
                popupGeometry();
                ensureCursorVisible();
            }
            return false;
        }

        private boolean keyRelease(int keyCode) {
            if (consumedKey == keyCode) {
                consumedKey = -1;
                return false;
            }
            return !open;
        }

        private void render(GuiGraphics graphics, int mouseX, int mouseY) {
            if (!visible) return;
            Minecraft minecraft = Minecraft.getInstance();
            Font font = minecraft.font;
            String tooltip = null;
            graphics.pose().pushPose();
            graphics.pose().translate(0F, 0F, STATUS_Z);
            int statusY = bar.y() + bar.height() - 11;
            long clock = System.nanoTime();
            if (clock - emptyCheckedAt > 250_000_000L) {
                empty = CatalogClient.filteredCount() == 0;
                emptyCheckedAt = clock;
            }
            String hint = empty ? "Нет совпадений · сброс" : "Категория + поиск";
            graphics.drawString(font, shorten(font, hint, bar.width() - 5), bar.x() + 2, statusY,
                    empty ? 0xFFFFC878 : 0xFFB0B5BD, false);
            if (empty && mouseX >= bar.x() && mouseX < bar.x() + bar.width()
                    && mouseY >= statusY && mouseY < bar.y() + bar.height()) {
                tooltip = "Нет предметов для выбранной категории и поиска.\n"
                        + "«Сброс» оставит поиск; Shift + щелчок очистит и его.\n"
                        + "Проверь также штатный фильтр «Только доступное».";
            }
            graphics.pose().popPose();
            if (open) {
                graphics.pose().pushPose();
                graphics.pose().translate(0F, 0F, POPUP_Z);
                tooltip = renderPopup(graphics, font, mouseX, mouseY, tooltip);
                graphics.pose().popPose();
            }
            if (tooltip != null) {
                graphics.pose().pushPose();
                graphics.pose().translate(0F, 0F, POPUP_Z);
                graphics.renderTooltip(font, Tooltip.splitTooltip(minecraft, Component.literal(tooltip)), mouseX, mouseY);
                graphics.pose().popPose();
            }
        }

        private String renderPopup(GuiGraphics graphics, Font font, int mouseX, int mouseY, String tooltip) {
            graphics.fill(popup.x() - 1, popup.y() - 1, popup.x() + popup.width() + 1, popup.y() + popup.height() + 1, 0xFF9CA6B5);
            graphics.fill(popup.x(), popup.y(), popup.x() + popup.width(), popup.y() + popup.height(), 0xFF15191F);
            graphics.fill(popup.x() + 1, popup.y() + 1, popup.x() + popup.width() - 1, popup.y() + POPUP_HEADER - 1, 0xFF282E37);
            String header = subView ? CatalogClient.selection().category().label() + " / раздел" : "Категории предметов";
            graphics.drawString(font, shorten(font, header, popup.width() - 14), popup.x() + 7, popup.y() + 7, 0xFFFFFFFF, false);
            List<Option> choices = options();
            for (int row = 0; row < visibleRows; row++) {
                int index = scroll + row;
                if (index >= choices.size()) break;
                Option choice = choices.get(index);
                int y = popup.y() + POPUP_HEADER + row * ROW;
                boolean hover = mouseX >= popup.x() + 2 && mouseX < popup.x() + popup.width() - 2
                        && mouseY >= y && mouseY < y + ROW;
                if (hover || cursor == index) graphics.fill(popup.x() + 2, y, popup.x() + popup.width() - 2, y + ROW, 0xFF394454);
                if (choice.selected()) graphics.fill(popup.x() + 3, y + 3, popup.x() + 5, y + ROW - 3, 0xFFFFD586);
                int color = choice.selected() ? 0xFFFFD586 : 0xFFE7EAF0;
                graphics.drawString(font, shorten(font, choice.text(), popup.width() - 25), popup.x() + 9, y + 5, color, false);
                if (choice.children()) {
                    int splitX = popup.x() + popup.width() - 25;
                    boolean overArrow = hover && mouseX >= splitX;
                    graphics.fill(splitX, y + 2, splitX + 1, y + ROW - 2, 0xFF566478);
                    if (overArrow) graphics.fill(splitX + 1, y + 1, popup.x() + popup.width() - 3, y + ROW - 1, 0xFF5A6E8A);
                    graphics.drawString(font, ">", popup.x() + popup.width() - 15, y + 5, 0xFFB8C5D7, false);
                    if (hover) tooltip = overArrow
                            ? "Открыть разделы: " + choice.text() + "\nКлавиатура: стрелка вправо."
                            : "Выбрать категорию: " + choice.text() + "\nEnter — выбрать; стрелка справа — разделы.";
                }
            }
            if (choices.size() > visibleRows) {
                int trackY = popup.y() + POPUP_HEADER;
                int trackHeight = ROW * visibleRows;
                int thumbHeight = Math.max(7, trackHeight * visibleRows / choices.size());
                int thumbY = trackY + (trackHeight - thumbHeight) * scroll / Math.max(1, choices.size() - visibleRows);
                graphics.fill(popup.x() + popup.width() - 3, trackY, popup.x() + popup.width() - 1, trackY + trackHeight, 0xFF343D4B);
                graphics.fill(popup.x() + popup.width() - 3, thumbY, popup.x() + popup.width() - 1, thumbY + thumbHeight, 0xFFA4B6CD);
            }
            String footer = subView ? "Колесо · Enter · ← назад · Esc" : "Enter: выбор · → разделы · Esc";
            graphics.drawString(font, shorten(font, footer, popup.width() - 12), popup.x() + 6,
                    popup.y() + popup.height() - 12, 0xFF9EACBF, false);
            return tooltip;
        }
    }

    private static String shorten(Font font, String text, int width) {
        if (font.width(text) <= Math.max(1, width)) return text;
        return font.plainSubstrByWidth(text, Math.max(1, width - font.width("…"))) + "…";
    }

    private static int clamp(int value, int min, int max) {
        return Math.max(min, Math.min(value, max));
    }
}

package cozy.catalog.mixin;

import cozy.catalog.CatalogClient;
import mezz.jei.gui.overlay.IIngredientGridSource;
import mezz.jei.gui.startup.OverlayHelper;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.ModifyVariable;

/** JEI 19.32.0.359: argument 2 is the right list; argument 3 is the separate lookup history. */
@Mixin(value = OverlayHelper.class, remap = false)
public abstract class EntryListMixin {
    @ModifyVariable(method = "createIngredientListOverlay(Lmezz/jei/api/runtime/IIngredientManager;Lmezz/jei/api/runtime/IScreenHelper;Lmezz/jei/gui/overlay/IIngredientGridSource;Lmezz/jei/gui/overlay/IIngredientGridSource;Lmezz/jei/gui/filter/IFilterTextSource;Lmezz/jei/common/input/IInternalKeyMappings;Lmezz/jei/common/config/IIngredientGridConfig;Lmezz/jei/common/config/IClientConfig;Lmezz/jei/common/config/IClientToggleState;Lmezz/jei/common/network/IConnectionToServer;Lmezz/jei/common/config/IIngredientFilterConfig;Lmezz/jei/common/gui/textures/Textures;Lmezz/jei/api/helpers/IColorHelper;)Lmezz/jei/gui/overlay/IngredientListOverlay;",
            at = @At("HEAD"), index = 2, argsOnly = true, require = 1, allow = 1, remap = false)
    private static IIngredientGridSource cozyCatalog$source(IIngredientGridSource nativeSource) {
        return CatalogClient.wrap(nativeSource);
    }
}

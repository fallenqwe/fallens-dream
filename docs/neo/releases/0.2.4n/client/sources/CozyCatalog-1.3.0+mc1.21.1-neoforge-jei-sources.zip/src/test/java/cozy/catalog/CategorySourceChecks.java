package cozy.catalog;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import mezz.jei.api.gui.drawable.IDrawable;
import mezz.jei.api.ingredients.IIngredientHelper;
import mezz.jei.api.ingredients.IIngredientRenderer;
import mezz.jei.api.ingredients.ITypedIngredient;
import mezz.jei.api.recipe.RecipeIngredientRole;
import mezz.jei.api.runtime.IRecipesGui;
import mezz.jei.common.gui.JeiTooltip;
import mezz.jei.gui.bookmarks.IBookmark;
import mezz.jei.gui.overlay.IIngredientGridSource;
import mezz.jei.gui.overlay.IngredientGridTooltipHelper;
import mezz.jei.gui.overlay.elements.IElement;
import mezz.jei.gui.util.FocusUtil;

/** Checks source isolation and same-query refresh without Minecraft initialization or a window. */
public final class CategorySourceChecks {
    public static void main(String[] args) {
        var first = new DummyElement();
        var second = new DummyElement();
        var delegate = new Source(List.of(first, second));
        var transforms = new AtomicInteger();
        var selected = new AtomicInteger(1);
        var filtered = new CategoryGridSource(delegate, entries -> {
            transforms.incrementAndGet();
            return entries.subList(0, selected.get());
        });
        check(filtered.getElements().equals(List.of(first)), "category output must replace only the wrapped view");
        check(delegate.getElements().equals(List.of(first, second)), "native source must remain intact");
        var oldSnapshot = filtered.getElements();
        check(transforms.get() == 1, "unchanged native source must reuse the computed view");
        try { oldSnapshot.clear(); throw new AssertionError("snapshot must be immutable"); }
        catch (UnsupportedOperationException expected) { }
        var notifications = new AtomicInteger();
        filtered.addSourceListChangedListener(notifications::incrementAndGet);
        selected.set(2);
        filtered.refresh();
        check(notifications.get() == 1, "category changes with the same search must notify the right grid");
        check(filtered.getElements().equals(List.of(first, second)), "same-query category change must recompute");
        check(oldSnapshot.equals(List.of(first)), "published snapshots must not change later");
        delegate.elements = List.of(second, first);
        delegate.changed();
        check(notifications.get() == 2, "native search changes must propagate to the right grid");
        check(filtered.getElements().equals(List.of(second, first)), "new native order must propagate unchanged");
        check(transforms.get() == 3, "cache must invalidate for own and native changes");
        System.out.println("PASS: category source isolation, immutable cache and same-query/native refresh");
    }
    private static void check(boolean value, String message) { if (!value) throw new AssertionError(message); }
    private static final class Source implements IIngredientGridSource {
        private List<IElement<?>> elements;
        private final List<SourceListChangedListener> listeners = new ArrayList<>();
        Source(List<IElement<?>> elements) { this.elements = elements; }
        public List<IElement<?>> getElements() { return elements; }
        public void addSourceListChangedListener(SourceListChangedListener listener) { listeners.add(listener); }
        void changed() { listeners.forEach(SourceListChangedListener::onSourceListChanged); }
    }
    /** No ingredient methods are needed by the source boundary; the native UI retains these identities. */
    private static final class DummyElement implements IElement<Object> {
        public ITypedIngredient<Object> getTypedIngredient() { throw new UnsupportedOperationException(); }
        public java.util.Optional<IBookmark> getBookmark() { return java.util.Optional.empty(); }
        public IDrawable createRenderOverlay() { throw new UnsupportedOperationException(); }
        public void show(IRecipesGui gui, FocusUtil focus, List<RecipeIngredientRole> roles) { throw new UnsupportedOperationException(); }
        public void getTooltip(JeiTooltip tooltip, IngredientGridTooltipHelper helper,
                               IIngredientRenderer<Object> renderer, IIngredientHelper<Object> ingredientHelper) { throw new UnsupportedOperationException(); }
        public boolean isVisible() { return true; }
    }
}

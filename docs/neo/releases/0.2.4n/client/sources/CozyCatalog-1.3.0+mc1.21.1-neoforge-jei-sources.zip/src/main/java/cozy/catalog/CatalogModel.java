package cozy.catalog;

import java.util.*;

/** Functional categories may overlap. The catch-all view never removes an entry. */
public final class CatalogModel {
    public enum Category {
        ALL("Всё"),FURNITURE("Мебель"),DECOR("Декор и свет"),BUILDING("Строительство"),MECHANISMS("Механизмы"),TOOLS("Инструменты"),GEAR("Снаряжение"),MATERIALS("Материалы"),FOOD("Еда и ферма"),NATURE("Природа"),OTHER("Прочее");
        private final String label;Category(String label){this.label=label;}public String label(){return label;}
    }
    public enum Sort {NATIVE,NAME,MOD}
    public record Selection(Category category,String subcategory,Sort sort){
        public Selection {Objects.requireNonNull(category);Objects.requireNonNull(subcategory);Objects.requireNonNull(sort);}
    }
    public record Subcategory(String id,String label){}
    public record Facts(String id,boolean block,boolean food,boolean tool,boolean gear){}
    public static final Selection DEFAULT=new Selection(Category.ALL,"all",Sort.NATIVE);
    private CatalogModel(){}
    private static boolean has(String text,String... fragments){for(String f:fragments)if(text.contains(f))return true;return false;}
    private static boolean one(String text,String... names){for(String n:names)if(text.equals(n))return true;return false;}
    private static boolean family(String path,String... names){for(String n:names)if(path.equals(n)||path.endsWith("_"+n))return true;return false;}
    private static boolean cgsWeapon(String ns,String p){
        return one(ns,"cgs")&&one(p,"flintlock","revolver","shotgun","nailgun","gatling","blazegun","launcher","hammer","frag_grenade");
    }
    private static boolean backpack(String ns,String p){
        return one(ns,"sophisticatedbackpacks","travelersbackpack")&&family(p,"backpack");
    }
    private static boolean createMechanism(Facts f,String ns,String p){
        // Mixed namespaces also contain decorative building blocks. Match functional families only.
        return f.block()&&one(ns,"create","copycats","create_connected","create_vibrant_vaults","create_mobile_packages")
                &&family(p,"shaft","cogwheel","gearbox","clutch","gearshift","chain_drive","bearing","motor",
                "pump","fluid_pipe","fluid_tank","funnel","tunnel","chute","encased_fan","deployer","drill","saw",
                "mechanical_press","mechanical_mixer","spout","basin","packager","stock_link","stock_ticker","item_vault",
                "shipping_container","package_frogport","mechanical_arm","rotation_speed_controller","speedometer","stressometer",
                "water_wheel","crushing_wheel","steam_engine","blaze_burner");
    }
    public static EnumSet<Category> categories(Facts f){
        String id=f.id(),ns=id.substring(0,id.indexOf(':')),p=id.substring(id.indexOf(':')+1);EnumSet<Category> out=EnumSet.of(Category.ALL);
        boolean gunBarrel=one(ns,"cgs")&&one(p,"barrel","barrel_sturdy");
        boolean portableStorage=backpack(ns,p);
        boolean storage=!gunBarrel&&(one(p,"chest","barrel","shulker_box")||p.endsWith("_chest")||p.endsWith("_shulker_box")||portableStorage&&f.block());
        boolean mdmFurnishing=one(ns,"mdm")&&f.block();
        boolean modernFurniture=one(ns,"moderndeco")&&f.block()&&one(p,"armchair","armchair_2","sofamd","sofamd_1","glasstable","glass_table_2","fridge","toilet");
        boolean interiorSeating=one(ns,"interiors")&&f.block()&&family(p,"chair","cushion","seat");
        boolean furnishing=mdmFurnishing||modernFurniture||interiorSeating||one(ns,"mcwfurnitures","skniro_furniture","storagedelight","mcwwindows","mcwdoors")||has(p,"_bed","_bookshelf","_shelf")||storage||one(p,"bookshelf","chiseled_bookshelf","lectern");
        boolean light=one(ns,"mcwlights")||has(p,"torch","lantern","candle","lamp","glowstone","froglight","campfire","end_rod","sea_pickle")||one(p,"light");
        // Tiny Flowers uses one BlockItem with components for every flower/mini-garden.
        // Keep namespace-wide tools (e.g. florists_shears) outside plant categories.
        boolean gardenPlant=one(ns,"tiny_flowers")&&f.block()&&one(p,"tiny_flower");
        boolean hedge=one(ns,"mcwfences")&&f.block()&&p.endsWith("_hedge");
        boolean decor=gardenPlant||hedge||light||has(p,"flower_pot","_banner","_carpet","_head","_skull","painting","item_frame","armor_stand","decor","sandcastle","shelf","curtain","blind","shutter","coral","_flower","_tulip","_orchid","_daisy","_rose","_bush")||one(p,"poppy","dandelion","allium","azalea","flowering_azalea","spore_blossom","lily_of_the_valley");
        decor|=mdmFurnishing&&one(p,"plate","mug","knife","fork","spoon","knife_stand","chopping_board");
        decor|=one(ns,"moderndeco")&&f.block()&&(one(p,"wallclock","poster","mini_poster","gamepad","gamepadblack","telephone","tv","tvminidesktop","tvminimounted","laptopblack","laptopsilver","laptopwhite","tablet","graphictablet","steamdeck","subwoofer","smartspeakeralice")||p.startsWith("poster_")||p.startsWith("mini_poster_")||p.startsWith("carpet"));
        decor|=one(ns,"exposure")&&one(p,"photograph","aged_photograph","stacked_photographs","photograph_frame","glass_photograph_frame");
        boolean mech=has(p,"redstone","piston","observer","hopper","dispenser","dropper","repeater","comparator","daylight_detector","tripwire","pressure_plate","_button","_lever","_rail","minecart","target","sculk_sensor","copper_bulb","crafter","furnace","smoker","blast_furnace","crafting_table","smithing_table","stonecutter","grindstone","anvil","brewing_stand","enchanting_table","cartography_table","composter","cooking_table","kitchen","stove","oven","sink","fridge","water_filter")||one(p,"lever","loom","rail","lightning_rod","bell","note_block","jukebox","chest","trapped_chest","barrel","beacon");
        mech|=storage||p.endsWith("_lightning_rod")||p.endsWith("_chest_boat")||p.endsWith("_chest_raft");
        mech|=createMechanism(f,ns,p);
        if(gunBarrel)mech=false;
        // These exact MDM appliances are decorative, unlike the working CFB ovens.
        if(mdmFurnishing&&one(p,"oven","gas_stove","set_1_oven_microwave","kitchen_set_3_oven_top","kitchen_set_3_oven_bottom","kitchen_set_3_dishwasher"))mech=false;
        boolean tool=f.tool()||has(p,"pickaxe","_axe","shovel","_hoe","shears","fishing_rod","flint_and_steel","brush","chisel","wrench","hammer","knife","bucket","compass","clock","spyglass","name_tag","bundle","scaffolding","_boat","_raft")||one(p,"lead","map","filled_map","recovery_compass");
        if(mdmFurnishing)tool=f.tool(); // Placed utensils and clocks are not usable tools.
        if(one(ns,"moderndeco")&&f.block()&&one(p,"wallclock"))tool=f.tool();
        tool|=portableStorage||one(ns,"exposure")&&one(p,"camera")||one(ns,"exposure_polaroid")&&one(p,"instant_camera");
        boolean gear=f.gear()||has(p,"_sword","_spear","helmet","chestplate","leggings","_boots","_horse_armor","wolf_armor","elytra","trident","crossbow","potion","enchanted_book","totem_of_undying")||p.endsWith("_arrow")||one(p,"arrow","bow","shield","mace","saddle","wind_charge","firework_rocket");
        gear|=cgsWeapon(ns,p);
        gear|=one(ns,"artifacts")&&!f.block()&&!f.food()&&!p.endsWith("_spawn_egg");
        boolean farm=has(p,"seeds","wheat","carrot","potato","beetroot","cabbage","tomato","onion","rice","pumpkin","melon","cocoa","sugar_cane","_berries","honey","milk","dough","flour","coconut","pepper","cooking_pot","skillet","cutting_board","rich_soil","farmland","wild_")||one(p,"salt","egg","blue_egg","brown_egg","turtle_egg","sniffer_egg");
        boolean nature=gardenPlant||hedge||has(p,"sapling","leaves","moss","grass","fern","vine","roots","propagule","coral","kelp","seagrass","lily_pad","sea_pickle","_flower","_tulip","_bush","_mushroom","fungus","cactus","bamboo","_spawn_egg")||one(p,"poppy","dandelion","allium","azalea","flowering_azalea","spore_blossom","lily_of_the_valley","wither_rose","dead_bush","pink_petals","pitcher_plant","torchflower","blue_orchid","oxeye_daisy");
        boolean wood=has(p,"planks","_log","_wood","_stem","hyphae","bamboo_block","bamboo_mosaic");
        boolean stone=has(p,"stone","cobble","deepslate","tuff","andesite","diorite","granite","basalt","blackstone","calcite","sand","gravel","clay","terracotta","concrete","mud","brick","quartz","prismarine","obsidian","netherrack","end_stone");
        boolean material=wood||stone||has(p,"_ingot","_nugget","_ore","raw_","_dust","_shard","_crystal","leather","string","feather","slime_ball","magma_cream","blaze_rod","blaze_powder","bone","gunpowder","paper","_dye","_wool","_scrap","rabbit_hide","resin_clump")||one(p,"stick","coal","charcoal","diamond","emerald","amethyst_shard","redstone","quartz","flint","clay_ball","glass","glass_pane","glowstone_dust","iron_bars","copper_grate","book","ender_pearl","ender_eye","nether_star","breeze_rod");
        material|=one(ns,"mdm")&&one(p,"furniture_parts");
        material|=gunBarrel;
        if(furnishing)out.add(Category.FURNITURE);if(decor)out.add(Category.DECOR);
        if(f.block()&&(!furnishing&&!nature||one(ns,"mcwdoors","mcwwindows","mcwroofs","mcwfences","mcwpaths","stoneworks","rechiseled")))out.add(Category.BUILDING);
        if(mech)out.add(Category.MECHANISMS);if(tool)out.add(Category.TOOLS);if(gear)out.add(Category.GEAR);
        if(material&&!furnishing&&!tool&&!gear)out.add(Category.MATERIALS);if(f.food()||farm||one(ns,"farmersdelight")&&!tool||one(ns,"rusticdelight")&&!tool&&!gear)out.add(Category.FOOD);if(nature)out.add(Category.NATURE);
        if(out.size()==1)out.add(Category.OTHER);return out;
    }
    public static boolean matches(Facts f,Selection s){
        if(s.category()==Category.ALL)return true;if(!categories(f).contains(s.category()))return false;
        if(s.subcategory().equals("all"))return true;String p=f.id().substring(f.id().indexOf(':')+1),ns=f.id().substring(0,f.id().indexOf(':'));
        return switch(s.subcategory()){
            case "seats"->has(p,"chair","stool","bench","sofa","couch","seat","cushion");
            case "tables"->has(p,"table","desk","counter");
            case "storage"->backpack(ns,p)||has(p,"cabinet","drawer","wardrobe","cupboard","shelf","bookshelf","chest","barrel","dresser","storage","shulker_box");
            case "beds"->has(p,"bed");case "openings"->one(ns,"mcwwindows","mcwdoors")||has(p,"door","window","blind","shutter","curtain");
            case "lighting"->one(ns,"mcwlights")||has(p,"torch","lantern","candle","lamp","froglight","glowstone","end_rod","campfire","sea_pickle")||one(p,"light");
            case "plants"->categories(f).contains(Category.NATURE)&&!has(p,"_spawn_egg");
            case "wood"->has(p,"oak","spruce","birch","jungle","acacia","cherry","mangrove","bamboo","crimson","warped","pale","poplar","coconut","plank","_log","_wood","_stem","hyphae");
            case "stone"->has(p,"stone","cobble","slate","tuff","andesite","diorite","granite","basalt","calcite","sand","gravel","clay","mud","brick","terracotta","concrete","quartz","prismarine","obsidian","netherrack");
            case "glass"->has(p,"glass");case "shapes"->has(p,"stairs","slab");case "exterior"->one(ns,"mcwroofs","mcwfences","mcwpaths")||has(p,"fence","roof","railing","wall");
            case "redstone"->has(p,"redstone","piston","observer","hopper","dispenser","dropper","repeater","comparator","daylight_detector","tripwire","pressure_plate","button","lever","target","sculk_sensor","copper_bulb","crafter")||one(p,"lightning_rod")||p.endsWith("_lightning_rod");
            case "workstations"->has(p,"furnace","smoker","table","stonecutter","grindstone","anvil","brewing","enchanting","composter","cooking","kitchen","stove","oven","sink","fridge")||one(p,"loom");
            case "transport"->has(p,"rail","minecart","hopper","chest","barrel","dispenser","dropper","shulker_box");
            case "mining"->has(p,"pickaxe","_axe","shovel");case "farming"->has(p,"_hoe","shears","knife","fishing_rod","seeds","wheat","carrot","potato","rice","onion","cabbage","tomato","farmland","rich_soil","wild_");
            case "weapons"->cgsWeapon(ns,p)||has(p,"sword","spear","bow","trident","mace","wind_charge")||one(p,"arrow")||p.endsWith("_arrow");case "armor"->has(p,"helmet","chestplate","leggings","boots","armor","shield");case "special"->one(ns,"artifacts")&&categories(f).contains(Category.GEAR)||has(p,"elytra","potion","enchanted_book","totem","saddle","firework");
            case "metals"->has(p,"ore","ingot","nugget","raw_","iron","gold","copper","netherite","diamond","emerald","amethyst","scrap");case "ingredients"->!f.food();case "edible"->f.food();
            case "saplings"->has(p,"sapling","propagule");case "sea"->has(p,"coral","kelp","seagrass","lily_pad","sea_pickle");
            default->false;
        };
    }
    public static List<Subcategory> subcategories(Category c){
        String[][] rows=switch(c){
            case FURNITURE->new String[][]{{"seats","Стулья и диваны"},{"tables","Столы и стойки"},{"storage","Шкафы и полки"},{"beds","Кровати"},{"openings","Окна, двери и жалюзи"}};
            case DECOR->new String[][]{{"lighting","Освещение"},{"plants","Растения"},{"openings","Шторы и жалюзи"}};
            case BUILDING->new String[][]{{"wood","Дерево"},{"stone","Камень и кирпич"},{"glass","Стекло"},{"shapes","Плиты и ступени"},{"exterior","Крыши и ограды"}};
            case MECHANISMS->new String[][]{{"redstone","Редстоун"},{"workstations","Рабочие места"},{"transport","Хранение и транспорт"}};
            case TOOLS->new String[][]{{"mining","Добыча"},{"farming","Ферма и рыбалка"}};
            case GEAR->new String[][]{{"weapons","Оружие"},{"armor","Броня и щиты"},{"special","Особое снаряжение"}};
            case MATERIALS->new String[][]{{"wood","Древесина"},{"stone","Камень и сыпучие"},{"metals","Руды и металлы"}};
            case FOOD->new String[][]{{"edible","Готовая еда"},{"ingredients","Ингредиенты"},{"farming","Ферма"}};
            case NATURE->new String[][]{{"plants","Растения"},{"saplings","Саженцы"},{"sea","Морское"}};
            default->new String[0][];
        };
        List<Subcategory> result=new ArrayList<>();result.add(new Subcategory("all","Вся категория"));for(String[] row:rows)result.add(new Subcategory(row[0],row[1]));return List.copyOf(result);
    }
}

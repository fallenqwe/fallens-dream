package cozy.catalog;

/** Pure GUI geometry: shared by the JEI adapter and standalone preview generation. */
public final class CatalogLayout {
    public static final int ROW = 18;
    public static final int POPUP_HEADER = 22;
    public static final int POPUP_FOOTER = 18;
    // Pinned JEI navigation ends at 26, or 31 with its background. Keep the outer border below both.
    private static final int CONTENT_TOP = 33;
    public record Rect(int x, int y, int width, int height) {
        public static final Rect EMPTY = new Rect(0, 0, 0, 0);
        public int right() { return x + width; }
        public int bottom() { return y + height; }
        public boolean contains(double px, double py) { return px >= x && px < right() && py >= y && py < bottom(); }
        public boolean contains(Rect rect) { return rect.x >= x && rect.y >= y && rect.right() <= right() && rect.bottom() <= bottom(); }
        public boolean overlaps(Rect rect) { return x < rect.right() && right() > rect.x && y < rect.bottom() && bottom() > rect.y; }
    }
    public record Controls(boolean visible, Rect category, Rect sort, Rect reset, Rect bar) {}
    public record Popup(Rect bounds, int visibleRows) {}
    private CatalogLayout() {}
    public static Controls controls(int screenWidth, int screenHeight, int guiRight, int rightWidth, boolean enabled) {
        // A two-row toolbar must leave at least one JEI ingredient row above its native search field.
        if (!enabled || rightWidth < 72 || screenHeight < 128)
            return new Controls(false, Rect.EMPTY, Rect.EMPTY, Rect.EMPTY, Rect.EMPTY);
        int x = Math.max(3, guiRight + 2);
        int width = Math.min(rightWidth - 4, screenWidth - x - 3);
        if (width < 67) return new Controls(false, Rect.EMPTY, Rect.EMPTY, Rect.EMPTY, Rect.EMPTY);
        int y = CONTENT_TOP;
        boolean narrow = width < 220;
        int resetWidth = narrow ? Math.min(48, Math.max(34, width / 3)) : 45;
        int sortWidth = narrow ? width - resetWidth - 3 : Math.min(90, width / 3);
        int mainWidth = narrow ? width : width - sortWidth - resetWidth - 6;
        return new Controls(true,
                new Rect(x, y, mainWidth, 18),
                new Rect(narrow ? x : x + mainWidth + 3, narrow ? y + 21 : y, sortWidth, 18),
                new Rect(x + width - resetWidth, narrow ? y + 21 : y, resetWidth, 18),
                new Rect(x - 1, y - 1, width + 2, narrow ? 55 : 34));
    }
    public static Popup popup(Rect bar, int screenWidth, int screenHeight, int count) {
        int width = Math.min(Math.max(190, bar.width()), Math.max(60, screenWidth - 8));
        int x = Math.max(4, Math.min(bar.right() - width, screenWidth - width - 4));
        int y = bar.bottom() + 2;
        int maxHeight = screenHeight - y - 25;
        if (maxHeight < POPUP_HEADER + POPUP_FOOTER + ROW) {
            y = CONTENT_TOP;
            maxHeight = screenHeight - y - 25;
        }
        int rows = Math.max(1, Math.min(Math.max(1, count), (maxHeight - POPUP_HEADER - POPUP_FOOTER) / ROW));
        return new Popup(new Rect(x, y, width, POPUP_HEADER + POPUP_FOOTER + rows * ROW), rows);
    }
}

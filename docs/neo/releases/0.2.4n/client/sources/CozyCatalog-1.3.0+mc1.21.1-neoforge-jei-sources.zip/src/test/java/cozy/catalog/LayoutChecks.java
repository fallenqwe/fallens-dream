package cozy.catalog;

/** Main-style checks for geometry shared by the live adapter and programmatic previews. */
public final class LayoutChecks {
    private static int checks;

    public static void main(String[] args) {
        // A valid right panel must expose controls without touching the container or native page arrows.
        var wide = CatalogLayout.controls(960, 540, 568, 392, true);
        check(wide.visible(), "valid JEI right panel exposes controls");
        check(wide.category().x() >= 568 && wide.reset().right() <= 957,
                "wide controls remain outside inventory and inside screen");
        // Pinned JEI with background occupies y=11..30; preserve the complete navigation.
        check(wide.bar().y() >= 32, "bar and input capture stay below native page arrows");
        check(!wide.bar().overlaps(new CatalogLayout.Rect(568, 11, 392, 20)),
                "wide toolbar exclusion leaves the complete native navigation clickable");
        check(!wide.category().overlaps(wide.sort()) && !wide.sort().overlaps(wide.reset()),
                "wide controls have distinct hit targets");
        check(wide.bar().contains(wide.category()) && wide.bar().contains(wide.reset()),
                "JEI exclusion covers the entire controls");

        var narrow = CatalogLayout.controls(480, 270, 328, 152, true);
        check(narrow.visible() && narrow.sort().y() > narrow.category().y(),
                "narrow right panel wraps utility controls below category");
        check(!narrow.sort().overlaps(narrow.reset()), "narrow utility controls have distinct hit targets");
        check(narrow.bar().contains(narrow.sort()) && narrow.bar().contains(narrow.reset()),
                "two-row bar exclusion covers utility controls");
        check(narrow.bar().y() >= 32 && !narrow.bar().overlaps(new CatalogLayout.Rect(328, 11, 152, 20)),
                "compact toolbar preserves the complete native navigation");
        check(!CatalogLayout.controls(480, 270, 420, 60, true).visible(),
                "insufficient right margin hides controls");
        check(!CatalogLayout.controls(480, 270, 328, 152, false).visible(),
                "disabled JEI hides controls");
        check(!CatalogLayout.controls(480, 110, 328, 152, true).visible(),
                "short layout keeps room for native ingredient grid and search");

        for (int width : new int[] {320, 480, 960}) {
            for (int height : new int[] {128, 180, 270, 540}) {
                var controls = CatalogLayout.controls(width, height, width - 152, 152, true);
                for (int count : new int[] {1, 5, 18, 30}) {
                    var popup = CatalogLayout.popup(controls.bar(), width, height, count);
                    var rect = popup.bounds();
                    check(rect.x() >= 4 && rect.right() <= width - 4,
                            "popup stays horizontally inside screen: " + width);
                    check(rect.y() - 1 >= 32 && rect.bottom() <= height - 25,
                            "popup including border preserves navigation and bottom search: " + width + "x" + height);
                    check(popup.visibleRows() >= 1 && popup.visibleRows() <= count,
                            "popup clips scrollable rows to available height");
                }
            }
        }
        var hit = new CatalogLayout.Rect(10, 20, 30, 40);
        check(hit.contains(10, 20) && !hit.contains(40, 60), "hit targets use half-open pixel bounds");
        System.out.println("LayoutChecks: " + checks + " PASS");
        if (args.length > 0 && args[0].equals("--preview")) {
            printPreview("wide-categories", wide, 960, 540, 11);
            printPreview("narrow-categories", narrow, 480, 270, 11);
            printPreview("normal-categories", CatalogLayout.controls(640, 360, 408, 232, true), 640, 360, 11);
            printPreview("compact-categories", CatalogLayout.controls(426, 240, 301, 125, true), 426, 240, 11);
        } else if (args.length == 5 && args[0].equals("--geometry")) {
            int width = Integer.parseInt(args[1]), height = Integer.parseInt(args[2]);
            int guiRight = Integer.parseInt(args[3]), count = Integer.parseInt(args[4]);
            printPreview("custom", CatalogLayout.controls(width, height, guiRight, width - guiRight, true),
                    width, height, count);
        }
    }

    private static void check(boolean condition, String message) {
        checks++;
        if (!condition) throw new AssertionError(message);
    }

    private static void printPreview(String name, CatalogLayout.Controls controls, int width, int height, int count) {
        var popup = CatalogLayout.popup(controls.bar(), width, height, count);
        System.out.println("{\"name\":\"" + name + "\",\"screen\":[" + width + "," + height
                + "],\"category\":" + json(controls.category()) + ",\"sort\":" + json(controls.sort())
                + ",\"reset\":" + json(controls.reset()) + ",\"bar\":" + json(controls.bar())
                + ",\"popup\":" + json(popup.bounds()) + ",\"optionCount\":" + count
                + ",\"visibleRows\":" + popup.visibleRows() + "}");
    }

    private static String json(CatalogLayout.Rect rect) {
        return "[" + rect.x() + "," + rect.y() + "," + rect.width() + "," + rect.height() + "]";
    }
}

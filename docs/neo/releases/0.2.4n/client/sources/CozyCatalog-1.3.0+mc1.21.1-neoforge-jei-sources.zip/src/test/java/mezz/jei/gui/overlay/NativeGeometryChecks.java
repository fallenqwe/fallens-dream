package mezz.jei.gui.overlay;

import java.util.Set;
import mezz.jei.common.config.IIngredientGridConfig;
import mezz.jei.common.util.*;
import mezz.jei.api.gui.placement.*;
import cozy.catalog.CatalogLayout;

public class NativeGeometryChecks {
 public static void main(String[] args) {
  int overlaps=0;
  for(boolean background : new boolean[]{false,true}) {
  IIngredientGridConfig config = new IIngredientGridConfig() {
   public int getMaxColumns(){return 9;}
   public int getMinColumns(){return 2;}
   public int getMaxRows(){return 16;}
   public int getMinRows(){return 1;}
   public boolean drawBackground(){return background;}
   public HorizontalAlignment getHorizontalAlignment(){return HorizontalAlignment.LEFT;}
   public VerticalAlignment getVerticalAlignment(){return VerticalAlignment.TOP;}
   public NavigationVisibility getButtonNavigationVisibility(){return NavigationVisibility.ENABLED;}
  };
  for (int[] dims : new int[][]{{960,540,568},{640,360,408},{480,270,328},{426,240,301}}) {
   var bar=CatalogLayout.controls(dims[0],dims[1],dims[2],dims[0]-dims[2],true);
   var b=bar.bar();
   var source=new ImmutableRect2i(dims[2],0,dims[0]-dims[2],dims[1]-22);
   var exclusions=Set.of(new ImmutableRect2i(b.x(),b.y(),b.width(),b.height()));
   var layout=IngredientGridWithNavigationLayout.calculate(config,source,exclusions,null,10000);
   var nav=layout.navigationArea();
   var n=new CatalogLayout.Rect(nav.getX(),nav.getY(),nav.getWidth(),nav.getHeight());
   boolean overlap=b.overlaps(n);
   if(overlap) overlaps++;
   System.out.println("background="+background+" dims="+java.util.Arrays.toString(dims)+" bar="+b+" category="+bar.category()+" nav="+nav+" slots="+layout.availableSlotCount()+" overlap="+overlap);
  }
  }
  if(overlaps>0)throw new AssertionError(overlaps+" toolbar/navigation overlaps");
  System.out.println("PASS actual JEI native navigation geometry");
 }
}


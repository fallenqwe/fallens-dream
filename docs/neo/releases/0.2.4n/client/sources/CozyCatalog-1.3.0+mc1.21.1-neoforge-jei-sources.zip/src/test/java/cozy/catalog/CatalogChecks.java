package cozy.catalog;
import java.util.*;
import static cozy.catalog.CatalogModel.*;
public final class CatalogChecks {
    static int checks;
    static void check(boolean condition,String why){checks++;if(!condition)throw new AssertionError(why);}
    static Facts f(String id,boolean block){return new Facts(id,block,false,false,false);}
    static void in(Facts facts,Category c,String sub){check(matches(facts,new Selection(c,sub,Sort.NATIVE)),facts.id()+" must be found in "+c+" / "+sub);}
    public static void main(String[] args){
        in(f("artifacts:night_vision_goggles",false),Category.GEAR,"special");
        in(f("artifacts:cloud_in_a_bottle",false),Category.GEAR,"special");
        in(f("artifacts:umbrella",false),Category.GEAR,"special");
        check(!categories(f("artifacts:mimic_spawn_egg",false)).contains(Category.GEAR),"spawn eggs are not wearable artifacts");
        check(!categories(new Facts("artifacts:everlasting_beef",false,true,false,false)).contains(Category.GEAR),"food artifacts retain food classification");

        in(f("mcwwindows:oak_blinds",true),Category.FURNITURE,"openings");
        in(f("mcwwindows:oak_blinds",true),Category.BUILDING,"wood");
        in(f("mcwfurnitures:oak_chair",true),Category.FURNITURE,"seats");
        in(f("skniro_furniture:oak_kitchen_cabinet",true),Category.FURNITURE,"storage");
        in(f("storagedelight:oak_drawer",true),Category.FURNITURE,"storage");
        in(f("mdm:kitchen_set_3_counter",true),Category.FURNITURE,"tables");
        in(f("mdm:kitchen_set_3_hanging_cabinet",true),Category.FURNITURE,"storage");
        in(f("mdm:kitchen_set_3_bar_chair",true),Category.FURNITURE,"seats");
        in(f("mdm:plate",true),Category.FURNITURE,"all");
        in(f("mdm:mug",true),Category.DECOR,"all");
        in(f("mdm:furniture_parts",false),Category.MATERIALS,"all");
        check(!categories(f("mdm:knife",true)).contains(Category.TOOLS),"decorative MDM knife is not a usable tool");
        check(!categories(f("mdm:oven",true)).contains(Category.MECHANISMS),"decorative MDM oven is not a working appliance");
        check(!categories(f("mdm:gas_stove",true)).contains(Category.MECHANISMS),"decorative MDM gas stove is not a working appliance");
        in(f("cookingforblockheads:white_oven",true),Category.MECHANISMS,"workstations");
        in(new Facts("rusticdelight:coffee",false,true,false,false),Category.FOOD,"edible");
        in(f("rusticdelight:roasted_coffee_beans",false),Category.FOOD,"ingredients");
        in(f("minecraft:hopper",true),Category.MECHANISMS,"redstone");
        in(f("minecraft:rail",true),Category.MECHANISMS,"transport");
        in(f("minecraft:lightning_rod",true),Category.MECHANISMS,"redstone");
        in(f("minecraft:waxed_lightning_rod",true),Category.MECHANISMS,"redstone");
        in(f("minecraft:exposed_copper_chest",true),Category.MECHANISMS,"transport");
        in(f("minecraft:ender_chest",true),Category.FURNITURE,"storage");
        in(f("minecraft:blue_shulker_box",true),Category.FURNITURE,"storage");
        in(f("minecraft:oak_shelf",true),Category.FURNITURE,"storage");
        in(f("minecraft:crafting_table",true),Category.MECHANISMS,"workstations");
        in(f("minecraft:iron_pickaxe",false),Category.TOOLS,"mining");
        in(f("farmersdelight:diamond_knife",false),Category.TOOLS,"farming");
        in(f("rechiseled:stone_big_tiles",true),Category.BUILDING,"stone");
        in(f("minecraft:oak_planks",true),Category.MATERIALS,"wood");
        in(f("minecraft:iron_ingot",false),Category.MATERIALS,"metals");
        in(new Facts("minecraft:apple",false,true,false,false),Category.FOOD,"edible");
        in(f("minecraft:carrot",false),Category.FOOD,"farming");
        in(f("ecologics:coconut_sapling",true),Category.NATURE,"saplings");
        in(f("minecraft:redstone_lamp",true),Category.DECOR,"lighting");
        in(f("minecraft:redstone_lamp",true),Category.MECHANISMS,"redstone");
        in(f("minecraft:oak_door",true),Category.BUILDING,"wood");
        // The real Tiny Flowers item id is shared by every component-based flower
        // and mixed garden. Shears must remain usable without appearing as plants.
        in(f("tiny_flowers:tiny_flower",true),Category.DECOR,"plants");
        in(f("tiny_flowers:tiny_flower",true),Category.NATURE,"plants");
        Facts shears=new Facts("tiny_flowers:florists_shears",false,false,true,false);
        in(shears,Category.TOOLS,"farming");
        check(categories(shears).equals(EnumSet.of(Category.ALL,Category.TOOLS)),"florists' shears are tools only, not flowers by mod namespace");
        in(f("mcwfences:oak_hedge",true),Category.DECOR,"plants");
        in(f("mcwfences:oak_hedge",true),Category.NATURE,"plants");
        in(f("mcwfences:oak_hedge",true),Category.BUILDING,"exterior");
        in(f("mcwfences:panelled_metal_fence",true),Category.BUILDING,"exterior");
        check(!matches(f("mcwfences:panelled_metal_fence",true),new Selection(Category.DECOR,"plants",Sort.NATIVE)),"ordinary fences do not become hedges by namespace");
        in(f("mcwpaths:oak_planks_path",true),Category.BUILDING,"exterior");
        in(f("mcwpaths:mossy_stone_running_bond_path",true),Category.BUILDING,"exterior");
        in(f("mcwpaths:dirt_path_block",true),Category.BUILDING,"exterior");
        in(f("mcwpaths:stone_running_bond_stairs",true),Category.BUILDING,"shapes");
        check(!matches(f("minecraft:stone",true),new Selection(Category.BUILDING,"exterior",Sort.NATIVE)),"plain stone does not become garden paving");
        in(f("futuremod:unknown_new_thing",false),Category.OTHER,"all");
        check(!matches(f("minecraft:stone",true),new Selection(Category.FURNITURE,"all",Sort.NAME)),"stone is not furniture");
        check(!matches(f("minecraft:crafting_table",true),new Selection(Category.FURNITURE,"tables",Sort.NAME)),"workstation does not become a dining table via substring");
        check(!matches(f("minecraft:diamond_sword",false),new Selection(Category.FOOD,"all",Sort.NATIVE)),"sword not food");
        check(!categories(f("minecraft:diamond_leggings",false)).contains(Category.FOOD),"leggings is not egg");
        check(!categories(f("minecraft:light_gray_wool",true)).contains(Category.DECOR),"light color is not a light source");
        check(!categories(f("minecraft:basalt",true)).contains(Category.FOOD),"basalt is not salt");
        check(!categories(f("minecraft:blooming_azalea",true)).contains(Category.MECHANISMS),"bloom is not loom");
        check(!categories(f("futuremod:narrow_stone_bricks",true)).contains(Category.GEAR),"narrow is not arrow");
        check(!categories(new Facts("minecraft:stone_pickaxe",false,false,true,false)).contains(Category.MATERIALS),"crafted tools are not raw stone");
        check(!categories(new Facts("minecraft:leather_helmet",false,false,false,true)).contains(Category.MATERIALS),"leather armor is not a crafting material");
        // Current 88-JAR pack: literal IDs checked in the pinned JAR assets/registration bytecode.
        // These are pure input fixtures, not evidence of a post-init Minecraft registry or rendering.
        for(String id:List.of("create:shaft","create:cogwheel","create:large_cogwheel","create:mechanical_press",
                "create:mechanical_mixer","create:fluid_pipe","create:andesite_funnel","create:item_vault",
                "copycats:copycat_cogwheel","copycats:copycat_shaft","copycats:copycat_fluid_pipe",
                "create_connected:brass_gearbox","create_vibrant_vaults:black_item_vault"))
            in(f(id,true),Category.MECHANISMS,"all");
        check(!categories(f("create:copper_shingle_slab",true)).contains(Category.MECHANISMS),"Create decorative building blocks are not mechanisms by namespace");
        check(!categories(f("copycats:copycat_block",true)).contains(Category.MECHANISMS),"plain copycat building block is not a machine");
        in(f("copycats:copycat_stairs",true),Category.BUILDING,"shapes");
        for(String id:List.of("cgs:flintlock","cgs:revolver","cgs:shotgun","cgs:nailgun","cgs:gatling","cgs:blazegun","cgs:launcher","cgs:hammer","cgs:frag_grenade"))
            in(f(id,false),Category.GEAR,"weapons");
        check(!categories(f("cgs:steel_ingot",false)).contains(Category.GEAR),"gun crafting material is not a weapon by mod namespace");
        check(!categories(f("cgs:lead_ingot",false)).contains(Category.TOOLS),"lead metal is not a lead for walking animals");
        in(f("cgs:lead_ingot",false),Category.MATERIALS,"metals");
        in(f("minecraft:lead",false),Category.TOOLS,"all");
        in(f("cgs:barrel",false),Category.MATERIALS,"all");
        check(!categories(f("cgs:barrel",false)).contains(Category.FURNITURE),"gun barrel is not a furniture barrel");
        check(!categories(f("cgs:barrel",false)).contains(Category.MECHANISMS),"gun barrel part is not storage machinery");
        in(f("exposure:camera",false),Category.TOOLS,"all");
        in(f("exposure_polaroid:instant_camera",false),Category.TOOLS,"all");
        check(!categories(f("exposure:color_film",false)).contains(Category.TOOLS),"film consumable is not a camera by namespace");
        in(f("exposure:photograph_frame",false),Category.DECOR,"all");
        in(f("moderndeco:armchair",true),Category.FURNITURE,"seats");
        in(f("moderndeco:sofamd_1",true),Category.FURNITURE,"seats");
        in(f("moderndeco:glasstable",true),Category.FURNITURE,"tables");
        in(f("moderndeco:wallclock",true),Category.DECOR,"all");
        check(!categories(f("moderndeco:wallclock",true)).contains(Category.TOOLS),"placed decorative wall clock is not a usable clock item");
        check(!categories(f("moderndeco:systemboard",false)).contains(Category.FURNITURE),"electronic crafting part is not furniture by namespace");
        in(f("interiors:black_chair",true),Category.FURNITURE,"seats");
        in(f("interiors:black_cushion",true),Category.FURNITURE,"seats");
        in(f("skniro_furniture:oak_black_cushion",true),Category.FURNITURE,"seats");
        for(String id:List.of("sophisticatedbackpacks:backpack","sophisticatedbackpacks:iron_backpack","travelersbackpack:travelers_backpack")){
            in(f(id,true),Category.TOOLS,"all");
            in(f(id,true),Category.FURNITURE,"storage");
            check(!categories(f(id,false)).contains(Category.FURNITURE),"portable non-block backpack is not furniture: "+id);
        }
        check(!categories(f("sophisticatedbackpacks:pickup_upgrade",false)).contains(Category.FURNITURE),"backpack upgrade is not furniture");
        for(Category c:Category.values()){
            List<Subcategory> subs=subcategories(c);check(subs.getFirst().id().equals("all"),"all in every menu");check(new HashSet<>(subs.stream().map(Subcategory::id).toList()).size()==subs.size(),"unique subcategory ids");
        }
        for(String id:List.of("minecraft:air","minecraft:stone","mcwwindows:oak_blinds","futuremod:thing"))check(matches(f(id,false),DEFAULT),"default preserves every entry");
        System.out.println("PASS: "+checks+" classification scenarios, overlapping functional categories, unknown content fallback and full reset. No Minecraft initialization.");
    }
}

package cozy.catalog;

import java.util.Collection;
import mezz.jei.api.IModPlugin;
import mezz.jei.api.JeiPlugin;
import mezz.jei.api.gui.handlers.IGlobalGuiHandler;
import mezz.jei.api.registration.IGuiHandlerRegistration;
import mezz.jei.api.runtime.IJeiRuntime;
import net.minecraft.client.renderer.Rect2i;
import net.minecraft.resources.ResourceLocation;

@JeiPlugin
public final class CatalogPlugin implements IModPlugin {
    @Override public ResourceLocation getPluginUid() { return ResourceLocation.fromNamespaceAndPath(CatalogClient.MOD_ID, "categories"); }
    @Override public void registerGuiHandlers(IGuiHandlerRegistration registration) {
        registration.addGlobalGuiHandler(new IGlobalGuiHandler() {
            @Override public Collection<Rect2i> getGuiExtraAreas() { return CatalogOverlay.exclusions(); }
        });
    }
    @Override public void onRuntimeAvailable(IJeiRuntime runtime) { CatalogClient.runtimeAvailable(runtime); }
    @Override public void onRuntimeUnavailable() { CatalogClient.runtimeUnavailable(); }
}

package cozy.catalog;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.function.UnaryOperator;
import mezz.jei.gui.overlay.IIngredientGridSource;
import mezz.jei.gui.overlay.elements.IElement;

/** A source wrapper used exclusively by JEI's right ingredient grid. */
public final class CategoryGridSource implements IIngredientGridSource {
    private final IIngredientGridSource delegate;
    private final UnaryOperator<List<IElement<?>>> transform;
    private final List<SourceListChangedListener> listeners = new ArrayList<>();
    private List<IElement<?>> nativeSnapshot;
    private List<IElement<?>> snapshot;
    public CategoryGridSource(IIngredientGridSource delegate, UnaryOperator<List<IElement<?>>> transform) {
        this.delegate = Objects.requireNonNull(delegate);
        this.transform = Objects.requireNonNull(transform);
        delegate.addSourceListChangedListener(this::refresh);
    }
    @Override public List<IElement<?>> getElements() {
        List<IElement<?>> current = delegate.getElements();
        if (snapshot == null || current != nativeSnapshot) {
            // Keep native element identities so native recipes and item actions stay attached.
            snapshot = List.copyOf(transform.apply(current));
            nativeSnapshot = current;
        }
        return snapshot;
    }
    @Override public void addSourceListChangedListener(SourceListChangedListener listener) {
        listeners.add(Objects.requireNonNull(listener));
    }
    /** Client thread, like JEI's native notifications. The search string never needs to change. */
    public void refresh() {
        snapshot = null;
        nativeSnapshot = null;
        List.copyOf(listeners).forEach(SourceListChangedListener::onSourceListChanged);
    }
}
